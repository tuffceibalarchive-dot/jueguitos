# -*- coding: utf-8 -*-
# Reemplazo en Python puro del modulo imagepatch.so (compilado solo para Linux/OLPC).
# Colocar este archivo en la carpeta Saludame.activity, junto a animation.py y game.py.
#
# El .so original aplicaba un diff XOR byte a byte entre el buffer de pixeles
# del frame anterior y el contenido descomprimido de un archivo .diff.zlib,
# para reconstruir el frame siguiente de la animacion del personaje.

import array

def patch(old_buffer, diff):
    """
    old_buffer: bytes/str con el buffer de pixeles del frame anterior
    diff: bytes/str con el diff ya descomprimido (mismo largo que old_buffer)
    Devuelve: bytes/str con el buffer del nuevo frame.
    """
    a = array.array('B', old_buffer)
    b = array.array('B', diff)

    if len(a) != len(b):
        raise ValueError("imagepatch.patch: los buffers tienen distinto tamano (%d vs %d)" % (len(a), len(b)))

    for i in range(len(a)):
        a[i] ^= b[i]

    return a.tostring()  # en Python 2 tostring() devuelve un str de bytes
