# -*- coding: utf-8 -*-
# Lanzador grafico de Saludame (Python 2 + Tkinter).
# Guardar como "Saludame.pyw" dentro de la carpeta Saludame.activity
# (junto a game.py). Al ser .pyw, Windows lo abre con pythonw.exe,
# que NO muestra ninguna ventana de consola.

import os
import sys
import subprocess
import Tkinter as tk

# Nos aseguramos de trabajar siempre desde la carpeta del juego,
# sin importar desde donde se haga doble clic.
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(SCRIPT_DIR)


def iniciar_juego():
    try:
        width = int(width_var.get())
        height = int(height_var.get())
    except ValueError:
        width, height = 1000, 650

    gender = gender_var.get()  # "boy" o "girl"

    args = ["py", "-2", "game.pyw", gender]

    if fullscreen_var.get():
        args.append("full")
    else:
        args.append("%dx%d" % (width, height))

    # CREATE_NO_WINDOW evita que aparezca una consola al lanzar el proceso hijo.
    creationflags = 0
    if hasattr(subprocess, "CREATE_NO_WINDOW"):
        creationflags = subprocess.CREATE_NO_WINDOW

    subprocess.Popen(args, cwd=SCRIPT_DIR, creationflags=creationflags)
    root.destroy()


def toggle_fullscreen():
    state = tk.DISABLED if fullscreen_var.get() else tk.NORMAL
    width_entry.config(state=state)
    height_entry.config(state=state)


root = tk.Tk()
root.title(u"Salúdame - Configuración")
root.resizable(False, False)

pad = {"padx": 10, "pady": 6}

tk.Label(root, text=u"Resolución", font=("Arial", 11, "bold")).grid(row=0, column=0, columnspan=2, sticky="w", **pad)

tk.Label(root, text=u"Ancho:").grid(row=1, column=0, sticky="e", **pad)
width_var = tk.StringVar(value="1000")
width_entry = tk.Entry(root, textvariable=width_var, width=8)
width_entry.grid(row=1, column=1, sticky="w", **pad)

tk.Label(root, text=u"Alto:").grid(row=2, column=0, sticky="e", **pad)
height_var = tk.StringVar(value="650")
height_entry = tk.Entry(root, textvariable=height_var, width=8)
height_entry.grid(row=2, column=1, sticky="w", **pad)

fullscreen_var = tk.BooleanVar(value=False)
tk.Checkbutton(
    root, text=u"Pantalla completa", variable=fullscreen_var, command=toggle_fullscreen
).grid(row=3, column=0, columnspan=2, sticky="w", **pad)

tk.Label(root, text=u"Personaje", font=("Arial", 11, "bold")).grid(row=4, column=0, columnspan=2, sticky="w", **pad)

gender_var = tk.StringVar(value="boy")
tk.Radiobutton(root, text=u"Iniciar como varón", variable=gender_var, value="boy").grid(
    row=5, column=0, columnspan=2, sticky="w", **pad
)
tk.Radiobutton(root, text=u"Iniciar como nena", variable=gender_var, value="girl").grid(
    row=6, column=0, columnspan=2, sticky="w", **pad
)

tk.Button(
    root, text=u"Iniciar Salúdame", command=iniciar_juego, font=("Arial", 11, "bold"), bg="#4CAF50", fg="white"
).grid(row=7, column=0, columnspan=2, sticky="we", padx=10, pady=12)

root.mainloop()
