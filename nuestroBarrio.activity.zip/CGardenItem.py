'''
Created on 19/03/2013

@author: Gus
'''
from api.CSpriteSheet import spritesheet;
from api.CSpriteStripAnim import SpriteStripAnim;
from api.CGame import cGame;
import Assets.Assets as A;
import pygame;
import api.CMath;
import random;
class cGardenItem(pygame.sprite.DirtySprite):
    '''
    classdocs
    '''
    
    def __init__(self, itemType, x, y, aPlayer, aGardenMap):
        
        '''
        Constructor
        '''
        pygame.sprite.DirtySprite.__init__(self);
        self.itemType = itemType;
        self.mGardenMap = aGardenMap;
        self.x = x;
        self.y = y;
        self.mPlayer = aPlayer;
        self.isDead = False;
        self.FPS = 30;
        if(self.itemType == "canilla"):
            self.frames = self.FPS / random.randint(1,3);
        else:
            self.frames = self.FPS / 2;
            
        self.trashState = "standing";
        self.killTime = 0;
        
        if(cGame.inst().cProgressSave.difficultySelected == 1):
            self.items = spritesheet(A.TRASH_100);
            self.itemList = self.items.load_strip((0, 0, 100, 100), 3, colorkey = (0,0,0));
            if(self.itemType == "botella"):    
                self.image =  pygame.Surface.convert_alpha((self.itemList[0]));    
            elif(self.itemType == "papel"):
                self.image =  pygame.Surface.convert_alpha((self.itemList[1]));    
            elif(self.itemType == "bolsa"):
                self.image =  pygame.Surface.convert_alpha((self.itemList[2]));
            elif(self.itemType == "canilla"):
                self.state = "abierta";
                self.n = 0;
                self.animAbierta = SpriteStripAnim(A.CANILLAS_100, (100, 0, 100, 100), 4, (0,0,0), True, self.frames);
                self.animCerrada = SpriteStripAnim(A.CANILLAS_100, (0, 0, 100, 100), 1, (0,0,0), True, self.frames);
                self.abierta = [self.animAbierta];
                self.cerrada = [self.animCerrada];
                self.image = self.abierta[self.n].next(); 
                    
            elif(self.itemType == "dumpster"):
                self.state = "closed";
                self.dumpster = SpriteStripAnim(A.TRASHCAN_100, (0, 0, 100, 100), 2, (0,0,0), True, self.frames);
                self.dumpsterAnim = [self.dumpster];
                self.n = 0;
                self.image = self.dumpsterAnim[self.n].first();
                self.dumpsterSndPlayed = False;
        elif(cGame.inst().cProgressSave.difficultySelected == 2):
            self.items = spritesheet(A.TRASH_75);
            self.itemList = self.items.load_strip((0, 0, 75, 75), 3, colorkey = (0,0,0));
            if(self.itemType == "botella"):
                self.image =  pygame.Surface.convert_alpha((self.itemList[0]));
            elif(self.itemType == "papel"):
                self.image =  pygame.Surface.convert_alpha((self.itemList[1]));
            elif(self.itemType == "bolsa"):
                self.image =  pygame.Surface.convert_alpha((self.itemList[2]));
            elif(self.itemType == "canilla"):
                self.state = "abierta";
                self.n = 0;
                self.animAbierta = SpriteStripAnim(A.CANILLAS_75, (75, 0, 75, 75), 4, (0,0,0), True, self.frames);
                self.animCerrada = SpriteStripAnim(A.CANILLAS_75, (0, 0, 75, 75), 1, (0,0,0), True, self.frames);
                self.abierta = [self.animAbierta];
                self.cerrada = [self.animCerrada];
                self.image = self.abierta[self.n].next();
            elif(self.itemType == "dumpster"):
                self.state = "closed";
                self.dumpster = SpriteStripAnim(A.TRASHCAN_75, (0, 0, 75, 75), 2, (0,0,0), True, self.frames);
                self.dumpsterAnim = [self.dumpster];
                self.n = 0;
                self.image = self.dumpsterAnim[self.n].first();  
                self.dumpsterSndPlayed = False;                 
                                       
        elif(cGame.inst().cProgressSave.difficultySelected == 3):
            self.items = spritesheet(A.TRASH_60);
            self.itemList = self.items.load_strip((0, 0, 60, 60), 3, colorkey = (0,0,0));
            if(self.itemType == "botella"):
                self.image =  pygame.Surface.convert_alpha((self.itemList[0]));
            elif(self.itemType == "papel"):
                self.image =  pygame.Surface.convert_alpha((self.itemList[1]));
            elif(self.itemType == "bolsa"):
                self.image =  pygame.Surface.convert_alpha((self.itemList[2]));
            elif(self.itemType == "canilla"):
                self.state = "abierta";
                self.n = 0;
                self.animAbierta = SpriteStripAnim(A.CANILLAS_60, (60, 0, 60, 60), 4, (0,0,0), True, self.frames);
                self.animCerrada = SpriteStripAnim(A.CANILLAS_60, (0, 0, 60, 60), 1, (0,0,0), True, self.frames);
                self.abierta = [self.animAbierta];
                self.cerrada = [self.animCerrada];
                self.image = self.abierta[self.n].next();
            elif(self.itemType == "dumpster"):
                self.state = "closed";
                self.dumpster = SpriteStripAnim(A.TRASHCAN_60, (0, 0, 60, 60), 2, (0,0,0), True, self.frames);
                self.dumpsterAnim = [self.dumpster];
                self.n = 0;
                self.image = self.dumpsterAnim[self.n].first();  
                self.dumpsterSndPlayed = False;                    
               
        self.rect = self.image.get_rect();
        self.rect.topleft = self.x ,self.y;  
     
    def update(self):
        eventos_republicar= [];
        
        if(self.itemType == "canilla"):
            if(self.state == "abierta"):
                self.image = self.abierta[self.n].next();
            else:
                self.image = self.cerrada[self.n].first();
            
        if(self.itemType == "dumpster"):
            if(self.state == "animar"):
                self.image = self.dumpsterAnim[self.n].next();
                 
        if (api.CMath.dist(self.rect.centerx , self.rect.centery , self.mPlayer.rect.centerx, self.mPlayer.rect.centery) <= 60):
            self.trashState = "tomado";
            if(self.itemType == "canilla"):
                for event in pygame.event.get(pygame.KEYDOWN):
                    if event.key==pygame.K_SPACE:
                        if(self.state != "cerrada"):
                            self.state = "cerrada";
                            if(self.mGardenMap.fxOn):
                                self.mGardenMap.canillaSnd.play();
                            self.mGardenMap.totalCanillasClosed +=1;
                    elif event.key == pygame.K_0:
                        if not event in eventos_republicar: eventos_republicar.append(event);
                        continue
                    elif event.key == pygame.K_1:
                        if not event in eventos_republicar: eventos_republicar.append(event);
                        continue
                    
                    elif event.key == pygame.K_LEFT:
                        if not event in eventos_republicar: eventos_republicar.append(event);
                        continue                
                    elif event.key == pygame.K_UP:
                        if not event in eventos_republicar: eventos_republicar.append(event);
                        continue
                    elif event.key == pygame.K_DOWN:
                        if not event in eventos_republicar: eventos_republicar.append(event);
                        continue
                    elif event.key == pygame.K_SPACE:
                        if not event in eventos_republicar: eventos_republicar.append(event);
                        continue
                    
                    elif event.key == pygame.K_RIGHT:
                        if not event in eventos_republicar: eventos_republicar.append(event);
                        continue
                    else:
                        continue
                for event in eventos_republicar:
                    pygame.event.post(event);
                
            elif(self.itemType == "dumpster"):
                self.state = "animar";
                if(self.dumpsterSndPlayed == False):
                    if(self.mGardenMap.fxOn):
                        self.mGardenMap.contenedorSnd.play();
                    self.dumpsterSndPlayed = True;
        if(self.itemType == "botella" or self.itemType == "papel" or self.itemType == "bolsa"):
            if(self.trashState == "tomado"):
                self.image = self.resize(self.image, 0.9);
                self.killTime += 1;
        if(self.killTime >= 10):
            self.isDead = True;
            
        
                    
    def destroy(self):
        self.items = None;
        self.itemList = None;
        self.image = None;    
        if(self.itemType == "canilla"):
            self.animAbierta = None;
            self.AnimCerrada = None;
            self.abierta = None;
            self.cerrada = None;
        elif(self.itemType == "dumpster"):
            self.dumpster = None;
            self.dumpsterAnim = None;
            self.dumpsterSndPlayed = None;
    def resize(self, surface, size):
        scale = size;
        return pygame.transform.rotozoom(surface, 5, scale);      

            
            
            
            
            
                
                