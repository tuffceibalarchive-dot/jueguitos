'''
Created on 15/04/2013

@author: Gus
'''
import pygame;
from api.CSpriteStripAnim import SpriteStripAnim;
import Assets.Assets as A;
class cCard(pygame.sprite.DirtySprite):
    '''
    classdocs
    '''


    def __init__(self, aNumberType, cardPos, aDistractorLevel):
        '''
        Constructor
        '''
        pygame.sprite.DirtySprite.__init__(self);
        self.mNumberType = aNumberType;
        self.mDistractorLevel = aDistractorLevel;
        self.frames = 1;
        self.n = 0;
#        self.mDistractorLevel = aDistractorLevel;
        self.cardType = SpriteStripAnim(A.CARDSHEET, ((aNumberType)*200, 0, 200, 200), 1, (0,0,0), True, self.frames);
        self.cardBack = SpriteStripAnim(A.CARDSHEET, (30*200, 0, 200, 200), 1, (0,0,0), True, self.frames);
        self.cardShowed = [self.cardType];
        self.cardNotShowed = [self.cardBack];
        
        self.image =  self.cardNotShowed[self.n].first();
        
        self.rect = self.image.get_rect();
        
        self.rect.topleft = cardPos;
        self.isSelected = False;
        self.hasMatch = False;
#        self.mDistractorLevel.allSprites.add(self);
    
    def update(self):
        if(self.isSelected or self.hasMatch):
            self.image = self.cardShowed[self.n].first();
        else:
            self.image =  self.cardNotShowed[self.n].first();
             
    def destroy(self):
#        self.mDistractorLevel.allSprites.remove(self);
#         for self.card in self.cardShowed:
#             self.card = None;
#         for self.theBack in self.cardNotShowed:
#             self.theBack = None;
        self.cardShowed = None;
        self.cardNotShowed = None;
        self.cardType = None;
        self.cardBack = None;
        self.image = None;
        self.rect = None;
        self.isSelected = None;
        self.hasMatch = None;
        self.mNumberType = None;
        self.mDistractorLevel = None;
        self.frames = None;
        self.n = None;
    
    def pressed(self):
        self.mousePos = pygame.mouse.get_pos();
        if self.mousePos[0] > self.rect.topleft[0]:
            if self.mousePos[1] > self.rect.topleft[1]:
                if self.mousePos[0] < self.rect.topleft[0] + self.rect[2]:
                    if self.mousePos[1] < self.rect.topleft[1] + self.rect[3]:
                        return True
                    else: return False
                else: return False
            else: return False
        else: return False
        pass
        