'''
Created on 19/04/2013

@author: Gus
'''
import pygame;
import Assets.Assets as A;
from api.CSpriteStripAnim import SpriteStripAnim;




class cMouse(pygame.sprite.Sprite):
    def __init__(self, aType = "pencil"):
        pygame.sprite.Sprite.__init__(self);
        self.EMPTY = 0;
        self.RED = 1;
        self.ORANGE = 2
        self.YELLOW = 3;
        self.GREEN = 4;
        self.BLUE = 5;
        self.PURPLE = 6;
        self.mType = aType;
        self.paint = self.EMPTY;
        
        if(aType == "pencil"):
            self.image =  pygame.Surface.convert_alpha(pygame.image.load(A.MOUSE));
        
        elif(aType == "brush"):
            self.brushAnim = SpriteStripAnim(A.BRUSHSHEET, (0, 0, 60, 110), 7, (0,0,0)); 
            self.image = self.brushAnim.getImageByIndex(0);
            
        elif(aType == "staff"):
            self.image = pygame.Surface.convert_alpha(pygame.image.load(A.STAFF));
        self.rect = self.image.get_rect();
    def update(self):
        self.rect.topleft = pygame.mouse.get_pos();
        
    
    def changeColor(self, color):
        if(color == self.EMPTY):
            self.image = self.brushAnim.getImageByIndex(0);
        elif(color == self.RED):
            self.image = self.brushAnim.getImageByIndex(1);
        elif(color == self.ORANGE):
            self.image = self.brushAnim.getImageByIndex(2);
        elif(color == self.YELLOW):
            self.image = self.brushAnim.getImageByIndex(3);
        elif(color == self.GREEN):
            self.image = self.brushAnim.getImageByIndex(4);
        elif(color == self.BLUE):
            self.image = self.brushAnim.getImageByIndex(5);
        elif(color == self.PURPLE):
            self.image = self.brushAnim.getImageByIndex(6);
        self.paint = color;
        
    def destroy(self):
        self.EMPTY = None;
        self.RED = None;
        self.ORANGE = None
        self.YELLOW = None;
        self.GREEN = None;
        self.BLUE = None;
        self.PURPLE = None;
        self.mType = None;
        self.paint = None;
        if(self.mType == "brush"):
            self.brushAnim = None;
        self.image = None;
        self.rect = None;
