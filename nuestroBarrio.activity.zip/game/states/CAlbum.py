'''
Created on 03/01/2013

@author: Gus
'''
from api.CGameState import cGameState;
import pygame;
from api.CGame import cGame;
from api.CSpriteSheet import spritesheet;
import game.states.CMainMenu;
import game.states.CLevelState;
#from api.CGameObject import cGameObject;
import Assets.Assets as A; 
from CMouse import cMouse;
from Assets.button import Button;
import Assets.AudioAssets as Audio;


class Label(pygame.sprite.DirtySprite):
    def __init__(self, medalType):
        #medalType between 0 bronze and 2 gold!!!
        pygame.sprite.DirtySprite.__init__(self);
        self.labelSheet = spritesheet(A.LABELS);
        self.labelType = medalType;
        self.labelList = self.labelSheet.load_strip((0, 0, 780, 180), 3, colorkey = (0,0,0));
        self.image = self.labelList[self.labelType];
        self.rect = self.image.get_rect();
    def SetCoords(self, x,y):
        self.rect.topleft = (x,y);
    def destroy(self):
        self.labelList = None;
        self.labelSheet = None;
        self.image = None;
        self.rect = None;
        self.medalType = None;
        
class Medal(pygame.sprite.DirtySprite):
    def __init__(self, medalType):
        #medalType between 0 bronze and 2 gold!!!
        pygame.sprite.DirtySprite.__init__(self);
        self.medalsSheet = spritesheet(A.MEDALS);
        self.medalType = medalType;
        self.medalsList = self.medalsSheet.load_strip((0, 0, 400, 400), 3, colorkey = (0,0,0));
        self.image = self.medalsList[self.medalType];
        self.rect = self.image.get_rect();
    def SetCoords(self, x,y):
        self.rect.topleft = (x,y);
    def destroy(self):
        self.medalsList = None;
        self.medalsSheet = None;
        self.image = None;
        self.rect = None;
        self.medalType = None;
        
class Picture(pygame.sprite.DirtySprite):
    def __init__(self, name, x,y):
        pygame.sprite.DirtySprite.__init__(self);       
        self.image = pygame.Surface.convert_alpha(pygame.image.load(name));
        self.rect = self.image.get_rect();
        self.rect.topleft = (x,y);
    def destroy(self):
        self.image = None;
        self.rect = None;
class cAlbum(cGameState):
    '''
    classdocs
    '''
    
    def __init__(self, aAlbumPage, aFromWhere):
        '''
        Constructor
        '''
        # Backgroung music
        self.music = Audio.MUSICALBUM;
        # Loading file & playing music
        pygame.mixer.music.load(self.music)
        pygame.mixer.music.play();
        if(cGame.inst().cProgressSave.audioOn == False):
            pygame.mixer.music.pause();
        self.name = "album";
        pygame.mouse.set_visible(False);
        self.display = cGame.inst().getDisplay();
#        cGame.CGameIntFace.set_background(self.mMainMenu);
        self.mAlbumPage = aAlbumPage;
        self.mFromWhere = aFromWhere;
        self.btnLeft = None;
        self.btnRight = None;
        self.medalWon = None;
        self.labelWon = None;
        self.allSprites = cGame.inst().getContainer();
        self.picList = [];
        self.AddUnlockedPics();
        if(self.mAlbumPage == 1):
            self.MENU = A.albumCover;
            if(cGame.inst().cProgressSave.medal != None):
                self.medalWon = Medal(cGame.inst().cProgressSave.medal);
                self.medalWon.SetCoords(420, 300);
                self.labelWon = Label(cGame.inst().cProgressSave.medal);
                self.labelWon.SetCoords(225, 105);
                self.allSprites.add(self.medalWon, self.labelWon);
        elif(self.mAlbumPage % 2 == 0):
            self.MENU = A.albumPageOne;
            self.btnLeft = Button(A.BTNLEFT, 10, 600);
            self.allSprites.add(self.btnLeft);
        elif(self.mAlbumPage != 1 and self.mAlbumPage % 2 != 0):
            self.MENU = A.albumPageTwo;
            self.btnLeft = Button(A.BTNLEFT, 10, 600);
            self.allSprites.add(self.btnLeft);
        if(self.mAlbumPage < 6):
            self.btnRight = Button(A.BTNRIGHT, 900, 600);
            self.allSprites.add(self.btnRight);  
        
        self.btnClose = Button(A.BTNCLOSE, 1050, 5);
        self.mMouse = cMouse();
        self.mMouse.update();
        cGame.inst().cProgressSave.newPic = False;
        self.allSprites.add(self.btnClose, self.mMouse);
        
        #----Copy the The Menu background one time so it stays behind always---#
        self.display.blit(self.MENU, (0,0));
        pygame.display.flip();
        self.started = True;
        self.flipTimer = 0;
#        CGame.cGame.CGameIntFace.addToContainer(self.mMainMenu);

    def eventUpdate(self):
        if(self.started):
            self.allSprites.update();
            for event in pygame.event.get():
                #handle basic events
                if event.type == pygame.QUIT:
                    cGame.inst().keepGoing = False;
                if event.type == pygame.MOUSEMOTION:
                    pass;
                if event.type==pygame.MOUSEBUTTONDOWN:
                    if(self.btnClose != None and self.btnClose.pressed()):
                        if(self.mFromWhere == "town"):
                            self.loadingTransition();
                            cGame.inst().setState(game.states.CLevelState.cLevelState(True));
                        elif(self.mFromWhere == "mainMenu"):
                            cGame.inst().setState(game.states.CMainMenu.cMainMenu());
                    elif(self.btnLeft != None and self.btnLeft.pressed()):
                        if(self.mAlbumPage > 1):
                            self.destroy();
                            cGame.inst().setState(game.states.CAlbum.cAlbum(self.mAlbumPage-1, self.mFromWhere));
                    elif(self.btnRight != None and self.btnRight.pressed()):
                        if(self.mAlbumPage < 6):
                            self.destroy();
                            cGame.inst().setState(game.states.CAlbum.cAlbum(self.mAlbumPage+1, self.mFromWhere));
                
    def update(self):
        #---Erase sprites from display and refill erased rectangles with the MENU background---#
        self.allSprites.clear(self.display, self.MENU);
        if(cGame.inst().cProgressSave.audioOn):
            if(pygame.mixer.music.get_busy() == False):
                pygame.mixer.music.play(); 
    
    def render(self):
        self.flipTimer+=1;
        #--- Draw and save sprite rectangles list ---#
        self.SpriteRectangles = self.allSprites.draw(self.display);
        #--- Pass sprite rectangles to display.update so it flips them to the display ---#
        pygame.display.update(self.SpriteRectangles);
        if(self.flipTimer >= 30):
            self.display.blit(self.MENU, (0,0));
            for self.sprite in self.allSprites:
                self.display.blit(self.sprite.image, (self.sprite.rect.topleft))
            pygame.display.flip();
            self.flipTimer = 0; 


    def AddUnlockedPics(self):
        if(self.mAlbumPage == 2):
            if(cGame.inst().cProgressSave.pics["circus01"]):
                self.pic = Picture(A.CIRCUS01,198,148);
                self.picList.append(self.pic);
            if(cGame.inst().cProgressSave.pics["circus02"]):
                self.pic = Picture(A.CIRCUS02, 664,148);
                self.picList.append(self.pic);
            if(cGame.inst().cProgressSave.pics["circus03"]):
                self.pic = Picture(A.CIRCUS03, 424,476);
                self.picList.append(self.pic);
        elif(self.mAlbumPage == 3):
            if(cGame.inst().cProgressSave.pics["museum01"]):
                self.pic = Picture(A.MUSEUM01, 398,110);
                self.picList.append(self.pic);
            if(cGame.inst().cProgressSave.pics["museum02"]):
                self.pic = Picture(A.MUSEUM02, 220,425);
                self.picList.append(self.pic);
            if(cGame.inst().cProgressSave.pics["garden01"]):
                self.pic = Picture(A.GARDEN01, 675,400);
                self.picList.append(self.pic);
        elif(self.mAlbumPage == 4):
            if(cGame.inst().cProgressSave.pics["garden02"]):
                self.pic = Picture(A.GARDEN02, 198,148);
                self.picList.append(self.pic);
            if(cGame.inst().cProgressSave.pics["farm01"]):
                self.pic = Picture(A.FARM01, 664,148);
                self.picList.append(self.pic);
            if(cGame.inst().cProgressSave.pics["farm02"]):
                self.pic = Picture(A.FARM02, 424,476);
                self.picList.append(self.pic);
        elif(self.mAlbumPage == 5):
            if(cGame.inst().cProgressSave.pics["vecino00"]):
                self.pic = Picture(A.DISTRACTOR01, 398,110);
                self.picList.append(self.pic);
            if(cGame.inst().cProgressSave.pics["vecino01"]):
                self.pic = Picture(A.DISTRACTOR02, 220,425);
                self.picList.append(self.pic);
            if(cGame.inst().cProgressSave.pics["vecino02"]):
                self.pic = Picture(A.DISTRACTOR03, 675,400);
                self.picList.append(self.pic);
        elif(self.mAlbumPage == 6):
            if(cGame.inst().cProgressSave.pics["vecino03"]):
                self.pic = Picture(A.DISTRACTOR04, 198,148);
                self.picList.append(self.pic);
            if(cGame.inst().cProgressSave.pics["vecino04"]):
                self.pic = Picture(A.DISTRACTOR05, 664,148);
                self.picList.append(self.pic);
            if(cGame.inst().cProgressSave.pics["gameCompleted"]):
                self.pic = Picture(A.ENDGAME, 424,476);
                self.picList.append(self.pic);
        self.allSprites.add(self.picList);
                
         
    def destroy(self):
        self.SpriteRectangles = None;
        self.allSprites.empty();
        self.allSprites = None;
        self.mMouse.destroy();
        self.mMouse = None;
        self.MENU = None;
        self.btnClose.destroy();
        self.btnClose = None;
        if(self.medalWon != None):
            self.medalWon.destroy();
            self.medalWon = None;
        if(self.btnRight != None):
            self.btnRight.destroy();          
            self.btnRight = None;
        if(self.btnLeft != None):
            self.btnLeft.destroy();
            self.btnLeft = None; 
        if(self.labelWon != None):
            self.labelWon.destroy();
            self.labelWon = None;
        self.display = None;
        self.i = 0;
        while(self.i<len(self.picList)):
            self.picList[self.i].destroy();
            self.picList[self.i] = None;
            self.i += 1;
        self.i = None;
#         for pic in self.picList:
#             pic.destroy();
        self.picList = None;
        pygame.mixer.music.stop();
        self.music = None;
        self.name = None;
        self.display = None;
        self.btnLeft = None;
        self.btnRight = None;
        self.medalWon = None;
        self.started = None;
        self.flipTimer = None;