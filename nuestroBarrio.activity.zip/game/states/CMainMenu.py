'''
Created on 03/01/2013

@author: Gus
'''
from api.CGameState import cGameState;
import pygame;
from api.CGame import cGame;
#from api.CGameObject import cGameObject;
from game.states.CDifficultySelect import cDifficultySelect;
from game.states.CCredits import cCredits;
from api.CSpriteStripAnim import SpriteStripAnim;
import Assets.Assets as A; 
from CMouse import cMouse;
import Assets.button as button;
import Assets.AudioAssets as Audio;
from api.CAudioBtns import cAudioBtns;


class RestartPopUp(pygame.sprite.DirtySprite):
    def __init__(self, x, y):
        pygame.sprite.DirtySprite.__init__(self);
        self.image = pygame.Surface.convert_alpha(pygame.image.load(A.NEWGAME));
        self.rect = self.image.get_rect();
        self.rect.topleft = (x,y);
    def update(self):
        pass
    def destroy(self):
        self.image = None;
        self.rect = None;
class Animbackground(pygame.sprite.DirtySprite):
    def __init__(self):
        pygame.sprite.DirtySprite.__init__(self);
        self.n = 0;
        self.frames = 30 / 6;
        self.bgSheet = SpriteStripAnim(A.MAINANIM, (0, 0, 1200, 900), 2, (0,0,0), True, self.frames);
        self.bgAnim = self.bgSheet;
        self.image = self.bgAnim.first();
        self.rect = self.image.get_rect();
    def update(self):
        self.image = self.bgAnim.next();
    def destroy(self):
        self.bgSheet = None;
        self.bgAnim = None;
        self.image = None;
        self.rect = None;
        self.n = None;
        self.frames = None;
        
class Foreground(pygame.sprite.DirtySprite):
    def __init__(self):
        pygame.sprite.DirtySprite.__init__(self);
        self.image = pygame.Surface.convert_alpha(pygame.image.load(A.MAINFOREGROUND));
        self.rect = self.image.get_rect();
        self.rect.topleft = (0,0);
    def update(self):
        pass;
    def destroy(self):
        self.image = None;
        self.rect = None;
        
class cMainMenu(cGameState):
    '''
    classdocs
    '''
    
    def __init__(self):
        '''
        Constructor
        '''
        # Backgroung music & audio
#         pygame.mixer.Sound(Audio.MUSICMAIN).play();
        self.fxOn = cGame.inst().cProgressSave.fxOn;
        self.btnPlaySnd = pygame.mixer.Sound(Audio.BTNPLAY);
        self.btnHoverSnd = pygame.mixer.Sound(Audio.BTNHOVER);
        self.playedHover = False;
        # Loading file & playing music
        pygame.mixer.music.load(Audio.MUSICMAIN);
        pygame.mixer.music.play();
        if(cGame.inst().cProgressSave.audioOn == False):
            pygame.mixer.music.pause();
        pygame.mouse.set_visible(False);
        self.display = cGame.inst().getDisplay();
        self.MENU = pygame.image.load(A.MAINFOREGROUND).convert();
        self.btnJugar = button.Button(A.BTNJUGAR, 442, 694);#720
        self.btnExit = button.Button(A.BTNCLOSE, 1050, 5);
        self.btnCredits = button.Button(A.BTNCREDITOS, 515, 815);
        self.mMouse = cMouse();
#         self.lastpos = 0;    
        self.bgAnim = Animbackground();
        #self.foreground = Foreground();
        self.allSprites = cGame.inst().getContainer();
        self.allSprites.add(self.bgAnim, self.btnExit, self.btnJugar, self.btnCredits);  
        self.audioBtns = cAudioBtns(self.allSprites);
        self.btnContinuar = button.Button(A.BTNCONTINUAR, 463, 606);
        self.restartPopUp = None;
        self.popUpVisible = False;
        self.btnContinuarVisible = False;
        self.config = cGame.inst().cProgressSave.config;
        if(self.config["firstTimeTuto"] != True):
            self.restartPopUp = RestartPopUp(132,425);
            self.allSprites.add(self.btnContinuar);
            self.btnContinuarVisible = True;
        self.allSprites.add(self.mMouse);#----Copy the The Menu background one time so it stays behind always---#
        self.display.blit(self.MENU, (0,0));
        pygame.display.flip();
#        self.keymap = {}
#         self.flipTimer = 0;
        self.allSprites.update();
        self.started = True;
           
    def eventUpdate(self):
        if(self.started):
            self.allSprites.update();
            for event in pygame.event.get():
                #handle basic events
                if event.type == pygame.QUIT:
                    cGame.inst().keepGoing = False;   
                if event.type == pygame.MOUSEMOTION:
                    if(self.fxOn):
                        if(self.btnJugar.mouseOver() or self.btnExit.mouseOver() or self.audioBtns.btnFx.mouseOver()
                           or self.audioBtns.btnMusic.mouseOver() or self.btnCredits.mouseOver() or (self.btnContinuar.mouseOver() and 
                                                                                                     self.btnContinuarVisible)):
                            if(self.playedHover != True):
                                self.playedHover = True;
                                self.btnHoverSnd.play();
                        else:
                            self.playedHover = False;
                if event.type==pygame.MOUSEBUTTONDOWN:
                    if(self.btnExit != None and self.btnExit.pressed()):
                        if(self.fxOn):
                            self.btnPlaySnd.play();
                        cGame.inst().keepGoing = False;
                    elif (self.audioBtns.btnFx != None and self.audioBtns.btnFx.pressed()):
                        self.audioBtns.btnFx.changeSetup();
                        self.fxOn = cGame.inst().cProgressSave.fxOn;
                    elif(self.audioBtns.btnMusic != None and self.audioBtns.btnMusic.pressed()):
                        self.audioBtns.btnMusic.changeSetup();
                    elif(self.btnCredits != None and self.popUpVisible == False and self.btnCredits.pressed()):
                        if(self.fxOn):
                            self.btnPlaySnd.play();
                        self.loadingTransition();
                        cGame.inst().setState(cCredits());
                    elif (self.btnJugar != None and self.popUpVisible == False and self.btnJugar.pressed()):
                        if(self.fxOn):
                            self.btnPlaySnd.play();
                        if(self.config["firstTimeTuto"]):
                            if(self.fxOn):
                                self.btnPlaySnd.play();
                            self.loadingTransition();
                            cGame.inst().setState(cDifficultySelect());
                        else:
                            if(self.fxOn):
                                self.btnPlaySnd.play();
                                #warning reset!
                            self.AddPopUp();
                    if(self.popUpVisible):
                        if(self.Clicked("cross")):
                            self.ErasePopUp();
                        elif(self.Clicked("tick")):
                            cGame.inst().cProgressSave.ResetValues();
                            self.loadingTransition();
                            cGame.inst().setState(cDifficultySelect());
                                    
                    if(self.btnContinuar != None and self.popUpVisible != True):
                        if(self.btnContinuar.pressed()):
                            if(self.fxOn):
                                self.btnPlaySnd.play();
                            self.loadingTransition();
                            cGame.inst().setState(cDifficultySelect());
                    
                    
                    
                
                        
    def update(self):
        #---Erase sprites from display and refill erased rectangles with the MENU background---#
        self.allSprites.clear(self.display, self.MENU);
        if(cGame.inst().cProgressSave.audioOn):
            if(pygame.mixer.music.get_busy() == False):
                pygame.mixer.music.play();
            
    def render(self):
        self.newPos = pygame.mouse.get_pos();

        #--- Draw and save sprite rectangles list ---#
        self.SpriteRectangles = self.allSprites.draw(self.display);
        #--- Pass sprite rectangles to display.update so it flips them to the display ---#
        
        pygame.display.update(self.SpriteRectangles);
    def Clicked(self, btn):
        self.mousePos = pygame.mouse.get_pos();
        if(btn == "cross"):
            if self.mousePos[0] > 783 and self.mousePos[1] > 426:
                if self.mousePos[0] < 892 and self.mousePos[1] < 535:
                        return True
            else: return False
            
        elif(btn == "tick"):
#            if self.mousePos[0] > 783 and self.mousePos[1] > 426:
            if self.mousePos[0] > 838 and self.mousePos[1] > 792:
                if self.mousePos[0] < 952 and self.mousePos[1] < 893:
                    return True
            else: return False
            

    def AddPopUp(self):
        if(self.restartPopUp not in self.allSprites):
            self.allSprites.remove(self.mMouse);
            self.allSprites.add(self.restartPopUp);
            self.allSprites.add(self.mMouse);
            self.popUpVisible = True;
    def ErasePopUp(self):
        self.popUpVisible = False;
        self.allSprites.remove(self.restartPopUp);
    def destroy(self):
        cGame.inst().cProgressSave.SaveValues();
        self.i = 0;
        while (self.i<len(self.SpriteRectangles)):
            self.SpriteRectangles[self.i] = None;
            self.i +=1;
        self.i = 0;
        self.SpriteRectangles = None;
        self.allSprites.empty();
        self.allSprites = None;
        self.bgAnim.destroy();
        self.bgAnim = None;
        if(self.restartPopUp != None):
            self.restartPopUp.destroy();
            self.restartPopUp = None;
        self.audioBtns.destroy();
        self.audioBtns = None;
        self.btnJugar.destroy();
        self.btnJugar = None;
        self.btnExit.destroy();
        self.btnExit = None;    
        self.btnContinuar.destroy();
        self.btnContinuar = None;
        self.btnContinuarVisible = None;
        self.btnCredits.destroy();
        self.btnCredits = None;
        self.mMouse.destroy();
        self.mMouse = None;
        self.MENU = None;
        self.display = None;
        self.btnPlaySnd = None;
        self.btnHoverSnd = None;
        self.fxOn = None;
        self.btnPlaySnd = None;
        self.btnHoverSnd = None;
        self.playedHover = None;
        self.display = None;
        self.config = None;
        self.popUpVisible = None;
        self.started = None;
    
        