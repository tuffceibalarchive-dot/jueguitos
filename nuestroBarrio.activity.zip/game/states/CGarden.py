# -*- coding: utf-8 -*- 

'''
Created on 14/03/2013

@author: Gus
'''
import pygame;
from api.CGameState import cGameState;
from api.CGame import cGame;
import game.states;
from api.CMap import cMap;
from api.CTutorial import Tutorial;
from CPlayer import Player;
from CGardenItem import cGardenItem;
from CGardenTimer import cGardenTimer;
from api.CGameMessage import cGameMessage;
from api.CPause import cPause;
from CMouse import cMouse;
import Assets.AudioAssets as Audio;
import random;

class cGarden(cGameState):
    

    def __init__(self, fromWhere):
        #load music and play
        self.fxOn = cGame.inst().cProgressSave.fxOn;
        pygame.mixer.music.load(Audio.MUSICGARDEN);
        pygame.mixer.music.play();
        self.fromWhere = fromWhere;
        if(cGame.inst().cProgressSave.audioOn == False):
            pygame.mixer.music.pause();
        #Load FX
        self.canillaSnd = pygame.mixer.Sound(Audio.CANILLA);
        self.basuraSnd = pygame.mixer.Sound(Audio.BASURA);
        self.contenedorSnd = pygame.mixer.Sound(Audio.CONTENEDOR);
        self.pedroOk1 = pygame.mixer.Sound(Audio.PEDROBIENHECHO);
        self.pedroOk2 = pygame.mixer.Sound(Audio.PEDROEXCELENTE);
        self.pedroDenuevo = pygame.mixer.Sound(Audio.PEDRODENUEVO);
        self.INTRO = 0;
        self.GAME = 1;
        self.END = 2;
        self.TUTO = 3;
        self.name = "garden";
        self.selectedCharacter = cGame.inst().cProgressSave.characterSelected;
        self.display = cGame.inst().getDisplay();
        self.garden = cMap("garden");        
        self.gardenSprites = cGame.inst().gardenSprites;
        self.tuto = None;
        self.message = None;       
#        self.mouse = A.mouse();
        pygame.mouse.set_visible(False);
        self.allSprites = cGame.inst().getContainer();
#        self.allSprites.add(self.mouse);
        self.player = Player(self.garden, (self.garden.returnPlayerStartX(), self.garden.returnPlayerStartY()));
        self.totalCanillas = 0;
        self.totalItems = 0; 
        self.totalItemsTaken = 0;
        self.totalCanillasClosed = 0;
        self.givePicture = False;
        
        for self.tileList in self.garden.tilesGarden:
            for self.tile in self.tileList:
                if(self.garden.getTileListIndex(self.tile) != self.garden.gardenExit):
                    if (self.tile.getTileIndex() == 2):
                        if((random.randint(1,5)) == 1):
                            self.indexName = 0;
                            self.item = random.randint(1, 4);
                            if(self.item == 1):
                                self.gardenItem = cGardenItem("botella", self.tile.mX, self.tile.mY, self.player, self); 
                                self.totalItems +=1;
                            elif(self.item == 2):
                                self.gardenItem = cGardenItem("papel", self.tile.mX, self.tile.mY, self.player, self);
                                self.totalItems +=1;
                            elif(self.item == 3):
                                self.gardenItem = cGardenItem("bolsa", self.tile.mX, self.tile.mY, self.player, self);
                                self.totalItems +=1;
                            elif(self.item == 4):
                                self.gardenItem = cGardenItem("canilla", self.tile.mX, self.tile.mY, self.player, self);
                                self.totalCanillas +=1;
                            self.allSprites.add(self.gardenItem);
                else:
                    self.gardenItem = cGardenItem("dumpster", self.tile.mX, self.tile.mY, self.player, self);
                    self.allSprites.add(self.gardenItem);
                        
        self.timer = cGardenTimer(self.allSprites, cGame.inst().cProgressSave.difficultySelected, self);
        self.allSprites.add(self.player);
        self.mouse = cMouse();
        self.mPause = cPause(self, self.mouse);
        pygame.display.flip();
        self.flipTimer = 0;
        self.started = False;
        self.start();
        
    def start(self):
        """ sets up the sprite groups
            begins the main loop """
        self.pause=False
        self.setState(self.TUTO)
        self.gardenSprites.draw(self.display);
        self.background = pygame.display.get_surface();
        self.background = self.background.convert();
        self.display.blit(self.background, (0,0));
        pygame.display.flip();
        self.started = True;
    def eventUpdate(self):
        if(self.started):
            if(self.pause != True):
                if(self.message == None and self.gameState == self.GAME):
                    self.allSprites.update();
                for event in pygame.event.get():
                    #handle basic events
                    if event.type == pygame.QUIT:
                        cGame.inst().keepGoing = False;
                    if event.type==pygame.KEYDOWN:
                        if event.key==pygame.K_ESCAPE:
                            self.pause = True;
                        if event.key==pygame.K_SPACE:
                            if(self.message != None):
                                self.removeMessage();
                                if(self.gameState == self.INTRO):
                                    self.setState(self.GAME);
                            if(self.tuto != None):
                                self.removeTuto();
                                if(self.gameState == self.TUTO):
                                    self.allSprites.clear(self.display, self.background);
                                    self.setState(self.INTRO);
                        pygame.event.clear();
            else:
                self.pauseLogic();
                            
    def update(self): 
        if(self.pause != True):   
            self.allSprites.clear(self.display, self.background);
        #   self.collidingSprites = pygame.sprite.spritecollide(self.player, self.allSprites, False);        
            for self.sprite in self.allSprites:
                if(self.sprite.isDead):
                    if(self.fxOn):
                        self.basuraSnd.play();
                    self.sprite.destroy();
                    self.allSprites.remove(self.sprite);
                    self.totalItemsTaken += 1;
                               
            if((self.player.centerX, self.player.upY) == self.garden.gardenExit):
                self.player.auto = True;
                self.player.rect.centerx += self.player.velx;
                self.player.image = self.player.walkRight[self.player.n].next();
                
                if ((self.player.rect.midleft) >= (1300,0)):
                    self.gameWon = True;
                    self.gameEnd();
                                               
            elif(self.timer.rect.right <= 20):
                self.gameWon = False;
                self.gameEnd();
        else:
            self.mPause.spriteList.clear(self.display, self.background);
        if(cGame.inst().cProgressSave.audioOn):
            if(pygame.mixer.music.get_busy() == False):
                pygame.mixer.music.play();
 
          
        #---------------------------------------------------------#        
    def render(self):
        if(self.pause != True):
            self.flipTimer += 1;
            self.SpriteRectangles = self.allSprites.draw(self.display);
            pygame.display.update(self.SpriteRectangles);
            if(self.flipTimer >= 30):
                self.display.blit(self.background, (0,0));
                for self.sprite in self.allSprites:
                    self.display.blit(self.sprite.image, (self.sprite.rect.topleft))
                pygame.display.flip();
                self.flipTimer = 0; 
        else:
            self.SpriteRectangles = self.mPause.spriteList.draw(self.display);
            pygame.display.update(self.SpriteRectangles);
   
    def pauseLogic(self):
        self.mPause.spriteList.update();
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    self.pause = False;
                    self.display.blit(self.background, (0,0));
                    pygame.display.flip();
            if event.type == pygame.MOUSEBUTTONDOWN:
                if(self.mPause.btnContinue.pressed()):
                    self.pause = False;
                    self.display.blit(self.background, (0,0));
                    pygame.display.flip();      
                elif(self.mPause.btnQuit.pressed()):
                    self.loadingTransition();
                    cGame.inst().setState(game.states.CInterval.cInterval("gardenInterval", exited = True));
                elif self.mPause.audioBtns.btnFx.pressed():
                    self.mPause.audioBtns.btnFx.changeSetup();
                    self.fxOn = cGame.inst().cProgressSave.fxOn;
                elif(self.mPause.audioBtns.btnMusic.pressed()):
                    self.mPause.audioBtns.btnMusic.changeSetup();
            
    def setState(self, aState):
        self.gameState = aState;
        if(self.gameState == self.INTRO):
            self.gameIntro();
        elif(self.gameState == self.TUTO):
            self.createTuto();
        elif(self.gameState == self.GAME):
            pass;
        
    def removeTuto(self):
        self.tuto.destroy();
        self.tuto = None;   
    
    def createTuto(self):
        self.tuto = Tutorial(self.allSprites, self);
                    
    def gameIntro(self):
        self.message = cGameMessage("garden", ["Cuando est"+u"é".format(unichr(0xc3))+"s listo", "presiona la barra", "espaciadora para", "comenzar la partida."], self );
    
    def removeMessage(self):
        self.allSprites.remove(self.message.sign, self.message.bust, self.message.text);
        self.message.destroy();
        self.message = None;

    def gameEnd(self):
        if(self.message == None and self.gameState == self.GAME):
            if(self.gameWon != True):
                if(cGame.inst().cProgressSave.fxOn):
                    self.pedroDenuevo.play();
                self.message = cGameMessage("garden", [u"¡".format(chr(0xc3)) + "Se acab" + u"ó".format(chr(0xc3)) + "el tiempo!",
                                                       "Prueba denuevo."], self);
            elif(self.gameWon):    
                self.playGreet();
                self.message = cGameMessage("garden", [u"¡".format(chr(0xc3)) + "Lo has logrado!", "Tambi" + u"é".format(chr(0xc3)) + "n has tomado: ",
                                                        str(self.totalItemsTaken) + " de " + str(self.totalItems) + " basuras",
                                                         "y has cerrado: " + str(self.totalCanillasClosed) + " de " + str(self.totalCanillas),
                                                          "canillas."], self);
                 
            self.gameState = self.END;
            
        elif(self.message == None and self.gameState == self.END):
            if(self.gameWon):
                if(self.fromWhere < 2):
                    if(self.fromWhere == 0):
                        if(cGame.inst().cProgressSave.pics["garden01"] == False):
                            cGame.inst().cProgressSave.newPic = True;
                            cGame.inst().UnlockPic("garden01"); 
                    self.GetPerformance();
                    self.loadingTransition();
                    cGame.inst().setState(game.states.CGarden.cGarden((self.fromWhere + 1)));
                else:
                    if(cGame.inst().cProgressSave.pics["garden02"] == False):        
                        cGame.inst().cProgressSave.newPic = True;
                        cGame.inst().UnlockPic("garden02");
                    cGame.inst().cProgressSave.stagesPassed["garden"] = True;
                    self.GetPerformance();
                    self.loadingTransition();
                    cGame.inst().setState(game.states.CInterval.cInterval("gardenInterval", True));
            else:
                self.loadingTransition();
                cGame.inst().setState(game.states.CInterval.cInterval("gardenInterval", exited = True));
           
    def playGreet(self):
        if(cGame.inst().cProgressSave.fxOn):
            self.randomNum = random.randint(0,1);
            if(self.randomNum == 0):
                self.pedroOk1.play();
            else:
                self.pedroOk2.play();        
    def GetPerformance(self):
        self.Percentage = (self.totalCanillasClosed + self.totalItemsTaken) * 100 / (self.totalCanillas + self.totalItems);
        self.tmpPercentage = 0;
        if(self.Percentage < 40):
            self.tmpPercentage = 1;
        elif(self.Percentage >= 41 and self.Percentage < 70):
            self.tmpPercentage = 2;
        elif(self.Percentage >= 71):
            self.tmpPercentage = 3;
        if(self.tmpPercentage > cGame.inst().cProgressSave.gardenScore[self.fromWhere]):
            cGame.inst().cProgressSave.gardenScore[self.fromWhere] = self.tmpPercentage;
        if(cGame.inst().cProgressSave.stagesPassed["garden"]):
            self.rateToDeliver = cGame.inst().cProgressSave.GetPerformanceRate("garden");
            cGame.inst().cProgressSave.gardenRate = self.rateToDeliver;
    def destroy(self):
        cGame.inst().cProgressSave.SaveValues();
        self.SpriteRectangles = None;
        self.allSprites.empty();
        self.allSprites = None;
        self.gardenSprites.empty();
        self.gardenSprites = None;
        self.player.destroy();
        self.player = None;
        self.mouse.destroy();
        self.mouse  = None;
        self.mPause.destroy();
        self.mPause = None;
        self.display = None;
        self.garden.destroy();
        self.garden = None;
        self.loading = None;
        self.timer = None;
        self.canillaSnd = None;
        self.contenedorSnd = None;
        self.basuraSnd = None;
        self.INTRO = None;
        self.GAME = None;
        self.END = None;
        self.TUTO = None;
        self.name = None;
        self.selectedCharacter = None;
        self.started = None;
        self.totalCanillas = None;
        self.totalItems = None; 
        self.totalItemsTaken = None;
        self.totalCanillasClosed = None;
        self.givePicture = None;  
        self.timer = None;      
        self.pause = None;  
        self.background = None;
        self.pedroOk1 = None;
        self.pedroOk2 = None;
        self.pedroDenuevo = None;
        self.flipTimer = None;
        pygame.mixer.music.stop();

