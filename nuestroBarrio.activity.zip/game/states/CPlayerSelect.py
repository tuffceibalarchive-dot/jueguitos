'''
Created on 21/02/2013

@author: Gus
'''

from api.CGameState import cGameState;
import pygame;
from api.CGame import cGame;
#from api.CGameObject import cGameObject;
from game.states.CLevelState import cLevelState;
import Assets.Assets as A; 
import Assets.button as button;
from api.CSpriteSheet import spritesheet;
from api.CText import cText;
from CMouse import cMouse;

class PlayerThumb(pygame.sprite.Sprite):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self);
        self.charSheet = spritesheet(A.CHARACTERSPRITESHEET);
        self.charList = self.charSheet.load_strip((0, 0, 240, 480), 6, colorkey = (0,0,0));
        self.charSelected = cGame.inst().cProgressSave.characterSelected;
        self.image =  self.charList[self.charSelected];
        self.rect = self.image.get_rect();        
        self.setCords((x, y));
    
    def update(self):
        self.charSelected = cGame.inst().cProgressSave.characterSelected;        
        self.image =  self.charList[self.charSelected];
               
    def setCords(self, coords):
        """coords is a tuple with the format (x, y)"""
        self.rect.topleft = coords;
    def destroy(self):
        self.charSheet = None;
        self.charList = None;
        self.charSelected = None;
        self.image = None;
        self.rect = None

class cPlayerSelect(cGameState):
    '''
    classdocs
    '''
    
    def __init__(self):
        '''
        Constructor
        '''

        pygame.mouse.set_visible(False);
        self.display = cGame.inst().getDisplay();
        self.MENU = A.playerSelection;
        self.charSelected = 0;
        cGame.inst().cProgressSave.characterSelected = 0;
        self.buttonClick = True;
        #-----------Player Buttons--------------#
        self.player_1c = button.Button(A.PLAYER_1C, 100, 700);
        self.player_2c = button.Button(A.PLAYER_2C, 250, 650);
        self.player_3c = button.Button(A.PLAYER_3C, 450, 600);
        self.player_4c = button.Button(A.PLAYER_4C, 650, 600);
        self.player_5c = button.Button(A.PLAYER_5C, 850, 650);
        self.player_6c = button.Button(A.PLAYER_6C, 1000, 700);
        
        self.playerThumbs = PlayerThumb(100,0);
        #---------------------------------#
        
        #----------------SpriteSheetRecorte------------#
        #    Player big sprite size 240x480
        self.mMouse = cMouse();    
#         self.lastpos = 0;
        self.allSprites = cGame.inst().getContainer();
        self.allSprites.add(self.player_1c, self.player_2c, self.player_3c,
                             self.player_4c, self.player_5c, self.player_6c, self.playerThumbs);
        self.playerName = cText("ALE", 1, None, 100, self.allSprites);
        self.btnGoTown = button.Button(A.BTNGOTOTOWN, 580, 790);
        self.playerName.setCoords(400, 200);
        self.allSprites.add(self.btnGoTown, self.mMouse);
        
        #----Copy the The Menu background one time so it stays behind always---#
        self.display.blit(self.MENU, (0,0));
        pygame.display.flip();
        self.flipTimer = 0;
        self.allSprites.update();
        self.started = True;

    def update(self):
        #---Erase sprites from display and refill erased rectangles with the MENU background---#
        self.allSprites.clear(self.display, self.MENU);
        if(pygame.mixer.music.get_busy() == False):
            pygame.mixer.music.play();
            
    def render(self):
        self.flipTimer += 1;
        self.newPos = pygame.mouse.get_pos();
        self.SpriteRectangles = self.allSprites.draw(self.display);
            #--- Pass sprite rectangles to display.update so it flips them to the display ---#
        pygame.display.update(self.SpriteRectangles);
        if(self.flipTimer >= 30):
            self.display.blit(self.MENU, (0,0));
            for self.sprite in self.allSprites:
                self.display.blit(self.sprite.image, (self.sprite.rect.topleft))
            pygame.display.flip();
            self.flipTimer = 0;
        
        
    def destroy(self):
        self.allSprites.empty();
        self.allSprites = None;
        self.i = 0;
        while(self.i<len(self.SpriteRectangles)):
            self.SpriteRectangles[self.i] = None;
            self.i +=1;
        self.i = None;
        self.SpriteRectangles = None;
        self.player_1c.destroy();
        self.player_1c = None;
        self.player_2c.destroy();
        self.player_2c = None;
        self.player_3c.destroy();
        self.player_3c = None;
        self.player_4c.destroy();
        self.player_4c = None;
        self.player_5c.destroy();
        self.player_5c = None;
        self.player_6c.destroy();
        self.player_6c = None;
        self.playerName.destroy();
        self.playerName = None;
        self.playerThumbs.destroy();
        self.playerThumbs = None;
        self.display = None;
        self.MENU = None;
        self.mMouse.destroy();
        self.mMouse = None;
        self.charList = None;
        self.charSheet = None;
        self.loading = None;
        self.btnGoTown.destroy();
        self.btnGoTown = None;
        self.started = None;
        pygame.mixer.stop();
                
    def eventUpdate(self):
        if(self.started):
            self.allSprites.update();
            for event in pygame.event.get():
                #handle basic events
                if event.type == pygame.QUIT:
                    cGame.inst().keepGoing = False;
#                 if(event.type == pygame.KEYDOWN):
#                     if(event.key == pygame.K_1):
#                         self.loadingTransition();
#                         cGame.inst().setState(cLevelState());                     
                if event.type==pygame.MOUSEBUTTONDOWN:
                    
                    self.buttonClick = True;
                    
                    if (self.player_1c != None and self.player_1c.pressed()):
                        self.clearNameSprite();
                        self. playerName = cText("ALE", 1, None, 100, self.allSprites);
                        cGame.inst().cProgressSave.characterSelected = 0;
                        
                    elif(self.player_2c != None and self.player_2c.pressed()):
                        self.clearNameSprite();
                        self. playerName = cText("CLARITA", 1, None, 100, self.allSprites);
                        cGame.inst().cProgressSave.characterSelected = 1;
                    elif(self.player_3c != None and  self.player_3c.pressed()):
                        self.clearNameSprite();
                        self. playerName = cText("TITO", 1, None, 100, self.allSprites);
                        cGame.inst().cProgressSave.characterSelected = 2;
                    elif(self.player_4c != None and self.player_4c.pressed()):
                        self.clearNameSprite();
                        self. playerName = cText("JULI", 1, None, 100, self.allSprites);
                        cGame.inst().cProgressSave.characterSelected = 3;
                    elif(self.player_5c !=None and self.player_5c.pressed()):
                        self.clearNameSprite();
                        self. playerName = cText("NACHO", 1, None, 100, self.allSprites);
                        cGame.inst().cProgressSave.characterSelected = 4;
                    elif(self.player_6c != None and self.player_6c.pressed()):
                        self.clearNameSprite();
                        self. playerName = cText("MACA", 1, None, 100, self.allSprites);
                        cGame.inst().cProgressSave.characterSelected = 5;
                    self.playerName.setCoords(400, 200);
                    self.charSelected = cGame.inst().cProgressSave.characterSelected;
                    if(self.btnGoTown != None and self.btnGoTown.pressed()):
                        self.loadingTransition();
                        cGame.inst().setState(cLevelState());
                

    def clearNameSprite(self):
        self.allSprites.remove(self.playerName);
        self.playerName = None;
                    
                    
                    