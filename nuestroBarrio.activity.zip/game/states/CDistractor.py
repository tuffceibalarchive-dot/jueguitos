'''
Created on 27/03/2013

@author: Gus
'''
import pygame;
from api.CGameState import cGameState
import game.states.CInterval;
from api.CGame import cGame;
#from api.CGameObject import cGameObject;
import Assets.Assets as A; 
import Assets.AudioAssets as Audio;
from CMouse import cMouse; 
from CCard  import  cCard;
import random;

class cDistractor(cGameState):
    '''
    classdocs
    '''


    def __init__(self, neighbour):
        '''
        Constructor
        '''
        #Load music and start playing
        self.fxOn = cGame.inst().cProgressSave.fxOn;
        pygame.mixer.music.load(Audio.MUSICDISTRACTOR);
        pygame.mixer.music.play();
        if(cGame.inst().cProgressSave.audioOn == False):
            pygame.mixer.music.pause();
        #Load FX
        self.pairMatch = pygame.mixer.Sound(Audio.PAIRMATCH);
        self.showCard = pygame.mixer.Sound(Audio.SHOWCARD);
        self.ups1 = pygame.mixer.Sound(Audio.PIQUITOUPS1);
        self.ups2 = pygame.mixer.Sound(Audio.PIQUITOUPS2);
        self.INTRO = 0;
        self.GAME = 1;
        self.END = 2;
        self.gameState = None;
        self.name = "distractor";
        self.display = cGame.inst().getDisplay();
        self.background = A.distractorBackground;
        self.mNeighbour = neighbour;
        self.difficultySelected = cGame.inst().cProgressSave.difficultySelected;
        self.createHand();
        self.mMouse = cMouse();    
        self.lastpos = 0;
        self.allSprites = cGame.inst().getContainer();
        self.allSprites.add(self.cardsList);
        self.allSprites.add(self.mMouse);
        self.SpriteRectangles = None;
        self.flipTimer = 0;
        self.started = False;
        self.start();
#        CGame.cGame.CGameIntFace.addToContainer(self.mMainMenu);
    def start(self):
        """ sets up the sprite groups
            begins the main loop """
        self.pause=False
        self.buttonPressed = False;
        self.targetFound = False;
        self.allShowed = False;
        self.endingTimer = 0;
        self.gameState = self.GAME;   
        self.message = None;
        #----Copy the The Menu background one time so it stays behind always---#
        self.display.blit(self.background, (0,0));
        pygame.display.flip();
        self.started = True;
         
    def update(self):        
        if(self.message == None and self.gameState== self.GAME):
            #---Erase sprites from display and refill erased rectangles with the MENU background---#       
            self.allSprites.clear(self.display, self.background); 
            if(self.allSprites != None):
                self.allSprites.update(); 
            if(self.selectedCards != None and len(self.selectedCards) >= 2):
                self.checkMatch();
            if(self.targetFound):
                self.endGame();
            
        if(cGame.inst().cProgressSave.audioOn):
            if(pygame.mixer.music.get_busy() == False):
                pygame.mixer.music.play();     
            
    def render(self):    
        if(self.pause != True):
            self.flipTimer += 1;
            self.SpriteRectangles = self.allSprites.draw(self.display);
            pygame.display.update(self.SpriteRectangles);
            if(self.flipTimer >= 30):
                self.display.blit(self.background, (0,0));
                for self.sprite in self.allSprites:
                    self.display.blit(self.sprite.image, (self.sprite.rect.topleft))
                pygame.display.flip();
                self.flipTimer = 0; 
                
    def eventUpdate(self):
        if(self.started):
            for event in pygame.event.get():
                #handle basic events
                if(len(self.selectedCards) < 2):
                    if event.type == pygame.MOUSEBUTTONDOWN:
                        for self.card in self.cardsList:
                            if(self.card.pressed()):
                                if(self.card not in self.selectedCards):
                                    if(self.card.hasMatch == False):
                                        if(self.fxOn):
                                            self.showCard.play();
                                        self.card.isSelected = True;
                                        self.selectedCards.append(self.card);
                                        
                if event.type == pygame.QUIT:
                    cGame.inst().keepGoing = False;
                if event.type==pygame.KEYDOWN:
                    if event.key==pygame.K_SPACE:
                        if(self.message != None):
                            self.removeMessage();
                            if(self.gameState == self.INTRO):
                                self.gameState = self.GAME;

                  
        
                              
    def checkMatch(self):
        self.showTime +=1;
        if(self.showTime > 15):
            if(self.selectedCards[0].mNumberType == self.selectedCards[1].mNumberType):
                for self.card in self.cardsList:
                    if(self.card.mNumberType == self.selectedCards[0].mNumberType):
                        if(self.fxOn):
                            self.pairMatch.play();
                        self.card.hasMatch = True;
                        if(self.card.mNumberType == self.target):
                            self.targetFound = True;
                            
            else:
                for self.card in self.cardsList:
                    self.card.isSelected = False;
                self.PlayUps();
            self.selectedCards[:] = [];
            self.showTime = 0;          
                          
    
    def endGame(self):
        self.endingTimer += 1;
        if(self.allShowed != True):
            for self.card in self.cardsList:
                self.card.hasMatch = True;
            self.allShowed = True;
        if(self.endingTimer >= 4 * 30):
            self.NeighbourPrize();
            self.loadingTransition();
            cGame.inst().setState(game.states.CInterval.cInterval("distractorInteval", True));
    
    def NeighbourPrize(self):
        self.picLst = cGame.inst().cProgressSave.pics;
        if(self.mNeighbour == 0 and self.picLst["vecino01"] == False):
            cGame.inst().UnlockPic("vecino01");
            cGame.inst().cProgressSave.newPic = True;
        elif(self.mNeighbour == 1 and self.picLst["vecino00"] == False):
            cGame.inst().UnlockPic("vecino00");
            cGame.inst().cProgressSave.newPic = True;
        elif(self.mNeighbour == 2 and self.picLst["vecino02"] == False):
            cGame.inst().UnlockPic("vecino02");
            cGame.inst().cProgressSave.newPic = True;
        elif(self.mNeighbour == 3 and self.picLst["vecino03"] == False):
            cGame.inst().UnlockPic("vecino03");
            cGame.inst().cProgressSave.newPic = True;
        elif(self.mNeighbour == 4 and self.picLst["vecino04"] == False):
            cGame.inst().UnlockPic("vecino04");
            cGame.inst().cProgressSave.newPic = True;
            
    def PlayUps(self):
        self.random = random.randint(0,1);
        if(self.random == 0):
            self.ups1.play();
        elif(self.random ==1):
            self.ups2.play();
    def destroy(self):
        cGame.inst().cProgressSave.SaveValues();
        self.fxOn = None;
        self.SpriteRectangles = None;
        self.allSprites.empty();
        self.allSprites = None;
        self.selectedCards = None;
        self.display = None;
        self.background = None;
        self.mMouse = None;
        self.loading = None;
        self.i = 0;
        while(self.i < len(self.cardsList)):
            self.cardsList[self.i].destroy();
            self.cardsList[self.i] = None;
            self.i += 1;
        self.i = None;
        self.cardsList = None;
        self.mNeighbour = None;
        self.name = None;
        self.INTRO = None;
        self.END = None;
        self.GAME = None;
        self.gameState = None;
        self.difficultySelected = None;
        self.lastpos = None;
        self.flipTimer = None;
        self.pause=None
        self.started = None;
        self.buttonPressed = None;
        self.targetFound = None;
        self.allShowed = None;
        self.endingTimer = None;
        self.showTime = None;
        self.dist = None;
        self.upperRowPos = None;
        self.lowerRowPos = None;
        self.j = 0;
        while(self.j < len(self.upper)):
            self.upper[self.j] = None;
            self.lower[self.j] = None;
            self.j+=1;
        self.j = None;
        self.upper = None;
        self.lower = None;
        self.pairMatch = None;
        self.showCard = None;
        self.target = None;
        self.ups1 = None;
        self.ups2 = None;
        self.started = None;
        pygame.mixer.music.stop();
        
    def createHand(self):
        #----------------create both numeric and sprite cards rows-------------------# 
        self.upper = [];
        self.lower = [];
        self.cardsList = [];
        self.selectedCards = [];
        self.showTime = 0;
        self.dist = 0;
        self.upperRowPos = (0,0);
        self.lowerRowPos = (0,0);
        self.i = 0;

        
        if(self.difficultySelected == 1):
            self.upperRowPos = (350, 200);
            self.lowerRowPos = (350, 450);
            while self.i < 1:
                self.n = random.randint(0, 24);
                if(self.n not in self.upper):
                    self.upper.append(self.n);
                    self.upper.append(self.n);
                    self.i +=1;
            
            self.dist = 250;
 
        elif(self.difficultySelected == 2):
            self.upperRowPos = (250, 200);
            self.lowerRowPos = (250, 450);
            
            while self.i < 2:
                self.n = random.randint(0, 24);
                if(self.n not in self.upper):
                    self.upper.append(self.n);
                    self.upper.append(self.n);
                    self.i +=1;
            self.dist = 220;
                           
        elif(self.difficultySelected == 3):
            self.upperRowPos = (190, 200);
            self.lowerRowPos = (190, 450);
            
            while self.i < 3:
                self.n = random.randint(0, 24);
                if(self.n not in self.upper):
                    self.upper.append(self.n);
                    self.upper.append(self.n);
                    self.i +=1;
            self.dist = 210;
        
        if(self.mNeighbour == 0):
            self.target = 25;
        elif(self.mNeighbour == 1):
            self.target = 26;
        elif(self.mNeighbour == 2):
            self.target = 27;
        elif(self.mNeighbour == 3):
            self.target = 28;
        elif(self.mNeighbour == 4):
            self.target = 29;
        self.upper.append(self.target);
        self.upper.append(self.target);
        random.shuffle(self.upper);
        self.lower = self.upper[:int(len(self.upper)/2)];
        self.upper = self.upper[int(len(self.upper)/2):]; 
        
        self.s = 0;
        while self.s <= len(self.upper) - 1:
            self.card = cCard(self.upper[self.s], (self.upperRowPos[0] + (self.s * self.dist), self.upperRowPos[1]), self);
            self.cardsList.append(self.card);
            self.s += 1;
        
        self.h = 0;
        while self.h <= len(self.lower) - 1:
            self.card = cCard(self.lower[self.h], (self.lowerRowPos[0] + (self.h * self.dist), self.lowerRowPos[1]), self);
            self.cardsList.append(self.card);
            self.h += 1;
            