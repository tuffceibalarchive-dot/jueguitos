# -*- coding: utf-8 -*- 

'''
Created on 31/12/2012

@author: Gus
'''
import pygame;
from api.CGameState import cGameState;
from api.CGame import cGame;
from api.CGameMessage import cGameMessage;
from api.CPause import cPause;
from CMouse import cMouse;
import Assets.Assets as A; 
import Assets.AudioAssets as Audio;
from api.CMap import cMap;
from CPlayer import Player;
from api.CSpriteSheet import spritesheet;
from api.CTutorial import Tutorial;
import game.states.CGarden;
import game.states.CMuseum;
import game.states.CCircus;
import game.states.CDistractor;
import game.states.CFarm;
import random;
        
class Dialogo(pygame.sprite.DirtySprite):
    def __init__(self):
        pygame.sprite.DirtySprite.__init__(self);
        self.image = pygame.Surface.convert_alpha(pygame.image.load(A.DIALOGOINTERVAL));
        self.rect = self.image.get_rect();
        self.rect.topleft = (558, 115);
        
    def destroy(self):
        self.image = None;
        self.rect = None;
        
class intervalForeground(pygame.sprite.Sprite):
    def __init__(self, foregroundType):
        pygame.sprite.Sprite.__init__(self);
        if(foregroundType == "garden"):
            self.image = pygame.Surface.convert_alpha(pygame.image.load(A.GARDENINTERVALSIGNS));    
        elif(foregroundType == "circus"):
            self.image = pygame.Surface.convert_alpha(pygame.image.load(A.CIRCOCRATES));
        elif(foregroundType == "museum"):
            self.image = pygame.Surface.convert_alpha(pygame.image.load(A.MUSEUMTREE));
        elif(foregroundType == "distractor"):
            self.image = pygame.Surface.convert_alpha(pygame.image.load(A.DISTRACTORSIGN));  
        elif(foregroundType == "farm"):
            self.image = pygame.Surface.convert_alpha(pygame.image.load(A.FARMSIGN));
       
        self.rect = self.image.get_rect();    
    def setCords(self,x,y):
        self.rect.topleft = x,y;
    def destroy(self):
        self.image = None;
        self.rect = None;
        
class Neighbour(pygame.sprite.DirtySprite):
    def __init__(self, neighbourType):
        pygame.sprite.DirtySprite.__init__(self);
        self.mNeighbourType = neighbourType;
        self.neighbourSheet = spritesheet(A.NEIGHBOURSHEET);
        self.neighbourList = self.neighbourSheet.load_strip((0, 0, 185, 345), 5, colorkey = (0,0,0));
        
        if(self.mNeighbourType == 0):
            self.image = pygame.Surface.convert_alpha((self.neighbourList[0]));
        elif(self.mNeighbourType == 1):
            self.image = pygame.Surface.convert_alpha((self.neighbourList[1]));
        elif(self.mNeighbourType == 2):
            self.image = pygame.Surface.convert_alpha((self.neighbourList[2]));
        elif(self.mNeighbourType == 3):
            self.image = pygame.Surface.convert_alpha((self.neighbourList[3]));
        elif(self.mNeighbourType == 4):
            self.image = pygame.Surface.convert_alpha((self.neighbourList[4]));
        self.rect = self.image.get_rect();
        self.setCoords(875,270);
        
    def setCoords(self, x, y):
        self.rect.topleft = (x,y);
    def destroy(self):
        self.neighbourSheet = None;
        self.neighbourList = None;
        self.image = None;
        self.rect = None;
        
class cInterval(cGameState):
    
    
    def __init__(self, intervalType, isEnded = False, exited = False):
#        pygame.key.set_repeat(15, 15)
        #loqd interval music and start playing
        self.isEnded = isEnded;
        if(self.isEnded or exited):
            pygame.mixer.music.load(Audio.MUSICINTERVALS);
            pygame.mixer.music.play();
        if(cGame.inst().cProgressSave.audioOn == False):
            pygame.mixer.music.pause();
        
        self.INTRO = 0;
        self.GAME = 1;
        self.END = 2;
        self.TUTO = 3;
        self.intervalType = intervalType;
        self.name = "interval";
        self.map = cMap("interval");
        self.selectedCharacter = cGame.inst().cProgressSave.characterSelected;
        self.display = cGame.inst().getDisplay();
        self.neighbour = None;
        self.helpText = None;
        self.neighbourNumber = 0;
        self.distractorDialog = None;
        self.intervalVoice = None;
        self.mouse = cMouse();   
        self.mPause = cPause(self, self.mouse);
        if(self.isEnded):
            self.map.distractorEnded = True;
        if(self.intervalType == "gardenInterval"):
            # Backgroung music
#             self.music = Audio.MUSICGARDEN;
            self.intervalMap = A.gardenInterval;        
            self.foreground = intervalForeground("garden");
            self.foreground.setCords(744, 637);   
            if(self.isEnded):
                self.intervalVoice = pygame.mixer.Sound(Audio.PEDROGRACIAS);
            else:
                self.intervalVoice = pygame.mixer.Sound(Audio.PEDROBIENVENIDA);  
        elif(self.intervalType == "circusInterval"):
#             self.music = Audio.MUSICCIRCUS;
            self.intervalMap = A.circoInterval;
            self.foreground =  intervalForeground("circus");
            self.foreground.setCords(421, 618);     
            if(self.isEnded):
                self.intervalVoice = pygame.mixer.Sound(Audio.FATIMAGRACIAS);
            else:
                self.intervalVoice = pygame.mixer.Sound(Audio.FATIMABIENVENIDA);                
            
        elif(self.intervalType == "museumInterval"):
#             self.music = Audio.MUSICMUSEUM;
            self.intervalMap = A.museumInterval;
            self.foreground = intervalForeground("museum");
            self.foreground.setCords(723, 570);
            if(self.isEnded):
                self.intervalVoice = pygame.mixer.Sound(Audio.JAIMEGRACIAS);
            else:
                self.intervalVoice = pygame.mixer.Sound(Audio.JAIMEBIENVENIDA);    
        elif(self.intervalType == "farmInterval"):
#             self.music = Audio.MUSICFARM;
            self.intervalMap = A.farmInterval;
            self.foreground = intervalForeground("farm");
            self.foreground.setCords(50, 600);
            if(self.isEnded):
                self.intervalVoice = pygame.mixer.Sound(Audio.LAURAGRACIAS);
            else:
                self.intervalVoice = pygame.mixer.Sound(Audio.LAURABIENVENIDA);         
        elif(self.intervalType == "distractorInteval"):
#             self.music = Audio.MUSICTOWN;
            self.intervalMap = A.distractorInterval;
            self.foreground = intervalForeground("distractor");
            self.foreground.setCords(800, 637);
            self.distractorDialog = Dialogo();    
            if(self.isEnded != True):
                if(len(cGame.inst().cProgressSave.toHelpList) <= 0):
                    self.randomNum = random.randint(0, 4);
                    self.neighbourNumber = self.randomNum;
                else:
                    self.randomNum = random.randint(0, (len(cGame.inst().cProgressSave.toHelpList)-1));
                    self.neighbourNumber = cGame.inst().cProgressSave.toHelpList.pop(self.randomNum);
                self.neighbour = Neighbour(self.neighbourNumber);
                if(self.neighbourNumber == 0):
                    self.intervalVoice = pygame.mixer.Sound(Audio.PIQUITOABUELO);
                elif(self.neighbourNumber == 1):
                    self.intervalVoice = pygame.mixer.Sound(Audio.PIQUITOPERRITO); 
                elif(self.neighbourNumber == 2):
                    self.intervalVoice = pygame.mixer.Sound(Audio.PIQUITOBIBLIOTECA); 
                elif(self.neighbourNumber == 3):
                    self.intervalVoice = pygame.mixer.Sound(Audio.PIQUITOBOLSA);  
                elif(self.neighbourNumber == 4):
                    self.intervalVoice = pygame.mixer.Sound(Audio.PIQUITOBILLETERA);  
            else:
                self.playGreet();
                
        self.player = Player(self.map, (600, 600));
        self.player.setVel(9, 9)
        self.allSprites = cGame.inst().getContainer();
        if(self.neighbour != None):
            self.allSprites.add(self.neighbour);  
            
        self.allSprites.add(self.player);
        self.allSprites.add(self.foreground);
        self.flipTimer = 0;
        self.message = None;
        self.tuto = None;
        self.started = False;
        self.start();
        
    def start(self):
        """ sets up the sprite groups
            begins the main loop """
        self.pause=False
        self.setState(self.INTRO);
        if(cGame.inst().cProgressSave.fxOn):
            self.intervalVoice.play();
        self.display.blit(self.intervalMap, (0,0));
        pygame.display.flip();
        self.started = True;
    def eventUpdate(self):
        if(self.started):
            if(self.pause != True):
                if(self.message == None and self.gameState == self.GAME):
                    self.allSprites.update();
        
                for event in pygame.event.get():
                    #handle basic events
                    if event.type == pygame.QUIT:
                        cGame.inst().keepGoing = False;
                    if event.type == pygame.KEYDOWN:
                        if event.key==pygame.K_ESCAPE:
                            self.pause = True;
                        if event.key==pygame.K_SPACE:
                            if(self.tuto != None):
                                self.removeTuto();
                                if(self.gameState == self.TUTO):
                                    self.setState(self.GAME);
                            if(self.message != None):
                                self.removeMessage();
                                if(self.gameState == self.INTRO):
                                    self.setState(self.TUTO);    
                           
            else:
                self.pauseLogic();
                            
    def update(self):
        if(self.pause != True):
            self.allSprites.clear(self.display, self.intervalMap);
            self.checkNeighbour();
            self.checkAutoMove();
            self.checkExits();    
#                if(cGame.inst().cProgressSave.circOpen == True and cGame.inst().cProgressSave.museumOpen == True):
#                    cGame.inst().cProgressSave.gardenOpen = True;
        else:
            self.mPause.spriteList.clear(self.display, self.intervalMap);
            
        if(cGame.inst().cProgressSave.audioOn):
            if(pygame.mixer.music.get_busy() == False):
                pygame.mixer.music.play();
            
        #---------------------------------------------------------#        
    def render(self):
        if(self.pause != True):
            self.flipTimer +=1;
            self.SpriteRectangles = self.allSprites.draw(self.display);
            pygame.display.update(self.SpriteRectangles);
            if(self.flipTimer >= 30):
                self.display.blit(self.intervalMap, (0,0));
                for self.sprite in self.allSprites:
                    self.display.blit(self.sprite.image, (self.sprite.rect.topleft))
                pygame.display.flip();
                self.flipTimer = 0; 
        else:
            self.SpriteRectangles = self.mPause.spriteList.draw(self.display);
            pygame.display.update(self.SpriteRectangles);
    def pauseLogic(self):
        self.mPause.spriteList.update();
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    self.pause = False;
                    self.display.blit(self.intervalMap, (0,0));
                    pygame.display.flip();
            if event.type == pygame.MOUSEBUTTONDOWN:
                if(self.mPause.btnContinue.pressed()):
                    self.pause = False;
                    self.display.blit(self.intervalMap, (0,0));
                    pygame.display.flip();      
                elif(self.mPause.btnQuit.pressed()):
                    self.loadingTransition();
                    cGame.inst().setState(game.states.CLevelState.cLevelState(True));
                elif self.mPause.audioBtns.btnFx.pressed():
                    self.mPause.audioBtns.btnFx.changeSetup();
                elif(self.mPause.audioBtns.btnMusic.pressed()):
                    self.mPause.audioBtns.btnMusic.changeSetup();
            
    def checkExits(self):
        if((self.player.rect.topleft) >= (1200, 0)): 
            if(self.intervalType == "gardenInterval"):
                self.loadingTransition();
                cGame.inst().setState(game.states.CGarden.cGarden(0));
            elif(self.intervalType == "circusInterval"):
                self.loadingTransition();
                cGame.inst().setState(game.states.CCircus.cCircus("count"));
            elif(self.intervalType == "museumInterval"):
                self.loadingTransition();
                cGame.inst().setState(game.states.CMuseum.cMuseum(0));
            elif(self.intervalType == "farmInterval"):
                self.loadingTransition();
                cGame.inst().setState(game.states.CFarm.cFarm());
            elif(self.intervalType == "distractorInteval"):
                if(self.isEnded == False):
                    self.loadingTransition();
                    cGame.inst().setState(game.states.CDistractor.cDistractor(self.neighbourNumber));
                    self.neighbourNumber = None;
                else:
                    self.loadingTransition();
                    cGame.inst().setState(game.states.CLevelState.cLevelState(True));
            self.intervalType = None;
            
        elif((self.player.rect.topright) <= (0, 900)):
            self.intervalType = None;
            self.loadingTransition();
            cGame.inst().setState(game.states.CLevelState.cLevelState(True));
            
    def checkAutoMove(self):
        if((self.player.centerX, self.player.upY) == self.map.rightExit):
            if(self.map.distractorEnded and self.intervalType == "distractorInterval"):
                self.auto = False;
            else:    
                self.player.auto = True;
                self.player.rect.centerx += self.player.velx;
                self.player.image = self.player.walkRight[self.player.n].next();
        elif((self.player.centerX, self.player.upY) == self.map.leftExit):
            self.player.auto = True;
            self.player.rect.centerx -= self.player.velx;
            self.player.image = self.player.walkLeft[self.player.n].next();
            
    def checkNeighbour(self):
        if(self.intervalType == "distractorInteval"):
            if((self.player.centerX, self.player.upY) == self.map.neighbourPlace):
                if(self.helpText == None and self.isEnded == False):
                    self.allSprites.add(self.distractorDialog);
                    self.setHelpMessage(self.neighbourNumber);
            else:
                if(self.helpText != None):
                    self.deletHelpMessage();
    
    def playGreet(self):
        if(cGame.inst().cProgressSave.fxOn):
            self.random = random.randint(0, 2);
            if(self.random == 0):
                self.intervalVoice = pygame.mixer.Sound(Audio.PIQUITOGENIAL); 
            elif (self.random ==1):
                self.intervalVoice = pygame.mixer.Sound(Audio.PIQUITOGENIAL2); 
            elif(self.random ==2):
                self.intervalVoice = pygame.mixer.Sound(Audio.PIQUITOBIENHECHO);

            
              
    def destroy(self):
        self.SpriteRectangles = None;
        self.allSprites.empty();
        self.allSprites = None;
        self.display = None;
        self.intervalMap = None;
        self.foreground.destroy();
        self.foreground = None;
        if(self.neighbour != None):
            self.neighbour.destroy();
            self.neighbour = None;
        if(self.helpText != None):
            self.helpText.destroy();
            self.helpText = None;
        self.intervalVoice.stop();
        self.intervalVoice = None;
        self.mPause.destroy();
        self.mPause = None;
        self.mouse.destroy();
        self.mouse = None;
        self.player.destroy();
        self.player = None;
        self.isEnded = None;
        self.INTRO = None;
        self.GAME = None;
        self.END = None;
        self.TUTO = None;
        self.name = None;
        self.map.destroy();
        self.map = None;
        self.selectedCharacter = None;
        self.display = None;
        self.neighbour = None;
        self.helpText = None;
        self.distractorDialog = None;   
        self.started = None;
        self.lost = None;
        self.started = None;
        self.flipTimer = None;
        pygame.mixer.music.stop();
        
    def setState(self, aState):
        self.gameState = aState;
        if(self.gameState == self.INTRO):
            self.gameIntro(self.intervalType);
        elif(self.gameState == self.TUTO):
            self.createTuto(self.intervalType);
        elif(self.gameState == self.GAME):
            pass;
    def gameIntro(self, aType):
        if(aType == "farmInterval"):
            if(self.isEnded):
                self.message = cGameMessage("farm", [u"¡".format(chr(0xc3)) + "Gracias por", "tu ayuda!", "los clientes estar"+u"á".format(chr(0xc3))+"n",
                                                    "muy satisfechos."], self );
            else:
                self.message = cGameMessage("farm", ["ay"+u"ú".format(chr(0xc3))+"dame a formar", "los pedidos dejando",
                                                     "los objetos en la","canasta.","con cada pedido",
                                                     "estaremos m" + u"á".format(chr(0xc3)) + "s","cerca de","lograrlo."], self );
        elif(aType == "gardenInterval"):
            if(self.isEnded):
                self.message = cGameMessage("garden", [u"¡".format(chr(0xc3)) +"Gracias por ", "tu ayuda!","ahora podremos","volver a disfrutar",
                                                       "del jard"+u"í".format(chr(0xc3)) +"n."], self );
            else:
                self.message = cGameMessage("garden", ["la gente que vino", "de paseo ha dejado","todo muy sucio.",
                                                       "recojamos la basura","tirada y cerremos","las canillas para","no desperdiciar","agua."], self );
        elif(aType == "circusInterval"):
            if(self.isEnded):
                self.message = cGameMessage("circus", [u"¡".format(chr(0xc3)) +"Muchas Gracias!","tienes un don","con los animales.",
                                                       "nunca los vi tan","tranquilos."], self );
            else:
                self.message = cGameMessage("circus", ["debo ordenar los", "animales antes de","que comience",
                                                       "la funci"+u"ó".format(chr(0xc3)) +"n."], self );
        elif(aType == "museumInterval"):
            if(self.isEnded):
                self.message = cGameMessage("museum", [u"¡".format(chr(0xc3)) +"Gracias por tu", "ayuda!","eres todo un","artista."], self );
            else:
                self.message = cGameMessage("museum", ["No estoy seguro", "de que color usar","en cada pintura.",
                                                       u"¿".format(chr(0xc3)) +"puedes ayudarme?"], self );
#         elif(aType == "distractorInterval"):
        elif(aType == "distractorInteval"):
            if(self.isEnded):
                self.message = cGameMessage("pet", [u"¡".format(chr(0xc3))+ "Muy buen trabajo!", "Volvamos al barrio."], self );
            else:
                self.message = cGameMessage("pet", [u"¡".format(chr(0xc3)) + "Encuentra la pareja en el", "juego de la memoria para", "ayudar al vecino!"], self );
                

    def createTuto(self, aType):
        self.tuto = Tutorial(self.allSprites, self);
        
    def removeTuto(self):
        self.tuto.destroy();
        self.tuto = None;
        
    def removeMessage(self):
        self.allSprites.remove(self.message.sign, self.message.bust, self.message.text);
        self.message.destroy();
        self.message = None;
    
    def setHelpMessage(self, neighbourNumber):
        if(neighbourNumber == 0):
            self.helpText = cGameMessage(None, [u"¿".format(chr(0xc3)) + "ME AYUDAS A", "CRUZAR LA", "CALLE?"], self);
        elif(neighbourNumber == 1):
            self.helpText = cGameMessage(None, [u"¿".format(chr(0xc3)) + "ME AYUDAS A", "ALIMENTAR A ", "MI PERRO?"], self);
        elif(neighbourNumber == 2):
            self.helpText = cGameMessage(None, [u"¡".format(chr(0xc3)) + "me ayudas a", "encontrar","el libro?"], self);
        elif(neighbourNumber == 3):
            self.helpText = cGameMessage(None, [u"¿".format(chr(0xc3)) + "ME AYUDAS ", "CON MIS", "COMPRAS?"], self);
        elif(neighbourNumber == 4):
            self.helpText = cGameMessage(None, [u"¿".format(chr(0xc3)) + "me ayudas a", "encontrar","mi billetera?"], self);
   
    def deletHelpMessage(self):
        self.allSprites.remove(self.helpText.text);
        self.helpText.destroy();
        self.helpText = None;
        self.allSprites.remove(self.distractorDialog);
        

