'''
Created on 21/02/2013

@author: Gus
'''
from api.CGameState import cGameState;
import pygame;
from api.CGame import cGame;
#from api.CGameObject import cGameObject;
from game.states.CPlayerSelect import cPlayerSelect;
from CMouse import cMouse;
import Assets.Assets as A; 
import Assets.AudioAssets as Audio;
import Assets.button as button;

class cDifficultySelect(cGameState):
    '''
    classdocs
    '''
    
    def __init__(self):
        '''
        Constructor
        '''
        self.fxOn = cGame.inst().cProgressSave.fxOn;
        self.btnPlaySnd = pygame.mixer.Sound(Audio.BTNPLAY);
        self.btnHoverSnd = pygame.mixer.Sound(Audio.BTNHOVER);
        self.playedHover = False;
        pygame.mouse.set_visible(False);
        self.display = cGame.inst().getDisplay();
        self.MENU = A.Difficulties;
        #-----------Buttons--------------#
        self.btnFacil = button.Button(A.FACIL, 400, 150);
        
        self.btnNormal = button.Button(A.NORMAL, 350, 315);
        
        self.btnDificil = button.Button(A.DIFICIL, 250, 550);
        self.buttonPressed = False;
        #---------------------------------#
        
        self.mMouse = cMouse();
#         self.lastpos = 0;    
        self.allSprites = cGame.inst().getContainer();
        self.allSprites.add(self.btnFacil, self.btnNormal, self.btnDificil, self.mMouse);

        
        #----Copy the The Menu background one time so it stays behind always---#
        self.display.blit(self.MENU, (0,0));
        pygame.display.flip();
        self.flipTimer = 0;
        self.allSprites.update();
        self.started = True;
    def update(self):
        #---Erase sprites from display and refill erased rectangles with the MENU background---#
#        super.__class__(cGameState.update(self));
        self.allSprites.clear(self.display, self.MENU);
        if(pygame.mixer.music.get_busy() == False):
            pygame.mixer.music.play();
    def render(self):
        self.flipTimer += 1;
        #--- Draw and save sprite rectangles list ---#
        self.newPos = pygame.mouse.get_pos();
        
#         if self.newPos != self.lastpos:
#             self.lastpos = self.newPos;
        self.SpriteRectangles = self.allSprites.draw(self.display);
            #--- Pass sprite rectangles to display.update so it flips them to the display ---#
        pygame.display.update(self.SpriteRectangles);
        if(self.flipTimer >= 30):
            self.display.blit(self.MENU, (0,0));
            for self.sprite in self.allSprites:
                self.display.blit(self.sprite.image, (self.sprite.rect.topleft))
            pygame.display.flip();
            self.flipTimer = 0;  
    def destroy(self):
        self.allSprites.empty();
        self.allSprites = None;
        self.i = 0;
        while(self.i<len(self.SpriteRectangles)):
            self.SpriteRectangles[self.i] = None;
            self.i +=1;
        self.i = None;
        self.SpriteRectangles = None;
        self.btnFacil.destroy();
        self.btnFacil = None;
        self.btnNormal.destroy();
        self.btnNormal = None;
        self.btnDificil.destroy();
        self.btnDificil = None;
        self.mMouse.destroy();
        self.mMouse = None;
        self.display = None;
        self.MENU = None;
        self.btnHoverSnd = None;
        self.btnPlaySnd = None;
        self.playedHover = None;
        self.buttonPressed = None;
        self.flipTimer = None;
        self.started = None;   
    def eventUpdate(self):
        if(self.started):
            self.allSprites.update();
            for event in pygame.event.get():
                #handle basic events
                if event.type == pygame.QUIT:
                    cGame.inst.keepGoing = False;
                if event.type == pygame.MOUSEMOTION:
                    if(self.fxOn):
                        if((self.btnFacil != None and self.btnFacil.mouseOver()) or (self.btnNormal != None and self.btnNormal.mouseOver())
                            or (self.btnDificil != None and self.btnDificil.mouseOver())):
                            if(self.playedHover != True):
                                self.playedHover = True;
                                self.btnHoverSnd.play();
                        else:
                            self.playedHover = False;
                if event.type==pygame.MOUSEBUTTONDOWN:
                    self.buttonPressed = True;
                    if(self.btnFacil != None and self.btnFacil.pressed()):
                        cGame.inst().cProgressSave.difficultySelected = 1;
                        self.loadingTransition();
                        cGame.inst().setState(cPlayerSelect());
                    elif(self.btnNormal != None and self.btnNormal.pressed()):
                        cGame.inst().cProgressSave.difficultySelected = 2;
                        self.loadingTransition();
                        cGame.inst().setState(cPlayerSelect());
                    elif(self.btnDificil != None and self.btnDificil.pressed()):
                        cGame.inst().cProgressSave.difficultySelected = 3;
                        self.loadingTransition();
                        cGame.inst().setState(cPlayerSelect());
                       
                    if(self.buttonPressed):
                        if(self.fxOn and self.btnPlaySnd != None):
                            self.btnPlaySnd.play();
                        
            
                    
        