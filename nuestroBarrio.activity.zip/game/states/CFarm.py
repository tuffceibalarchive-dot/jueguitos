# -*- coding: utf-8 -*- 
'''
Created on 14/03/2013

@author: Gus
'''
import pygame;
from api.CGameState import cGameState;
from api.CGame import cGame;
from game.states.CCircus import CheckBtn;
from api.CMap import cMap;
from api.CGameMessage import cGameMessage;
from api.CSpriteSheet import spritesheet;
from api.CSpriteStripAnim import SpriteStripAnim;
from api.CText import cText;
from api.CTutorial import Tutorial;
from api.CPause import cPause;
from CMouse import cMouse;
from CPlayer import Player;
from CGardenTimer import cGardenTimer;
import Assets.Assets as A;
import Assets.AudioAssets as Audio;
import game.states.CInterval;
import random;
        
class farmObjectAnim(pygame.sprite.DirtySprite):
    def __init__(self, aType, x, y, spriteContainer):
        pygame.sprite.DirtySprite.__init__(self);
        self.type = aType;
        self.n = 0;
        self.spriteContainer = spriteContainer;
        self.animTimer = 0;
        if(self.type == "cowHead"):
            self.frames = 30 / 3;
            self.farmObjectAnimSheet = SpriteStripAnim(A.COWHEAD, (0, 0, 150, 185), 3, (0,0,0), True, self.frames);
        elif(self.type == "chicken"):
            self.frames = 90;
            self.farmObjectAnimSheet = SpriteStripAnim(A.CHICKEN, (0, 0, 120, 140), 2, (0,0,0), True, self.frames);    
        elif(self.type == "cowTail"):
            self.frames = 5;
            self.farmObjectAnimSheet = SpriteStripAnim(A.COWTAIL, (0, 0, 115, 115), 5, (0,0,0), True, self.frames);   
        self.anim = [self.farmObjectAnimSheet];
        self.image = self.anim[self.n].next();
        self.rect = self.image.get_rect();
        self.rect.topleft = (x,y);
        self.spriteContainer.add(self);
    def update(self):
        self.animTimer += 1;
        if(self.type != "cowTail"):
            self.image = self.anim[self.n].next();
        else:
            if(self.animTimer >= 30 * 5 and self.animTimer <= 30* 5.5):
                self.image = self.anim[self.n].next();
            elif(self.animTimer > 30 * 5.5 ):
                self.image = self.anim[self.n].first();
                self.animTimer = 0;
    def destroy(self):
        self.anim = None;
        self.rect = None;
        self.farmObjectAnimSheet = None;
        self.image = None;
        self.frames = None;
        self.type = None;
        self.n = None;
        self.spriteContainer = None;
        self.animTimer = None;
            
class Dialogo(pygame.sprite.DirtySprite):
    def __init__(self):
        pygame.sprite.DirtySprite.__init__(self);
        self.image = pygame.Surface.convert_alpha(pygame.image.load(A.DIALOGO));
        self.rect = self.image.get_rect();
        self.rect.topleft = (658, 94);
        
    def destroy(self):
        self.image = None;
        self.rect = None;
            
class farmObject(pygame.sprite.DirtySprite):
    def __init__(self, aType = "small"):
        pygame.sprite.DirtySprite.__init__(self);
        if(aType == "small"):   
            self.objectSheet = spritesheet(A.SMALLOBJECTS);
            self.objectSpriteList = self.objectSheet.load_strip((0, 0, 75, 75), 6, colorkey = (0,0,0));
        else:
            self.objectSheet = spritesheet(A.BIGOBJECTS);
            self.objectSpriteList = self.objectSheet.load_strip((0, 0, 160, 160), 6, colorkey = (0,0,0));
        self.image =  self.objectSpriteList[5];
        self.rect = self.image.get_rect();
        self.objectNumber = 0;

    def changeObjectIndex(self, number):
        self.image = self.objectSpriteList[number];
        self.objectNumber = number;
    def setCoords(self, x, y):
        self.rect.topleft = (x, y);
    def destroy(self):
        self.objectSheet = None;
        self.objectSpriteList = None;
        self.image = None;
        self.rect = None;
        self.objectNumber = None;

class cFarm(cGameState):
    
    
    def __init__(self):
#        pygame.key.set_repeat(15, 15)
        #load music and start playing
        self.fxOn = cGame.inst().cProgressSave.fxOn;
        pygame.mixer.music.load(Audio.MUSICFARM);
        pygame.mixer.music.play();
        if(cGame.inst().cProgressSave.audioOn == False):
            pygame.mixer.music.pause();
        #load FX
        self.correct = pygame.mixer.Sound(Audio.PAIRMATCH);
        self.colocarFx = pygame.mixer.Sound(Audio.COLOCAR);
        self.gallinaFx = pygame.mixer.Sound(Audio.GALLINA);
        self.recolectarFx = pygame.mixer.Sound(Audio.RECOLECTAR);
        self.vacaFx = pygame.mixer.Sound(Audio.VACA); 
        self.lauraOk1 = pygame.mixer.Sound(Audio.LAURABIENHECHO);
        self.lauraOk2 = pygame.mixer.Sound(Audio.LAURAFANTASTICO);
        self.lauraOk3 = pygame.mixer.Sound(Audio.LAURAGENIAL); 
        self.lauraDenuevo = pygame.mixer.Sound(Audio.LAURADENUEVO);
        #----GameStates----
        self.GOLD = 3;
        self.INTRO = 0;
        self.GAME = 1;
        self.END = 2;
        self.TUTO = 3;
        self.difficultySelected = cGame.inst().cProgressSave.difficultySelected;
        self.name = "farm";
        self.farmMap = cMap("farm");
        self.selectedCharacter = cGame.inst().cProgressSave.characterSelected;
        self.display = cGame.inst().getDisplay();       
        
        self.player = Player(self.farmMap, (self.farmMap.farmBegin[0] * self.farmMap.TILE_WIDTH, self.farmMap.farmBegin[1] * self.farmMap.TILE_HEIGHT ));
        self.player.setVel(10, 10);
        pygame.mouse.set_visible(False);
        self.mouse = cMouse();
        self.mPause = cPause(self, self.mouse);
        self.allSprites = cGame.inst().getContainer();
        
        #----Match Logic and stuff-----
        self.objectList = []
        self.OrderList = [];
        self.orderListSprites = [];
        self.timer = cGardenTimer(self.allSprites, self.difficultySelected, self);
        self.deliveryCount = 0;
        if(self.difficultySelected == 1):
            self.QUOTA = 2;
        elif(self.difficultySelected == 2):
            self.QUOTA = 3;
        elif(self.difficultySelected == 3):
            self.QUOTA = 4;
        self.objectTaken = farmObject();

        self.flipTimer = 0;
        self.message = None;
        self.tuto = None;
        self.SpacePressed = False;
        self.greeting = False;
        self.greetTime = 0;
        self.greetingText = None;
        self.dialogo = Dialogo();
        self.cowAnim = farmObjectAnim("cowHead", 315, 455, self.allSprites);
        self.chickenAnim = farmObjectAnim("chicken", 875, 505, self.allSprites );
        self.cowTailAnim = farmObjectAnim("cowTail", 598, 536, self.allSprites);
        self.checkBtn = CheckBtn((1020, 450), 4);
        self.checkBtn.changeImg(3)
        self.allSprites.add(self.player, self.objectTaken, self.checkBtn);
        self.farmBackground = None;
        self.signOn = False;
        self.signTimer = 0;
        self.deliveredOk = False;
        self.started = False;
        
        self.start();
        
    def start(self):
        """ sets up the sprite groups
            begins the main loop """
        self.pause=False
        self.gameEnded = False;
        self.setState(self.TUTO)
        self.farmBackground = A.farmBackground;
        self.display.blit(self.farmBackground, (0,0));
        pygame.display.flip();
        self.started = True;
    def eventUpdate(self):
        if(self.started):
            if(self.pause != True):
                if(self.message == None and self.gameState == self.GAME):
                    self.allSprites.update();
        
                for event in pygame.event.get():
                    #handle basic events
                    if event.type == pygame.QUIT:
                        cGame.inst().keepGoing = False;
                    if event.type==pygame.KEYDOWN:
                        if event.key==pygame.K_ESCAPE:
                            self.pause = True;
                        if event.key==pygame.K_SPACE:
                            self.SpacePressed = True;
                            if(self.message != None):
                                self.removeMessage();
                                if(self.gameState == self.INTRO):
                                    self.setState(self.GAME);
                            if(self.tuto != None):
                                self.removeTuto();
                                if(self.gameState == self.TUTO):
                                    self.allSprites.clear(self.display, self.farmBackground);
                                    self.setState(self.INTRO);
            else:
                self.pauseLogic();
                    
                            
    def update(self): 
        if(self.pause != True):        
            if(self.message == None and self.gameState == self.GAME):
                if(self.dialogo not in self.allSprites):
                    self.allSprites.add(self.dialogo);
                self.allSprites.clear(self.display, self.farmBackground);
                self.objectTaken.setCoords(self.player.rect.topleft[0]+ 15, self.player.rect.topleft[1] - 60);
                self.createOrder();  
                self.takeObjectFunction();
                self.checkObjectDelivered();
                self.ShowHideSign();
                self.greetingFunc();
                if(self.timer.rect.right <= 20):
                    self.gameEnd();
        else:
            self.mPause.spriteList.clear(self.display, self.farmBackground);
        if(cGame.inst().cProgressSave.audioOn):
            if(pygame.mixer.music.get_busy() == False):
                pygame.mixer.music.play();  
        #---------------------------------------------------------#        
    def render(self):
        if(self.pause != True):
            self.flipTimer += 1;
            self.SpriteRectangles = self.allSprites.draw(self.display);
            pygame.display.update(self.SpriteRectangles);
            
            if(self.flipTimer >= 30):
                self.display.blit(self.farmBackground, (0,0));
                for self.sprite in self.allSprites:
                    self.display.blit(self.sprite.image, (self.sprite.rect.topleft))
                pygame.display.flip();
                self.flipTimer = 0;  
            #print("renderLevel")
        else:
            self.SpriteRectangles = self.mPause.spriteList.draw(self.display);
            pygame.display.update(self.SpriteRectangles);
    
    def pauseLogic(self):
        self.mPause.spriteList.update();
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    self.pause = False;
                    self.display.blit(self.farmBackground, (0,0));
                    pygame.display.flip();
            if event.type == pygame.MOUSEBUTTONDOWN:
                if(self.mPause.btnContinue.pressed()):
                    self.pause = False;
                    self.display.blit(self.farmBackground, (0,0));
                    pygame.display.flip();      
                elif(self.mPause.btnQuit.pressed()):
                    self.loadingTransition();
                    cGame.inst().setState(game.states.CInterval.cInterval("farmInterval", exited = True));
                elif self.mPause.audioBtns.btnFx.pressed():
                    self.mPause.audioBtns.btnFx.changeSetup();
                    self.fxOn = cGame.inst().cProgressSave.fxOn;
                elif(self.mPause.audioBtns.btnMusic.pressed()):
                    self.mPause.audioBtns.btnMusic.changeSetup();    
    def createOrder(self):
        if(len(self.OrderList) <= 0 and self.greeting == False):
            self.checkBtn.changeImg(3);
            self.i = 0;
            for self.i in range(3):
                self.randomNumber = random.randint(0, 4);
                self.randomObject = farmObject("big");
                self.randomObject.changeObjectIndex(self.randomNumber);
                if(self.i == 0):
                    self.randomObject.setCoords(680, 90);
                elif(self.i == 1):
                    self.randomObject.setCoords(840, 90);
                elif(self.i == 2):
                    self.randomObject.setCoords(1000, 90);
                self.OrderList.append(self.randomObject);
                self.allSprites.add(self.OrderList);
            
    
    def takeObjectFunction(self):
        if(self.SpacePressed):
            if((self.player.centerX, self.player.upY) == self.farmMap.tomatos):
                self.objectTaken.changeObjectIndex(0);
                if(self.fxOn):
                    self.recolectarFx.play();
            elif((self.player.centerX, self.player.upY) == self.farmMap.carrotLeft or (self.player.centerX, self.player.upY) == self.farmMap.carrotRight):
                self.objectTaken.changeObjectIndex(1);
                if(self.fxOn):
                    self.recolectarFx.play();
            elif((self.player.centerX, self.player.upY) == self.farmMap.cow):
                self.objectTaken.changeObjectIndex(2);
                if(self.fxOn):  
                    self.vacaFx.play();
            elif((self.player.centerX, self.player.upY) == self.farmMap.oranges or (self.player.centerX, self.player.upY) == self.farmMap.orangesRight):
                self.objectTaken.changeObjectIndex(3);
                if(self.fxOn):
                    self.recolectarFx.play();
            elif((self.player.centerX, self.player.upY) == self.farmMap.chicken):
                self.objectTaken.changeObjectIndex(4);
                if(self.fxOn):
                    self.gallinaFx.play();
            self.SpacePressed = False;
    
    def ShowHideSign(self):
        if(self.signOn):
            self.signTimer +=1;
            if(self.deliveredOk):
                self.checkBtn.changeImg(2);
            else:
                self.checkBtn.changeImg(1);
            if(self.signTimer > 30 * 2):
                self.checkBtn.changeImg(3);
                self.signOn = False;
                self.signTimer = 0;
                self.deliveredOk = False;
    def checkObjectDelivered(self):
        if((self.player.centerX, self.player.upY) == self.farmMap.basket and self.objectTaken.objectNumber != 5):
            self.counter = 0;
            
            while(self.counter < len(self.OrderList)):
                if self.OrderList[self.counter].objectNumber == self.objectTaken.objectNumber:
                    self.allSprites.remove(self.OrderList[self.counter]);
                    self.OrderList[self.counter].destroy();
                    self.OrderList.remove(self.OrderList[self.counter]);
                    self.deliveredOk = True;
                    if(self.fxOn):
                        self.colocarFx.play();
                    break;
                self.counter +=1;
            self.signOn = True;
            if(len(self.OrderList) <=0 and self.greeting != True):
                if(self.deliveryCount == 0):
                    if(cGame.inst().cProgressSave.pics["farm01"] == False):
                        cGame.inst().cProgressSave.newPic = True;
                        cGame.inst().UnlockPic("farm01");
                self.deliveryCount += 1;
                self.greeting = True;
                if(self.fxOn):
                    self.correct.play();
                    self.playGreet();
            #print(self.deliveryCount)
            self.objectTaken.changeObjectIndex(5);
            
    def playGreet(self):
        if(cGame.inst().cProgressSave.fxOn):
            self.randomNum = random.randint(0,2);
            if(self.randomNum == 0):
                self.lauraOk1.play();
            elif(self.randomNum == 1):
                self.lauraOk2.play();
            elif(self.randomNum == 2):
                self.lauraOk3.play();
    def greetingFunc(self):
        if(self.greeting):
            self.greetTime +=1;
            if(self.greetingText == None):
                self.addGreet();
                self.greetingText.setCoords(750, 125);
        if(self.greetTime >= 2 * 30):
            self.greetingText.destroy();
            self.greetTime = 0;
            self.greeting = False;
            self.greetingText = None;
    
    def addGreet(self):
        self.randomGreet = random.randint(0, 6);
        if(self.randomGreet == 0):
            self.string = u"¡".format(chr(0xc3)) + "Genial!";
        elif(self.randomGreet == 1):
            self.string = u"¡".format(chr(0xc3)) +"Gracias!";
        elif(self.randomGreet == 2):
            self.string = u"¡".format(chr(0xc3)) + "S" + u"ú".format(chr(0xc3)) + "per!";
        elif(self.randomGreet == 3):
            self.string = u"¡".format(chr(0xc3)) + "Excelente!"
        elif(self.randomGreet == 4):
            self.string = u"¡".format(chr(0xc3)) + "Que bien!"
        elif(self.randomGreet == 5):
            self.string = u"¡".format(chr(0xc3)) + "sigue as" + u"í".format(chr(0xc3)) + "!";
        elif(self.randomGreet == 6):
            self.string = u"¡".format(chr(0xc3)) + "As" + u"í".format(chr(0xc3)) + " es!";
        self.greetingText = cText((self.string), 1, None, 60, self.allSprites );
    
    def setState(self, aState):
        self.gameState = aState;
        if(self.gameState == self.INTRO):
            self.gameIntro();
        elif(self.gameState == self.TUTO):
            self.createTuto();
        elif(self.gameState == self.GAME):
            pass;
        
    def removeTuto(self):
        self.tuto.destroy();
        self.tuto = None;   
    
    def createTuto(self):
        self.tuto = Tutorial(self.allSprites, self);
            
    def gameIntro(self):
        self.message = cGameMessage("farm", ["Cuando est"+u"é".format(unichr(0xc3))+"s listo", "presiona la barra", "espaciadora para", "comenzar la partida."], self );
    
    def gameEnd(self):
        if(self.message == None and self.gameState == self.GAME):
            if(self.gameEnded != True):
                if(self.deliveryCount >= self.QUOTA):
                    self.message = cGameMessage("farm", [u"¡".format(chr(0xc3)) + "Se acab" + u"ó".format(chr(0xc3)) + " el tiempo!",
                                                           "Has completado: " + str(self.deliveryCount), "entregas",
                                                           "el m" + u"í".format(chr(0xc3)) + "nimo eran " + str(self.QUOTA),
                                                           u"¡".format(chr(0xc3)) + "Felicitaciones!"], self);
                    
                else:
                    if(cGame.inst().cProgressSave.fxOn):
                        self.lauraDenuevo.play();
                    self.message = cGameMessage("farm", [u"¡".format(chr(0xc3)) + "Se acab" + u"ó".format(chr(0xc3)) + " el tiempo!",
                                                            "Has completado: " + str(self.deliveryCount), "entregas",
                                                           "el m" + u"í".format(chr(0xc3)) + "nimo eran " + str(self.QUOTA),
                                                           u"¡".format(chr(0xc3)) + "Intenta denuevo!"], self);
            self.gameEnded = True;
            
            if(self.message == None and self.gameEnded):
                if(self.deliveryCount >= self.QUOTA):
                    if(cGame.inst().cProgressSave.pics["farm02"] == False):
                        cGame.inst().cProgressSave.newPic = True;
                        cGame.inst().UnlockPic("farm02");
                    cGame.inst().cProgressSave.farmScore = self.GOLD;
                    cGame.inst().cProgressSave.stagesPassed["farm"] = True; 
                    self.loadingTransition();
                    cGame.inst().setState(game.states.CInterval.cInterval("farmInterval", True));
                else:
                    self.loadingTransition();
                    cGame.inst().setState(game.states.CInterval.cInterval("farmInterval", exited = True));
                
    def removeMessage(self):
        self.allSprites.remove(self.message.sign, self.message.bust, self.message.text);
        self.message.destroy();
        self.message = None;
        
    def destroy(self):
        cGame.inst().cProgressSave.SaveValues();
        self.player.destroy();
        self.player = None;
        self.fxOn = None;
        self.SpriteRectangles = None;
        self.allSprites.empty();
        self.allSprites = None;
        self.farmBackground = None;
        self.cowAnim.destroy();
        self.cowAnim = None;
        self.chickenAnim.destroy();
        self.chickenAnim = None;
        self.cowTailAnim.destroy();
        self.cowTailAnim = None;
        if(self.OrderList != None):
            for self.object in self.OrderList:
                self.object.destroy();
            self.OrderList = None;
        self.objectList = None;
        self.orderListSprites = None;
        self.timer.destroy();
        self.timer = None;
        self.objectTaken.destroy();
        if(self.greetingText != None):
            self.greetingText.destroy();
            self.greetingText = None;
        self.checkBtn.destroy();
        self.checkBtn = None;
        self.signOn = None;
        self.signTimer = None;
        self.deliveredOk = None;
        self.farmMap.destroy();
        self.farmMap = None;
        self.mPause.destroy();
        self.mPause = None;
        self.mouse.destroy();
        self.mouse = None;
        self.colocarFx = None;
        self.recolectarFx = None;
        self.vacaFx = None;
        self.gallinaFx = None;
        self.correct = None;
        self.GOLD = None;
        self.INTRO = None;
        self.GAME = None;
        self.END = None;
        self.TUTO = None;
        self.difficultySelected = None;
        self.name = None;
        self.selectedCharacter = None; 
        self.deliveryCount = None;
        self.SpacePressed = None;
        self.greeting = None;
        self.greetTime = None;
        self.dialogo.destroy();
        self.dialogo = None;
        self.pause=None;
        self.gameEnded = None;
        self.lauraOk1 = None;
        self.lauraOk2 = None;
        self.lauraOk3 = None;
        self.lauraDenuevo = None;
        self.started = None;
        self.flipTimer = None;
        pygame.mixer.music.stop();