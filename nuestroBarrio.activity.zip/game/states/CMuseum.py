# -*- coding: utf-8 -*- 
'''
Created on 14/03/2013

@author: Gus
'''
import pygame;
from api.CGameState import cGameState;
from api.CGame import cGame;
from api.CGameMessage import cGameMessage;
from api.CTutorial import Tutorial;
from CMuseumButton import museumButton;
from CMouse import cMouse;
from CMuseumObject import museumObject;
from api.CPause import cPause;
import Assets.Assets as A;
import Assets.AudioAssets as Audio;
import game.states.CInterval;
import random;
        
class cMuseum(cGameState):
    
    
    def __init__(self, aFromWhere):
        #load music file and play
        self.fxOn = cGame.inst().cProgressSave.fxOn;
        pygame.mixer.music.load(Audio.MUSICMUSEUM);
        pygame.mixer.music.play();
        if(cGame.inst().cProgressSave.audioOn == False):
            pygame.mixer.music.pause();
        #Load FX
        self.cargarSnd = pygame.mixer.Sound(Audio.CARGAR);
        self.limpiarSnd = pygame.mixer.Sound(Audio.LIMPIAR);
        self.pintarOKSnd = pygame.mixer.Sound(Audio.PINTARBIEN);
        self.pintarMalSnd = pygame.mixer.Sound(Audio.PINTARMAL);
        self.jaimeOk1 = pygame.mixer.Sound(Audio.JAIMEMUYBIEN);
        self.jaimeOk2 = pygame.mixer.Sound(Audio.JAIMEOHLALA);
        self.BRONZE = 1;
        self.SILVER = 2;
        self.GOLD = 3;
        self.MAXERRORS = 12;
        self.MINERRORS = 6;
        #Game States constants
        self.INTRO = 0;
        self.GAME = 1;
        self.END = 2;
        self.TUTO = 3;
        #stage name constants numerical
        self.INTERVAL = 0;
        self.BEACH = 1;
        self.CAMPO = 2;
        self.CIUDAD = 3;
        self.MOUNTAIN = 4;
        self.LASTSTAGE = 5;
        self.name = "museum";
#        pygame.key.set_repeat(15, 15)
        self.selectedCharacter = cGame.inst().cProgressSave.characterSelected;
        self.display = cGame.inst().getDisplay();       
        pygame.mouse.set_visible(False);
        self.allSprites = cGame.inst().getContainer();
        self.mFromWhere = aFromWhere;
        self.museumBackground = None;
        #Background#
        if(self.mFromWhere == self.INTERVAL):
            self.museumBackground = A.museumBackgroundBeach;
        elif(self.mFromWhere == self.BEACH):
            self.museumBackground = A.museumBackgroundCampo;
        elif(self.mFromWhere == self.CAMPO):
            self.museumBackground = A.museumBackgroundCiudad;
        elif(self.mFromWhere == self.CIUDAD):
            self.museumBackground = A.museumBackgroundMountain;
        elif(self.mFromWhere == self.MOUNTAIN):
            self.museumBackground = A.museumBackgroundLake;
#             self.museumBackground == A.mu
        
        #Brush paints and cleaner#
        self.mouse = cMouse();
        self.mPause = cPause(self, self.mouse);
        self.brush = cMouse("brush");
        self.brush.update();
        self.brushCleaner = museumButton((self.brush.EMPTY), (945, 640), self.brush);
        self.redCan = museumButton((self.brush.RED), (60, 650), self.brush);
        self.yellowCan = museumButton((self.brush.YELLOW), (370, 650), self.brush);
        self.blueCan = museumButton((self.brush.BLUE), (660, 650), self.brush);
        
        self.triesCount = 0;
        self.remainList = [];
        self.paintObjectList = [];
        self.createPaint();
        
        self.allSprites.add(self.brushCleaner, self.redCan, self.yellowCan, self.blueCan, self.brush);
        self.flipTimer = 0;
        self.endCount = 0;
        self.message = None;
        self.tuto = None;
        self.SpriteRectangles = None;
        self.started = False;
        self.start();
        
    def start(self):
        """ sets up the sprite groups
            begins the main loop """
        self.pause=False
        self.abort=False 
        self.gameState = self.INTRO; 
        self.gameIntro();
        self.display.blit(self.museumBackground, (0,0));
        pygame.display.flip();
        self.started = True;
    def eventUpdate(self):
        if(self.started):
            if(self.pause != True):
                if(self.message == None and self.gameState == self.GAME):
                    self.allSprites.update();
        
                for event in pygame.event.get():
                    #handle basic events
                    if event.type == pygame.QUIT:
                        cGame.inst().keepGoing = False;
                    if event.type==pygame.KEYDOWN:
                        if event.key==pygame.K_ESCAPE:
                            self.pause = True;
                        if event.key==pygame.K_SPACE:
                            if(self.tuto != None):
                                self.removeTuto();
                                if(self.gameState == self.TUTO):
                                    self.setState(self.GAME);
                            if(self.message != None):
                                self.removeMessage();
                                if(self.gameState == self.INTRO):
                                    self.allSprites.clear(self.display, self.museumBackground);
                                    self.setState(self.TUTO);
        
                    if event.type == pygame.MOUSEBUTTONDOWN:
                        if(self.redCan.pressed()):
                            self.redCan.justPressed = True;
                            if(self.fxOn):
                                self.cargarSnd.play();
                        elif(self.blueCan.pressed()):
                            self.blueCan.justPressed = True;
                            if(self.fxOn):
                                self.cargarSnd.play();
                        elif(self.yellowCan.pressed()):
                            self.yellowCan.justPressed = True;
                            if(self.fxOn):
                                self.cargarSnd.play();
                        elif(self.brushCleaner.pressed()):
                            self.brushCleaner.justPressed = True;
                            if(self.fxOn):
                                self.limpiarSnd.play(); 
                        else:    
                            for self.object in self.paintObjectList:
                                if(self.object.isButton):
                                    if(self.object.pressed()):
                                        self.object.checkPaint();
                                        if(self.object.painted):
                                            for self.remainder in self.remainList:
                                                if(self.object == self.remainder):
                                                    if(self.fxOn):
                                                        self.pintarOKSnd.play();
                                                    self.remainList.remove(self.remainder);
                                        else:
                                            if(self.fxOn):
                                                self.pintarMalSnd.play();
                                            self.triesCount += 1; 
                                 
            else:
                self.pauseLogic();
                            
    def update(self):
        if(self.pause != True):
            self.allSprites.clear(self.display, self.museumBackground);
            if(len(self.remainList) == 0):
                self.endCount +=1;
                if(self.endCount >= 5):
                    self.gameEnd();
        else:
            self.mPause.spriteList.clear(self.display, self.museumBackground);
        if(cGame.inst().cProgressSave.audioOn):
            if(pygame.mixer.music.get_busy() == False):
                pygame.mixer.music.play();  
        
        
        #---------------------------------------------------------#        
    def render(self):
        if(self.pause != True):
            self.flipTimer += 1;
            self.SpriteRectangles = self.allSprites.draw(self.display);
            pygame.display.update(self.SpriteRectangles);
            if(self.flipTimer >= 30):
                self.display.blit(self.museumBackground, (0,0));
                for self.sprite in self.allSprites:
                    self.display.blit(self.sprite.image, (self.sprite.rect.topleft))
                pygame.display.flip();
                
                self.flipTimer = 0; 
        else:
            self.SpriteRectangles = self.mPause.spriteList.draw(self.display);
            pygame.display.update(self.SpriteRectangles);
            
    def pauseLogic(self):
        self.mPause.spriteList.update();
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    self.pause = False;
                    self.display.blit(self.museumBackground, (0,0));
                    pygame.display.flip();
            if event.type == pygame.MOUSEBUTTONDOWN:
                if(self.mPause.btnContinue.pressed()):
                    self.pause = False;
                    self.display.blit(self.museumBackground, (0,0));
                    pygame.display.flip(); 
                elif(self.mPause.btnQuit.pressed()):
                    self.loadingTransition();
                    cGame.inst().setState(game.states.CInterval.cInterval("museumInterval", exited = True));
                elif self.mPause.audioBtns.btnFx.pressed():
                    self.mPause.audioBtns.btnFx.changeSetup();
                    self.fxOn = cGame.inst().cProgressSave.fxOn;
                elif(self.mPause.audioBtns.btnMusic.pressed()):
                    self.mPause.audioBtns.btnMusic.changeSetup();
                    
    def setState(self, aState):
        self.gameState = aState;
        if(self.gameState == self.INTRO):
            self.gameIntro();
        elif(self.gameState == self.TUTO):
            self.createTuto();
        elif(self.gameState == self.GAME):
            pass;
        
    def removeTuto(self):
        self.tuto.destroy();
        self.tuto = None;   
    
    def createTuto(self):
        self.tuto = Tutorial(self.allSprites, self);
         
    def gameIntro(self):
        self.message = cGameMessage("museum", ["Cuando est"+u"é".format(unichr(0xc3))+"s listo", "presiona la barra", "espaciadora para", "comenzar la partida."], self );
    
    def gameEnd(self):
        if(self.message == None and self.gameState == self.GAME):
            self.playGreet();
            if(self.triesCount == 0):
                self.message = cGameMessage("museum", [u"¡".format(unichr(0xc3)) + "Has terminado",
                                                        "sin errores!",
                                                         u"¡".format(unichr(0xc3)) + "Excelente trabajo!",
                                                         "Presiona la barra",
                                                          "espaciadora para","seguir." ], self);
            elif(self.triesCount > 0 and self.triesCount <= 1):
                self.message = cGameMessage("museum", [u"¡".format(unichr(0xc3)) + "Has terminado",
                                                       "con solo" + str(self.triesCount) + " error!",
                                                       u"¡".format(unichr(0xc3)) + "Muy buen trabajo!",
                                                       "Presiona la barra", 
                                                       "espaciadora para seguir."], self);
            elif(self.triesCount > 1):
                self.message = cGameMessage("museum", ["Has terminado","con " + str(self.triesCount), "errores",
                                                       u"¡".format(unichr(0xc3)) + "Buen trabajo!",
                                                       "Presiona la barra", 
                                                       "espaciadora para","seguir."], self);
            self.gameState = self.END;
            
        elif(self.message == None and self.gameState == self.END):
            if(self.mFromWhere != self.MOUNTAIN):
                if(self.mFromWhere == self.INTRO):
                    if(cGame.inst().cProgressSave.pics["museum01"] == False):
                        cGame.inst().UnlockPic("museum01");
                        cGame.inst().cProgressSave.newPic=True;
                    
                self.RegisterScore();
                self.loadingTransition();
                cGame.inst().setState(game.states.CMuseum.cMuseum(self.mFromWhere + 1));
            else:
                if(cGame.inst().cProgressSave.pics["museum02"] == False):
                    cGame.inst().UnlockPic("museum02");
                    cGame.inst().cProgressSave.newPic=True;
                cGame.inst().cProgressSave.stagesPassed["museum"] = True;
                self.RegisterScore();
                cGame.inst().cProgressSave.newPic=True;
                self.loadingTransition();
                cGame.inst().setState(game.states.CInterval.cInterval("museumInterval", True));
                
    def playGreet(self):
        if(cGame.inst().cProgressSave.fxOn):
            self.randomNum = random.randint(0,1);
            if(self.randomNum == 0):
                self.jaimeOk1.play();
            else:
                self.jaimeOk2.play();
            
    def RegisterScore(self):
        self.finalScore = 0;
        if(self.triesCount > self.MAXERRORS):
            self.finalScore = self.BRONZE;
        elif(self.triesCount <= self.MAXERRORS and self.triesCount > self.MINERRORS):
            self.finalScore = self.SILVER;
        elif(self.triesCount <= self.MINERRORS):
            self.finalScore = self.GOLD;
        if(cGame.inst().cProgressSave.museumScore[self.mFromWhere] != None):
            if(self.finalScore > cGame.inst().cProgressSave.museumScore[self.mFromWhere]):
                cGame.inst().cProgressSave.museumScore[self.mFromWhere] = self.finalScore;
        else:
            cGame.inst().cProgressSave.museumScore[self.mFromWhere] = self.finalScore;
        if(cGame.inst().cProgressSave.stagesPassed["museum"]):       
            self.rateToDeliver = cGame.inst().cProgressSave.GetPerformanceRate("museum");
            cGame.inst().cProgressSave.museumRate = self.rateToDeliver;     
    def removeMessage(self):
        self.allSprites.remove(self.message.sign, self.message.bust, self.message.text);
        self.message.destroy();
        self.message = None;
    
    def destroy(self):
        cGame.inst().cProgressSave.SaveValues();
        self.i = 0;
        while (self.i<len(self.SpriteRectangles)):
            self.SpriteRectangles[self.i] = None;
            self.i +=1;
        self.i = 0;
        self.SpriteRectangles = None;
        self.allSprites.empty();
        self.allSprites = None;
        self.museumBackground = None;
        self.brush.destroy();
        self.mPause.destroy();
        self.mouse.destroy();
        self.brush = None;
        self.redCan.destroy();
        self.yellowCan.destroy();
        self.blueCan.destroy();
        self.brushCleaner.destroy();
        self.pintarMalSnd = None;
        self.pintarOKSnd = None;
        self.cargarSnd = None;
        self.limpiarSnd = None;
        self.jaimeOk1 = None;
        self.jaimeOk2 = None;
        self.started = None;
        self.j = 0;
        while(self.j<len(self.paintObjectList)):
            self.paintObjectList[self.j].destroy();
            self.paintObjectList[self.j] = None;
            self.j+=1;
        self.paintObjectList = None;
        self.flipTimer = None;
        pygame.mixer.music.stop();
        
    def createPaint(self):
        if(self.mFromWhere == self.INTERVAL):
            #creo el beach.
            self.sol = museumObject(A.SOL, 265, 50, 206, 206, True, self.brush.YELLOW, self.brush);
            self.castillos = museumObject(A.CASTILLOS, 264, 413, 170, 170, True, self.brush.ORANGE, self.brush);
            self.shells = museumObject(A.SHELLS, 62, 555, 320, 124, True, self.brush.PURPLE, self.brush);
            self.sombrilla = museumObject(A.SOMBRILLA, 470, 128, 355, 315, True, self.brush.PURPLE, self.brush);
            self.sombrero = museumObject(A.SOMBRERO, 970, 572, 164, 182, True, self.brush.YELLOW, self.brush);
            self.flotador = museumObject(A.FLOTADOR, 718, 440, 244, 162, True, self.brush.BLUE, self.brush);
            self.faro = museumObject(A.FARO, 48, 71, 202, 268, True, self.brush.RED, self.brush);
            self.pelota = museumObject(A.PELOTA, 258, 328, 92, 92, True, self.brush.ORANGE, self.brush);
            self.sandia = museumObject(A.SANDIA, 490, 450, 220, 195, True, self.brush.RED, self.brush);
            self.planta = museumObject(A.PLANTA, 85, 340, 105, 145, True, self.brush.GREEN, self.brush);
            self.palmera = museumObject(A.PALMERA, 800, 90, 332, 202, True, self.brush.GREEN, self.brush);
            self.surfboard = museumObject(A.SURFBOARD, 1025, 305, 80, 262, True, self.brush.BLUE, self.brush);
            self.paintObjectList.append(self.sol);
            self.paintObjectList.append(self.castillos);
            self.paintObjectList.append(self.shells);
            self.paintObjectList.append(self.sombrilla);
            self.paintObjectList.append(self.sombrero);
            self.paintObjectList.append(self.flotador);
            self.paintObjectList.append(self.faro);
            self.paintObjectList.append(self.pelota);
            self.paintObjectList.append(self.sandia);
            self.paintObjectList.append(self.planta);
            self.paintObjectList.append(self.palmera);
            self.paintObjectList.append(self.surfboard);
        elif(self.mFromWhere == self.BEACH):
            self.arbol = museumObject(A.ARBOL, 334, 40, 300, 225, True, self.brush.GREEN, self.brush);
            self.mariposa = museumObject(A.MARIPOSA, 610, 40, 110, 125, True, self.brush.RED, self.brush);
            self.pajaro = museumObject(A.PAJARO, 966, 45, 155, 130, True, self.brush.BLUE, self.brush);
            self.girasoles = museumObject(A.GIRASOLES, 140, 190, 220, 120, True, self.brush.YELLOW, self.brush);
            self.ladyBug = museumObject(A.LADYBUG, 65, 385, 110, 75, True, self.brush.RED, self.brush);
            self.violetas = museumObject(A.VIOLETAS, 180, 370, 150, 135, True, self.brush.PURPLE, self.brush);
            self.arana = museumObject(A.ARANA, 385, 540, 60, 50, True, self.brush.BLUE, self.brush);
            self.huevo = museumObject(A.HUEVO, 618, 330, 45, 55, True, self.brush.ORANGE, self.brush);
            self.plantacion = museumObject(A.PLANTACION, 725, 190, 245, 205, True, self.brush.GREEN, self.brush);
            self.zapallo = museumObject(A.ZAPALLO, 742, 425, 155, 140, True, self.brush.ORANGE, self.brush);
            self.choclo = museumObject(A.CHOCLO, 968, 215, 175, 315, True, self.brush.YELLOW, self.brush);
            self.berenjena = museumObject(A.BERENJENA, 769, 570, 190, 190, True, self.brush.PURPLE, self.brush);
            self.paintObjectList.append(self.arbol); 
            self.paintObjectList.append(self.mariposa); 
            self.paintObjectList.append(self.pajaro); 
            self.paintObjectList.append(self.girasoles); 
            self.paintObjectList.append(self.ladyBug); 
            self.paintObjectList.append(self.violetas); 
            self.paintObjectList.append(self.arana);
            self.paintObjectList.append(self.huevo); 
            self.paintObjectList.append(self.plantacion); 
            self.paintObjectList.append(self.zapallo);
            self.paintObjectList.append(self.choclo); 
            self.paintObjectList.append(self.berenjena); 
        elif(self.mFromWhere == self.CAMPO):    
            self.lineas = museumObject(A.LINEAS, 62, 546, 570,30, True, self.brush.YELLOW, self.brush);
            self.ventanas = museumObject(A.VENTANAS, 163, 93, 105,105, True, self.brush.BLUE, self.brush);
            self.techo = museumObject(A.TECHO, 224, 200, 245,155, True, self.brush.PURPLE, self.brush);
            self.semaforo = museumObject(A.SEMAFORO, 495, 260, 70,150, True, self.brush.RED, self.brush);
            self.hidrante = museumObject(A.HIDRANTE, 115, 385, 80,120, True, self.brush.RED, self.brush);
            self.flores = museumObject(A.FLORES, 65, 577, 160,105, True, self.brush.ORANGE, self.brush);
            self.pasto = museumObject(A.PASTO, 270, 585, 255,105, True, self.brush.GREEN, self.brush);
            self.banco = museumObject(A.BANCO, 630, 520, 165,150, True, self.brush.BLUE, self.brush);
            self.auto = museumObject(A.AUTO, 830, 450, 300,145, True, self.brush.PURPLE, self.brush);
            self.casa = museumObject(A.CASA, 558, 128, 270,335, True, self.brush.GREEN, self.brush);
            self.arbol = museumObject(A.ARBOLCITY, 945, 90, 215,230, True, self.brush.ORANGE, self.brush);
            self.sol = museumObject(A.SOLCITY, 875, 45, 70,70, True, self.brush.YELLOW, self.brush);
            self.paintObjectList.append(self.lineas);
            self.paintObjectList.append(self.ventanas);
            self.paintObjectList.append(self.techo);
            self.paintObjectList.append(self.semaforo);
            self.paintObjectList.append(self.hidrante);
            self.paintObjectList.append(self.flores);
            self.paintObjectList.append(self.pasto);
            self.paintObjectList.append(self.banco);
            self.paintObjectList.append(self.auto);
            self.paintObjectList.append(self.casa);
            self.paintObjectList.append(self.arbol);
            self.paintObjectList.append(self.sol);
        elif(self.mFromWhere == self.CIUDAD):
            self.cableCar = museumObject(A.CABLECAR, 320, 50, 135,125, True, self.brush.YELLOW, self.brush);
            self.avion = museumObject(A.AVION, 865, 40, 175,95, True, self.brush.RED, self.brush);
            self.techo = museumObject(A.TECHOMOUNT, 90, 250, 265,95, True, self.brush.RED, self.brush);
            self.pinos = museumObject(A.PINOS, 535, 300, 135,185, True, self.brush.GREEN, self.brush);
            self.guante = museumObject(A.GUANTE, 630, 520, 140,100, True, self.brush.YELLOW, self.brush);
            self.trineo = museumObject(A.TRINEO, 325, 460, 210,115, True, self.brush.BLUE, self.brush);
            self.cerca = museumObject(A.CERCA, 70, 400, 250,285, True, self.brush.ORANGE, self.brush);
            self.bufanda = museumObject(A.BUFANDA, 770, 375, 170,175, True, self.brush.PURPLE, self.brush);
            self.zanahoria = museumObject(A.ZANAHORIAMOUNT, 695, 320, 155,50, True, self.brush.ORANGE, self.brush);
            self.gorra = museumObject(A.GORRA, 800, 210, 120,85, True, self.brush.BLUE, self.brush);
            self.snowboard = museumObject(A.SNOWBOARD, 990, 165, 165,365, True, self.brush.PURPLE, self.brush);
            self.planta = museumObject(A.PLANTAMOUNT, 1000, 530, 135,125, True, self.brush.GREEN, self.brush);
            self.paintObjectList.append(self.cableCar);
            self.paintObjectList.append(self.avion);
            self.paintObjectList.append(self.techo);
            self.paintObjectList.append(self.pinos);
            self.paintObjectList.append(self.guante);
            self.paintObjectList.append(self.trineo);
            self.paintObjectList.append(self.cerca);
            self.paintObjectList.append(self.bufanda);
            self.paintObjectList.append(self.zanahoria);
            self.paintObjectList.append(self.gorra);
            self.paintObjectList.append(self.snowboard);
            self.paintObjectList.append(self.planta);
        elif(self.mFromWhere == self.MOUNTAIN):
            self.casaLake = museumObject(A.CASALAKE, 230, 145, 185,200, True, self.brush.BLUE, self.brush);
            self.globo = museumObject(A.GLOBO, 430, 30, 120,200, True, self.brush.PURPLE, self.brush);
            self.cometa = museumObject(A.COMETA, 695, 35, 180,320, True, self.brush.YELLOW, self.brush);
            self.juncos = museumObject(A.JUNCOS, 920, 285, 225,185, True, self.brush.ORANGE, self.brush);
            self.pez = museumObject(A.PEZ, 790, 390, 120,180, True, self.brush.PURPLE, self.brush);
            self.plantasFlot = museumObject(A.PLANTASFLOTANTES, 375, 350, 130,65, True, self.brush.GREEN, self.brush);
            self.muelle = museumObject(A.MUELLE, 130, 405, 150,85, True, self.brush.ORANGE, self.brush);
            self.bote = museumObject(A.BOTE, 410, 408, 310,100, True, self.brush.RED, self.brush);
            self.mantel = museumObject(A.MANTEL, 45, 505, 300, 185, True, self.brush.RED, self.brush);
            self.bananas = museumObject(A.BANANAS, 355, 548, 170,120, True, self.brush.YELLOW, self.brush);
            self.bolsa = museumObject(A.BOLSA, 583, 520, 195,170, True, self.brush.BLUE, self.brush);
            self.tortuga = museumObject(A.TORTUGA, 815, 570, 150,100, True, self.brush.GREEN, self.brush);
            self.paintObjectList.append(self.casaLake);
            self.paintObjectList.append(self.globo);
            self.paintObjectList.append(self.cometa);
            self.paintObjectList.append(self.juncos);
            self.paintObjectList.append(self.pez);
            self.paintObjectList.append(self.plantasFlot);
            self.paintObjectList.append(self.muelle);
            self.paintObjectList.append(self.bote);
            self.paintObjectList.append(self.mantel);
            self.paintObjectList.append(self.bananas);
            self.paintObjectList.append(self.bolsa);
            self.paintObjectList.append(self.tortuga);
        self.allSprites.add(self.paintObjectList);
        self.remainList = self.paintObjectList[:];
