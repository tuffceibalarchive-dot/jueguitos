# -*- coding: utf-8 -*- 

'''
Created on 31/12/2012

@author: Gus
'''

import pygame;
from api.CGameState import cGameState;
from api.CGame import cGame;
from api.CTutorial import Tutorial;
from api.CSpriteStripAnim import SpriteStripAnim;
import Assets.Assets as A; 
import Assets.AudioAssets as Audio;
import game.states.CMainMenu;
import game.states.CAlbum
from api.CMap import cMap;
from CPlayer import Player;
import game.states.CInterval;
from CMouse import cMouse;
from api.CGameMessage import cGameMessage;
from api.CPause import cPause;
import random;

class MedalAwarded(pygame.sprite.DirtySprite):
    def __init__(self, x, y, medal):
        pygame.sprite.DirtySprite.__init__(self);
        self.medalLst = SpriteStripAnim(A.MEDALSIGN, (0,0,280,300), 3, (0,0,0));
        self.SetMedalSign(medal);
        self.rect = self.image.get_rect();
        self.rect.topleft = (x,y);
    def SetMedalSign(self, medal):
        if(medal == 0):
            self.image = self.medalLst.getImageByIndex(0);
        elif(medal == 1):
            self.image = self.medalLst.getImageByIndex(1);
        elif(medal == 2):
            self.image = self.medalLst.getImageByIndex(2);
    def SetCoords(self, x, y):
        self.rect.topleft = x,y;
    def destroy(self):
        self.medalLst = None;
        self.image = None;
        self.rect = None;
        
class AchievementUnlocked(pygame.sprite.DirtySprite):
    def __init__(self, x, y):
        pygame.sprite.DirtySprite.__init__(self);
        self.image = pygame.Surface.convert_alpha(pygame.image.load(A.ACHIEVEMENT));
        self.rect = self.image.get_rect();
        self.rect.topleft = (x,y);
    def SetCoords(self, x, y):
        self.rect.topleft = x,y;
    def destroy(self):
        self.image = None;
        self.rect = None;
        
class Cartelito(pygame.sprite.DirtySprite):
    def __init__(self, performance):
        pygame.sprite.DirtySprite.__init__(self);
        self.cartelitoLst = SpriteStripAnim(A.CARTELITO, (0,0,50,75), 3, (0,0,0));
        self.SetPerformanceSign(performance);
        self.rect = self.image.get_rect();
    def SetPerformanceSign(self, performance):
        if(performance == 1):
            self.image = self.cartelitoLst.images[0];
        elif(performance == 2):
            self.image = self.cartelitoLst.images[1];
        elif(performance == 3):
            self.image = self.cartelitoLst.images[2];
    def SetCoords(self, x,y):
        self.rect.topleft = x,y;
    def destroy(self):
        self.cartelitoLst = None;
        self.image = None;
        self.rect = None;
        
#-----------------Museum class for Sprite---------------#
class museo(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self);
        self.image = pygame.Surface.convert_alpha(pygame.image.load(A.MUSEO));
        self.rect = self.image.get_rect();
    def setCords(self,x,y):
        self.rect.topleft = x,y
    def destroy(self):
        self.image = None;
        self.rect = None;
#------------------------------------------------------#
        
class cLevelState(cGameState):
    
    
    def __init__(self, coming = False):
        # Backgroung music
        self.music = Audio.MUSICTOWN;
        # Loading file & playing music
        pygame.mixer.music.load(self.music)
        pygame.mixer.music.play();
        if(cGame.inst().cProgressSave.audioOn == False):
            pygame.mixer.music.pause();
        self.name = "town";
        self.isFirstPlay = cGame.inst().cProgressSave.config["firstTimeTuto"];
        self.picLst = cGame.inst().cProgressSave.pics;
        #----------------Game Progress control---------------#
        self.comingFromGame = coming;
        self.medalSign = None;
        self.piquitoOutro = None;
        self.piquitoYahoo = None;
        self.stagesPassed = cGame.inst().cProgressSave.stagesPassed;
        if(self.stagesPassed["circus"] and self.stagesPassed["museum"] and self.stagesPassed["garden"] and self.stagesPassed["farm"]):    
            cGame.inst().cProgressSave.DeliverMedal();
            self.piquitoYahoo = pygame.mixer.Sound(Audio.PIQUITOYAHOO);
            if(self.picLst["vecino00"] and self.picLst["vecino01"] and
               self.picLst["vecino02"] and self.picLst["vecino03"] and
               self.picLst["vecino04"]):
                if(self.picLst["gameCompleted"] == False):
                    cGame.inst().cProgressSave.gameCompleted = True;
                    cGame.inst().UnlockPic("gameCompleted");
                    cGame.inst().cProgressSave.newPic = True; 
                    if(cGame.inst().cProgressSave.fxOn):   
                        self.piquitoOutro = pygame.mixer.Sound(Audio.OUTRO);
                        
        self.createTownMessages();    
        self.keyPressed = False;
        self.map = cMap("town");
        self.selectedCharacter = cGame.inst().cProgressSave.characterSelected;
        self.display = cGame.inst().getDisplay();
        self.townMap = A.townMap;        
        self.player = Player(self.map, cGame.inst().cProgressSave.playerLastPos);
        self.lastposX = (0,0);
        self.museo = museo();
        self.museo.setCords(0, 492);
        self.mouse = cMouse();
        self.mouse.update();
        self.mPause = cPause(self, self.mouse);
        self.allSprites = cGame.inst().getContainer();
        #Cartelitos de pantallas pasadas
        self.cartelitoCircus = None;
        self.cartelitoFarm = None;
        self.cartelitoGarden = None;
        self.cartelitoMuseum = None;
        self.SpriteRectangles = None;
        self.StagePassedSigns();
        self.allSprites.add(self.player, self.museo);
        if(cGame.inst().cProgressSave.newMedal):
            self.medalSign = MedalAwarded(470, 150, cGame.inst().cProgressSave.medal);
            cGame.inst().cProgressSave.newMedal = False;
            self.allSprites.add(self.medalSign);
            self.piquitoYahoo.play();
        if(cGame.inst().cProgressSave.newPic and self.medalSign == None):
            self.achievement = AchievementUnlocked(535, 5);
            self.allSprites.add(self.achievement);
        else:
            self.achievement = None;
        #        self.allSprites.add(self.mouse);
        #---------------Game messages creation------------------#
        self.message = None;
        self.tuto = None;
        self.inGardenDoor = False;
        self.inCircDoor = False;
        self.inFarmDoor = False;
        self.inMuseumDoor = False;
        self.signAdded = False;
        self.distractorSign = cGameMessage("pet", ["Parece que un vecino", "precisa de tu ayuda", u"¡".format(chr(0xc3)) + "Vamos!"], self );
        #---------------Voices-------------------#
        self.piquitoIntro = None;
        self.distractorCount = 0;
        self.inADoor = False;
        self.renderSign = 0;
        self.display.blit(self.townMap, (0,0));
        pygame.display.flip();
        self.flipTimer = 0;
        self.medalSignTimer = 0;
        self.started = False;
        self.distractorNow = False;
        self.start();
            
        
    def start(self):
        """ sets up the sprite groups
            begins the main loop """
        self.pause=False
        if(self.isFirstPlay):
            self.createTuto();
        elif(cGame.inst().cProgressSave.gameCompleted):
            if(self.piquitoOutro != None):
                self.piquitoOutro.play();
        self.started = True;
    def eventUpdate(self):
        if(self.started):
            if(self.pause != True):
                if(self.tuto == None and self.distractorNow != True): 
                    self.allSprites.update();        
                for event in pygame.event.get():
                    #handle basic events
                    if event.type == pygame.QUIT:
                        cGame.inst().keepGoing = False;
                    if event.type==pygame.KEYDOWN:
                        self.keyPressed = True;             
                        if event.key==pygame.K_ESCAPE:
                            self.pause = True;   
                        #Check if player can proceed into a mini game and if so, save players last position.    
                        if event.key == pygame.K_SPACE:
                            if self.inGardenDoor :
                                self.savePlayerPos();   
                                self.loadingTransition();  
                                cGame.inst().setState(game.states.CInterval.cInterval("gardenInterval"));
            
                            elif self.inMuseumDoor:
                                self.savePlayerPos(); 
                                self.loadingTransition();
                                cGame.inst().setState(game.states.CInterval.cInterval("museumInterval"));
                                
                            elif self.inCircDoor:
                                self.savePlayerPos(); 
                                self.loadingTransition();
                                cGame.inst().setState(game.states.CInterval.cInterval("circusInterval"));
                                
                            elif self.inFarmDoor:
                                self.savePlayerPos();
                                self.loadingTransition();
                                cGame.inst().setState(game.states.CInterval.cInterval("farmInterval"));
        
                            elif(self.tuto != None):
                                self.removeTuto();
                            elif(self.distractorNow == True):
                                self.loadingTransition();
                                cGame.inst().setState(game.states.CInterval.cInterval("distractorInteval"));
                    if event.type == pygame.KEYUP:
                        self.keyPressed = False;
                    
            else:
                self.pauseLogic();             
                    
                        
    def update(self):
        if(self.pause != True and self.tuto == None and self.distractorNow == False): 
            if(self.medalSign != None):
                self.medalSignTimer += 1;
                if(self.medalSignTimer > 30*3):
                    self.allSprites.remove(self.medalSign);
                    self.medalSign.destroy();
                    self.medalSign = None;
            self.allSprites.clear(self.display, self.townMap);
            self.checkDoorsAndSigns(); 
            if(cGame.inst().cProgressSave.config["distractorOn"]):           
                self.checkDistractor();
        else:
            self.mPause.spriteList.clear(self.display, self.townMap);
            
        if(cGame.inst().cProgressSave.audioOn):
            if(pygame.mixer.music.get_busy() == False):
                pygame.mixer.music.play();

    
    def render(self):
        if(self.pause != True):  
                self.flipTimer += 1;  
                self.SpriteRectangles = self.allSprites.draw(self.display);
                pygame.display.update(self.SpriteRectangles);
                if(self.flipTimer >= 30):
                    self.display.blit(self.townMap, (0,0));
                    for self.sprite in self.allSprites:
                        self.display.blit(self.sprite.image, (self.sprite.rect.topleft))
                    pygame.display.flip();
                    self.flipTimer = 0;
        else:
            self.SpriteRectangles = self.mPause.spriteList.draw(self.display);
            pygame.display.update(self.SpriteRectangles);
            
    
    def pauseLogic(self):
        self.mPause.spriteList.update();
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    self.pause = False;
                    self.display.blit(self.townMap, (0,0));
                    pygame.display.flip();
            if event.type == pygame.MOUSEBUTTONDOWN:
                if(self.mPause.btnDistractorOnOff.pressed()):          
                    self.mPause.btnDistractorOnOff.changeSetup();
                elif(self.mPause.btnGotoAlbum.pressed()):
                    pygame.mixer.music.stop();
                    self.music = None;
                    self.savePlayerPos();
                    self.loadingTransition();
                    cGame.inst().setState(game.states.CAlbum.cAlbum(1, "town"));
                elif(self.mPause.btnGotoMenu.pressed()):
                    pygame.mixer.music.stop();
                    self.music = None;
                    self.savePlayerPos();
                    self.loadingTransition();
                    cGame.inst().setState(game.states.CMainMenu.cMainMenu());
                
                    
                                    
    def checkDoorsAndSigns(self):
        #----------------Check if player's in doors entries-----------------#
            if((self.player.centerX, self.player.centerY) == self.map.museumDoor or
               (self.player.centerX, self.player.centerY) == self.map.museumDoor2):
                if(self.message == None and self.medalSign == None and self.comingFromGame != True):
                    self.message = self.museumSign;
                    self.addSign();
                    
                self.inMuseumDoor = True;
            else:
                self.inMuseumDoor = False;

                
            if((self.player.centerX, self.player.upY) == self.map.circDoor):
                if(self.message == None and self.medalSign == None and self.comingFromGame != True):
                    #self.circusYes = cGameMessage("circus", [u"¡".format(chr(0xc3)) + "Bienvenido al Circo!"], self);
                    self.message = self.circusSign;
                    self.addSign();
                self.inCircDoor = True;
            else:
                self.inCircDoor = False;
                
            if((self.player.centerX, self.player.centerY) == self.map.gardenDoor or
               (self.player.centerX, self.player.centerY) == self.map.gardenDoor2):
                
                if(self.message == None and self.medalSign == None and self.comingFromGame != True):
                    self.message = self.gardenSign;    
                    self.addSign();
                self.inGardenDoor= True;
            else:
                self.inGardenDoor = False;

                    
            if((self.player.centerX, self.player.centerY) == self.map.farmDoor or
               (self.player.centerX, self.player.centerY) == self.map.farmDoor2):

                if(self.message == None and self.medalSign == None and self.comingFromGame != True):
                    #if(cGame.inst().cProgressSave.farmOpen):    
                    self.message = self.farmSign;
                    self.addSign();
                self.inFarmDoor = True;
            else:
                self.inFarmDoor = False;
                        
            if(self.inCircDoor == False and self.inFarmDoor == False and
                self.inGardenDoor == False and self.inMuseumDoor == False):
                self.inADoor = False;
                self.comingFromGame = False;
                if(self.message != None and self.message.sign.mType != "pet"):
                    self.removeMessage();
            else:
                self.inADoor = True;
    def checkDistractor(self):
        if(self.inADoor == False):
            self.distractorCount +=1;
            if(self.distractorCount >= 8 * 30):
                self.distractorChance = random.randint(0, 1);
                if(self.distractorChance == 1):
                    self.savePlayerPos();
                    self.message = self.distractorSign;
                    self.addSign();
                    self.distractorNow = True;
                self.distractorCount = 0;

    def createTuto(self):
        self.tuto = Tutorial(self.allSprites, self);
        if(cGame.inst().cProgressSave.fxOn):
            self.piquitoIntro = pygame.mixer.Sound(Audio.INTRO);
            self.piquitoIntro.play();
    def removeTuto(self):
        cGame.inst().cProgressSave.config["firstTimeTuto"] = False;
        self.isFirstPlay = cGame.inst().cProgressSave.config["firstTimeTuto"];
        self.tuto.destroy();
        self.tuto = None;            
                
    def savePlayerPos(self):
        cGame.inst().cProgressSave.playerLastPos = ((self.player.rect.centerx,
                                                      self.player.rect.centery)); 
    def addSign(self):
        if(self.signAdded == False):
            self.allSprites.add(self.message.sign, self.message.bust, self.message.text);
            self.signAdded = True;
    
    def removeMessage(self):
        if(self.message != None):
            self.allSprites.remove(self.message.sign, self.message.bust, self.message.text);
        self.message = None;     
        self.signAdded = False; 
        self.comingFromGame = False;
        #---------------------------------------------------------#        
    
    def createTownMessages(self):
        self.museumSign = None;
        self.gardenSign = None;
        self.circusSign = None;
        self.farmSign = None;
        if(cGame.inst().cProgressSave.stagesPassed["circus"]):
            self.circusSign = cGameMessage("circus", [u"¡".format(chr(0xc3)) + "gracias por ayudarme", "con los animalitos!",
                                                       "Vuelve cuando", "quieras y jugaremos", "denuevo."], self);
        else:
            self.circusSign = cGameMessage("circus", [u"¡".format(chr(0xc3)) + "bienvenido al circo!", "vamos a contar,","sumar y restar",
                                                      "mientras me ayudas", "con los animales."], self);
        if(cGame.inst().cProgressSave.stagesPassed["museum"]):
            self.museumSign = cGameMessage("museum", [u"¡".format(chr(0xc3)) + "gracias por la ayuda!", "vuelve cuando","quieras y pintaremos","denuevo."], self);
        else:
            self.museumSign = cGameMessage("museum", [u"¡".format(chr(0xc3)) + "te doy la bienvenida","al Museo del barrio!","necesito ayuda para",
                                                       "terminar mis pinturas.",u"¿".format(chr(0xc3)) + "puedes ayudarme?"], self);
        if(cGame.inst().cProgressSave.stagesPassed["garden"]):
            self.gardenSign = cGameMessage("garden", [u"¡".format(chr(0xc3)) + "gracias por la ayuda!","vuelve cuando gustes","y trabajaremos","juntos otra vez."], self);
        else:
            self.gardenSign = cGameMessage("garden", [u"¡".format(chr(0xc3)) + "Bienvenido al jard" + u"í".format(chr(0xc3)) + "n!",
                                                      "trabajemos juntos","para limpiarlo.", u"¡".format(chr(0xc3)) +"vamos!"], self);
        if(cGame.inst().cProgressSave.stagesPassed["farm"]):
            self.farmSign = cGameMessage("farm", [u"¡".format(chr(0xc3)) + "No podr"+ u"í".format(chr(0xc3))+"a haberlo",
                                                  "hecho sin tu ayuda!", u"¡".format(chr(0xc3)) + "muchas gracias!",
                                                   u"¡".format(chr(0xc3))+"Siempre podr"+u"á".format(chr(0xc3)) +"s", "volver!" ], self);
        else:
            self.farmSign = cGameMessage("farm", [u"¡".format(chr(0xc3)) + "bienvenido a la","huerta!", "me faltan pedidos",
                                                   "por completar y", "estoy sola con", "mis animales.",u"¿".format(chr(0xc3)) +"me ayudas?" ], self);
                
    def destroyTownMessages(self):
        if(self.museumSign != None):
            self.museumSign.destroy();
        if(self.circusSign != None):
            self.circusSign.destroy();
        if(self.gardenSign != None):
            self.gardenSign.destroy();
        if(self.farmSign != None):
            self.farmSign.destroy();
        self.distractorSign.destroy();
        self.museumSign = None;
        self.gardenSign = None;
        self.circusSign = None;
        self.farmSign = None;
        self.distractorSign = None;
    
    def StagePassedSigns(self):
        if(self.stagesPassed["circus"]):
            self.cartelitoCircus = Cartelito(cGame.inst().cProgressSave.circusRate);
            self.cartelitoCircus.SetCoords(160, 190);
            self.allSprites.add(self.cartelitoCircus);
        if(self.stagesPassed["museum"]):
            self.cartelitoMuseum = Cartelito(cGame.inst().cProgressSave.museumRate);
            self.cartelitoMuseum.SetCoords(238, 690);
            self.allSprites.add(self.cartelitoMuseum);
        if(self.stagesPassed["garden"]):
            self.cartelitoGarden = Cartelito(cGame.inst().cProgressSave.gardenRate);
            self.cartelitoGarden.SetCoords(690, 785);
            self.allSprites.add(self.cartelitoGarden);
        if(self.stagesPassed["farm"]):
            self.cartelitoFarm = Cartelito(cGame.inst().cProgressSave.farmScore);
            self.cartelitoFarm.SetCoords(1040, 300);
            self.allSprites.add(self.cartelitoFarm);
    def DestroyPassedSigns(self):
        if(self.cartelitoCircus != None):
            self.cartelitoCircus.destroy();
            self.cartelitoCircus = None;
        if(self.cartelitoFarm != None):
            self.cartelitoFarm.destroy();
            self.cartelitoFarm = None;
        if(self.cartelitoGarden != None):
            self.cartelitoGarden.destroy();
            self.cartelitoGarden = None;
        if(self.cartelitoMuseum != None):
            self.cartelitoMuseum.destroy();
            self.cartelitoMuseum = None;
            
    def destroy(self):
        #SAVE DATA BEFORE DESTROY EVERYTHING
        cGame.inst().cProgressSave.SaveValues();
        self.SpriteRectangles = None;
        if(self.achievement != None):
            self.achievement.destroy();
            self.achievement = None;
        if(self.medalSign != None):
            self.medalSign.destroy();
            self.medalSign = None;
        self.townMap = None;
        self.museo.destroy();
        self.museo = None;
        self.player.destroy();
        self.player = None;
        self.mouse.destroy();
        self.mouse = None;
        self.display = None;
        self.map.destroy();
        self.map = None;
        self.loading = None;
        self.message = None;
        self.lastposX = None;
        self.destroyTownMessages();
        self.DestroyPassedSigns();
        self.mPause.destroy();
        self.mPause = None;
        self.allSprites.empty();
        self.allSprites = None;
        self.SpriteRectangles = None;
        self.name = None;
        self.isFirstPlay = None;
        self.picLst = None;
        self.stagesPassed = None;
        self.keyPressed = None;
        self.selectedCharacter = None;
        self.message = None;
        self.inGardenDoor = None;
        self.inCircDoor = None;
        self.inFarmDoor = None;
        self.inMuseumDoor = None;
        self.signAdded = None;
        self.distractorCount = None;
        self.inADoor = None;
        self.renderSign = None;
        self.medalSignTimer = None;
        self.pause=None;
        self.comingFromGame = None;
        if(self.piquitoIntro != None):
            self.piquitoIntro.stop();    
            self.piquitoIntro = None;
        if(self.piquitoOutro != None):
            self.piquitoOutro.stop();
            self.piquitoOutro = None;
        self.started = None;
        self.flipTimer = None;
        self.distractorNow = None;
    
           

