# -*- coding: utf-8 -*- 
'''
Created on 14/03/2013

@author: Gus
'''
import pygame;
from api.CGameState import cGameState;
from api.CGame import cGame;
from api.CSpriteSheet import spritesheet;
from api.CMap import cMap;
from api.CGameMessage import cGameMessage;
from api.CText import cText;
from api.ElephantManager import elephantManager;
from api.CTutorial import Tutorial;
from CMouse import cMouse;
from api.CPause import cPause;
import Assets.AudioAssets as Audio;
import Assets.Assets as A;
import game.states.CInterval;
import random;
        
class NumberSprite(pygame.sprite.DirtySprite):
    def __init__(self, num, x,y, letterSize, spriteGroup, circus):
        pygame.sprite.DirtySprite.__init__(self);
        self.numVal = num;
        self.circus = circus;
        self.strNum = str(num);
        self.size = letterSize;
        self.group = spriteGroup;
        self.font= pygame.font.Font(A.DEJAVUFONT, self.size);
        self.image = pygame.Surface.convert_alpha(self.font.render(self.strNum, 1, (255,255,255)));
        self.rect = self.image.get_rect();
        if(self.circus.circusType != "count"):
            if(self.numVal < 10):
                self.setCoords(x + 85, y);
            else:
                self.setCoords(x + 28, y);
        else:
            self.SetCenterReg(x, y);
        self.group.add(self);
    def setCoords(self, x, y):
        self.rect.topleft = x, y;
    def SetCenterReg(self, x, y):
        self.rect.center = x,y;    
    def destroy(self):
        self.group.remove(self);
        self.group = None;
        self.image = None;
        self.rect = None;
        self.numVal = None;
        self.circus = None;
        self.strNum = None;
        self.size = None;
        self.font = None;
        
        
class CheckBtn(pygame.sprite.DirtySprite):
    def __init__(self, (x,y), numberOfSprites):
        pygame.sprite.DirtySprite.__init__(self);
        self.checkBtnSheet = spritesheet(A.CHECKBTN);
        self.checkBtnList = self.checkBtnSheet.load_strip((0,0,180,180), numberOfSprites, colorkey = (0,0,0));
        self.changeImg(0);
        self.rect = self.image.get_rect();
        self.rect.topleft = (x,y);
    def changeImg(self, num):
        self.image = self.checkBtnList[num];
        
    def pressed(self):
        self.mousePos = pygame.mouse.get_pos();
        if self.mousePos[0] > self.rect.topleft[0]:
            if self.mousePos[1] > self.rect.topleft[1]:
                if self.mousePos[0] < self.rect.topleft[0] + self.rect[2]:
                    if self.mousePos[1] < self.rect.topleft[1] + self.rect[3]:
                        return True
                    else: return False
                else: return False
            else: return False
        else: return False
        pass   
    def destroy(self):
        self.checkBtnSheet = None;
        self.checkBtnList = None;
        self.image = None;
        self.rect = None;
        
class MathSign(pygame.sprite.DirtySprite):
    def __init__(self,(x,y)):
        pygame.sprite.DirtySprite.__init__(self);
        self.mathSignsSheet = spritesheet(A.MATHSIGNS);
        self.mathSignsList = self.mathSignsSheet.load_strip((0,0, 140,140), 2, colorkey = (0,0,0));
        self.changeImg(0);
        self.rect = self.image.get_rect();
        self.rect.topleft = (x,y);
    def changeImg(self, num):
        self.image = self.mathSignsList[num];       
    def destroy(self):
        self.mathSignsSheet = None;
        self.mathSignsList = None;
        self.image = None;
        self.rect = None;
        
class Tigers(pygame.sprite.DirtySprite):
    def __init__(self, x, y, isChangeable, animalNumber):
        pygame.sprite.DirtySprite.__init__(self);
        self.randomAnimals= animalNumber;
        if(self.randomAnimals == 0): 
            self.tigersSheet = spritesheet(A.SUMTIGERS);
        elif(self.randomAnimals == 1):
            self.tigersSheet = spritesheet(A.SUMZEBRAS);
        elif(self.randomAnimals == 2):
            self.tigersSheet = spritesheet(A.SUMELEPHANTS);
        elif(self.randomAnimals == 3):
            self.tigersSheet = spritesheet(A.SUMLIONS);
        self.tigersList = self.tigersSheet.load_strip((0,0,222,256), 10, colorkey = (0,0,0));
        self.changeImg(0);
        self.rect = self.image.get_rect();
        self.cardNum = 0;
        self.rect.topleft = (x,y);
        self.isChangeable = isChangeable;
    def updateNum(self):
        if(self.isChangeable):
            if(self.pressed()):
                if(self.cardNum < 9):
                    self.cardNum += 1;
                    self.changeImg(self.cardNum);    
                else:
                    self.cardNum = 0;
                    self.changeImg(self.cardNum);
    def pressed(self):
        self.mousePos = pygame.mouse.get_pos();
        if self.mousePos[0] > self.rect.topleft[0]:
            if self.mousePos[1] > self.rect.topleft[1]:
                if self.mousePos[0] < self.rect.topleft[0] + self.rect[2]:
                    if self.mousePos[1] < self.rect.topleft[1] + self.rect[3]:
                        return True
                    else: return False
                else: return False
            else: return False
        else: return False
        pass            
    def changeImg(self, num):
        self.image = self.tigersList[num];
    def resetCard(self):
        self.cardNum = 0;
        self.changeImg(self.cardNum);
    def destroy(self):
        self.tigersSheet = None;
        self.tigersList = None;
        self.image = None;
        self.rect = None;
        self.randomAnimals = None;
        self.cardNum = None;
        self.isChangeable = None;
        
class cCircus(cGameState):
    
    
    def __init__(self, circType):
        #Load music and start playing
        self.fxOn = cGame.inst().cProgressSave.fxOn;
        pygame.mixer.music.load(Audio.MUSICCIRCUS);
        pygame.mixer.music.play();
        if(cGame.inst().cProgressSave.audioOn == False):
            pygame.mixer.music.pause();
        #Load FX
        self.correct = pygame.mixer.Sound(Audio.PAIRMATCH);
        self.fatimaOk1 = pygame.mixer.Sound(Audio.FATIMAGENIAL);
        self.fatimaOk2 = pygame.mixer.Sound(Audio.FATIMABIENHECHO);
        self.BRONZE = 1;
        self.SILVER = 2;
        self.GOLD = 3;
        self.MAXERRORS = 13;
        self.MINERRORS = 6;
        self.INTRO = 0;
        self.GAME = 1;
        self.END = 2;
        self.TUTO = 3;
        self.name = "circ";
        self.selectedCharacter = cGame.inst().cProgressSave.characterSelected;
        self.difficulty = cGame.inst().cProgressSave.difficultySelected;
        self.display = cGame.inst().getDisplay();       
        self.circusType = circType;
        pygame.mouse.set_visible(False);
        self.allSprites = cGame.inst().getContainer();
        self.message = None;
        self.tuto = None;
        self.gameEnded = False;
        self.gameState = None;
        self.mMouse = cMouse("staff");
        self.mMouse.update();
        self.mPause = cPause(self, self.mMouse);
        self.correctAnswers = 0;
        self.errors = 0;
        self.round = 0;
        self.greetingText = None;
        self.greeting = False;
        self.greetingNot = False;
        self.greetTime = 0;
        self.eqCreated = False;
        self.answerNum = None;
        self.nowResta = False;
        self.randomAnimals = None;
        self.elephantManager = None;
        self.SpriteRectangles = None;
        if(self.circusType == "count"):
            self.choiceNum = 0;
            self.solutionNum = 0;
            self.grilla = cMap("circus");
            self.elephantManager = elephantManager(self.allSprites, self.grilla, self);
            self.checkBtn = CheckBtn((424,628), 3);
            self.allSprites.add(self.checkBtn, self.mMouse); 
        else:
            self.randomAnimals  = random.randint(0,3);
            self.checkBtn = CheckBtn((910,600), 3);
            self.mathSign = MathSign((290,270));
            self.tigersMed = Tigers(462, 210, True, self.randomAnimals);
            self.tigersLeft = Tigers(34, 210, False, self.randomAnimals);
            self.allSprites.add(self.tigersLeft, self.tigersMed, self.mathSign, self.checkBtn, self.mMouse);
            self.leftNum = None;
        self.flipTimer = 0;
        self.started = False;
        self.start();
        
    def start(self):
        """ sets up the sprite groups
            begins the main loop """
        self.pause=False
        self.abort=False
        self.gameEnded = False;
        self.setState(self.TUTO); 

        if(self.circusType == "count"):
            self.circusBackground = A.circusBackgroundCount;
        else:
            self.circusBackground = A.circusBackground;
        self.display.blit(self.circusBackground, (0,0));
        pygame.display.flip(); 
        self.started = True;
        
    def eventUpdate(self):
        if(self.started):
            if(self.pause != True):
                for event in pygame.event.get():
                    #handle basic events
                    if event.type == pygame.QUIT:
                        cGame.inst().keepGoing = False;
                    if event.type==pygame.KEYDOWN:
                        if event.key==pygame.K_ESCAPE:
                            self.pause = True;
                        if(event.key==pygame.K_SPACE):
                            if(self.message != None):
                                self.removeMessage();
                                if(self.gameState == self.INTRO):
                                    self.setState(self.GAME);
                                    if(self.nowResta):
                                        self.nowResta = False;
                            if(self.tuto != None):
                                self.removeTuto();
                                if(self.gameState == self.TUTO):
                                    self.allSprites.clear(self.display, self.circusBackground);
                                    self.setState(self.INTRO);
                    if event.type==pygame.MOUSEBUTTONDOWN:
                        if(self.circusType == "count"):
                            if(len(self.elephantManager.elephantList) <= 25):
                                self.elephantManager.CheckPressed();
                                self.allSprites.remove(self.mMouse);
                                self.allSprites.add(self.mMouse);
                            if(pygame.mouse.get_pos() >= (600, 100) and pygame.mouse.get_pos() <= (1100, 600) and
                               self.elephantManager.elephantSent == False):
                                self.elephantManager.RemoveElephant();
                                if(self.choiceNum > 0):
                                    self.choiceNum -= 1;
                            if(self.checkBtn.pressed()):
                                self.checkSolution();
                        else:
                            if(self.tigersMed.pressed()):
                                self.tigersMed.updateNum();
                            elif(self.checkBtn.pressed()):
                                self.checkSolution();
            else:
                self.pauseLogic();
                            
    def update(self):
        if(self.pause != True):
            if(self.message == None and self.gameState == self.GAME):
                self.allSprites.clear(self.display, self.circusBackground);
                self.allSprites.update();
                if(self.circusType == "count"):
                    if(self.round <= 4 and self.correctAnswers < 4):
                        self.createCountNum();
                        self.greetingFunc();
                        self.greetingNotFunc();
                        self.elephantManager.update();
                    else:
                        self.gameEnd();
                else:
                    if(self.round <= 6 and self.correctAnswers < 6):
                        if(self.round > 3 and self.nowResta):
                            self.setState(self.TUTO);
                        self.createEq();
                        self.greetingFunc();
                        self.greetingNotFunc();
                    else:
                        self.gameEnd();
        else:
            self.mPause.spriteList.clear(self.display, self.circusBackground);
        if(cGame.inst().cProgressSave.audioOn):
            if(pygame.mixer.music.get_busy() == False):
                pygame.mixer.music.play(); 
            
               
        #---------------------------------------------------------#        
    def render(self):
        if(self.pause == False):
            self.flipTimer +=1;
            self.SpriteRectangles = self.allSprites.draw(self.display);
            pygame.display.update(self.SpriteRectangles);
            if(self.flipTimer >= 30):
                self.display.blit(self.circusBackground, (0,0));
                for self.sprite in self.allSprites:
                    self.display.blit(self.sprite.image, (self.sprite.rect.topleft))
                pygame.display.flip();
                self.flipTimer = 0; 
        else:
            self.SpriteRectangles = self.mPause.spriteList.draw(self.display);
            pygame.display.update(self.SpriteRectangles);
            
    def pauseLogic(self):
        self.mPause.spriteList.update();
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    self.pause = False;
                    self.display.blit(self.circusBackground, (0,0));
                    pygame.display.flip();
            if event.type == pygame.MOUSEBUTTONDOWN:
                if(self.mPause.btnContinue.pressed()):
                    self.pause = False;
                    self.display.blit(self.circusBackground, (0,0));
                    pygame.display.flip();
                elif(self.mPause.btnQuit.pressed()):
                    self.loadingTransition();
                    cGame.inst().setState(game.states.CInterval.cInterval("circusInterval", exited = True));
                elif self.mPause.audioBtns.btnFx.pressed():
                    self.mPause.audioBtns.btnFx.changeSetup();
                    self.fxOn = cGame.inst().cProgressSave.fxOn;
                    if(self.elephantManager != None):
                        self.elephantManager.fxOn = cGame.inst().cProgressSave.fxOn;
                elif(self.mPause.audioBtns.btnMusic.pressed()):
                    self.mPause.audioBtns.btnMusic.changeSetup();
                    
    def playGreet(self):
        if(cGame.inst().cProgressSave.fxOn):
            self.randomNum = random.randint(0,1);
            if(self.randomNum == 0):
                self.fatimaOk1.play();
            else:
                self.fatimaOk2.play();
    def createCountNum(self):
        if(self.eqCreated == False):
            self.elephantManager.AddElephant();
            self.elephantManager.elephantSent = False;
            self.choiceNum = 0;
            if(self.difficulty == 1):
                self.solutionNum = random.randint(1, 5);
            elif(self.difficulty == 2):
                self.solutionNum = random.randint(6, 15);
            elif(self.difficulty == 3):
                self.solutionNum = random.randint(16, 25);
            self.eqCreated = True;
            self.round += 1;
            self.answerNum = NumberSprite(self.solutionNum, 329, 247, 180, self.allSprites, self);
            self.allSprites.remove(self.mMouse);
            self.allSprites.add(self.mMouse);
            
    def createEq(self):
        if(self.eqCreated == False):
            if(self.round >= 0 and self.round < 3):
                if(self.difficulty == 1 and self.greeting == False):
                    self.a = random.randint(1, 5); 
                    self.b = random.randint(1, 5);
                elif(self.difficulty == 2 and self.greeting == False):
                    self.a = random.randint(1, 10);
                    self.b = random.randint(1, 9);
                elif(self.difficulty == 3 and self.greeting == False):
                    self.a = random.randint(11, 15);
                    self.b = random.randint(1, 5); 
                self.c = self.a + self.b;   
                self.mathSign.changeImg(0);
            elif(self.round >= 3):
                if(cGame.inst().cProgressSave.pics["circus02"] == False):    
                    cGame.inst().UnlockPic("circus02");
                    cGame.inst().cProgressSave.newPic = True;
                if(self.round == 3):
                    self.nowResta = True;           
                    self.playGreet();
                if(self.difficulty == 1 and self.greeting == False):
                    self.a = random.randint(1, 5);
                    self.b = 10;
                    while self.b > self.a:
                        self.b = random.randint(1, 5);
                elif(self.difficulty == 2 and self.greeting == False):
                    self.a = random.randint(1, 10);
                    self.b = random.randint(1, 9);
                    while self.b > self.a:
                        self.b = random.randint(1, 9);
                elif(self.difficulty == 3 and self.greeting == False):
                    self.a = random.randint(11, 15);
                    self.b = random.randint(1, 5);
                    while self.b > self.a:
                        self.b = random.randint(1, 9);
                self.c = self.a - self.b;
                self.mathSign.changeImg(1);
            self.answerNum = NumberSprite(self.c, 910, 235, 180, self.allSprites, self);
            if(self.difficulty == 1):
                self.tigersLeft.changeImg(self.a);
            else:
                self.leftNum = NumberSprite(self.a, 5, 235, 180, self.allSprites, self);
            self.round += 1;
            self.eqCreated = True;
            self.checkBtn.changeImg(0);
            self.allSprites.remove(self.mMouse);
            self.allSprites.add(self.mMouse);
                
                    
                
    def checkSolution(self):
        if(self.circusType != "count"):
            if(self.tigersMed.cardNum == self.b):
                if(self.difficulty == 1):
                    self.tigersLeft.resetCard();
                else:
                    self.leftNum.destroy();
                    self.leftNum = None;
                self.greeting = True;
                if(self.fxOn):
                    self.correct.play();
                self.correctAnswers += 1;
                self.tigersMed.resetCard();
                if(self.answerNum != None):
                    self.answerNum.destroy();
                    self.answerNum = None;
            else:
                self.errors += 1;
                self.greetingNot = True; 
        else:
            if(self.answerNum != None):
                if(self.answerNum.numVal == self.choiceNum):
                    if(self.fxOn):
                        self.correct.play();
                    self.correctAnswers += 1;
                    self.greeting = True;
                    self.elephantManager.ClearElephants();
                    self.answerNum.destroy();
                    self.answerNum = None;
                    for sprite in self.allSprites:
                        if(type(sprite) == type("Elephant")):
                            self.allSprites.remove(sprite);
                else:
                    self.errors += 1;
                    self.greetingNot = True;
 

    def greetingFunc(self):
        if(self.greeting):
            self.checkBtn.changeImg(2);
            self.greetTime +=1;
            if(self.greetingText == None):
                self.addGreet();
                if(self.circusType == "count"):
                    self.greetingText.SetCenterReg(329, 247);
                else:   
                    self.greetingText.SetCenterReg(524, 714);
        if(self.greetTime >= 2 * 30):
            self.greetingText.destroy();
            self.greetTime = 0;
            self.greeting = False;
            self.greetingText = None;
            self.eqCreated = False;
            self.checkBtn.changeImg(0);
            
    def greetingNotFunc(self):
        if(self.greetingNot):
            self.checkBtn.changeImg(1);
            self.greetTime +=1;
            if(self.greetingText == None):
                self.addGreetNot();
                if(self.circusType == "count"):
                    self.allSprites.remove(self.answerNum);
                    self.greetingText.SetCenterReg(329, 247);
                else:   
                    self.greetingText.SetCenterReg(524, 714);
        if(self.greetTime >= 2 * 30):
            self.greetingText.destroy();
            self.greetTime = 0;
            self.greetingNot = False;
            self.greetingText = None;
            self.checkBtn.changeImg(0);
            if(self.circusType == "count"):
                self.allSprites.remove(self.mMouse);
                self.allSprites.add(self.answerNum);
                self.allSprites.add(self.mMouse);
    

    def addGreet(self):
        self.randomGreet = random.randint(0, 6);
        if(self.randomGreet == 0):
            self.string = u"¡".format(chr(0xc3)) + "Genial!";
        elif(self.randomGreet == 1):
            self.string = u"¡".format(chr(0xc3)) +"Gracias!";
        elif(self.randomGreet == 2):
            self.string = u"¡".format(chr(0xc3)) + "S" + u"ú".format(chr(0xc3)) + "per!";
        elif(self.randomGreet == 3):
            self.string = u"¡".format(chr(0xc3)) + "Excelente!"
        elif(self.randomGreet == 4):
            self.string = u"¡".format(chr(0xc3)) + "Que bien!"
        elif(self.randomGreet == 5):
            self.string = u"¡".format(chr(0xc3)) + "As" + u"í".format(chr(0xc3)) + " es!";
        elif(self.randomGreet == 6):
            self.string = u"¡".format(chr(0xc3)) + "S" + u"í".format(chr(0xc3)) + "gue" + " as" + u"í".format(chr(0xc3));
        self.greetingText = cText((self.string), 1, None, 60, self.allSprites );
        
    def addGreetNot(self):
        self.randomGreet = random.randint(0,2);
        if(self.randomGreet == 0):
            self.string = u"¡".format(chr(0xc3)) + "Ups!";
        elif(self.randomGreet == 1):
            self.string = u"¡".format(chr(0xc3)) +"Casi!";
        elif(self.randomGreet == 2):
            self.string = u"¡".format(chr(0xc3)) + "Otra vez!";
        self.greetingText = cText((self.string), 1, None, 60, self.allSprites );    
    
    def setState(self, aState):
        self.gameState = aState;
        if(self.gameState == self.INTRO):
            self.gameIntro();
        elif(self.gameState == self.TUTO):
            self.createTuto();
        elif(self.gameState == self.GAME):
            pass;
                
    def gameIntro(self):
        
        self.message = cGameMessage("circus", ["Cuando est"+u"é".format(unichr(0xc3))+"s listo", "presiona la barra", "espaciadora para", "comenzar la partida"], self );
       
    def createTuto(self):
        self.tuto = Tutorial(self.allSprites, self);
        
    def removeTuto(self):
        self.tuto.destroy();
        self.tuto = None;
                  
    def gameEnd(self):
        if(self.message == None and self.gameState == self.GAME):
            if(self.gameEnded != True):
                self.playGreet();
                if(self.errors <= 0):    
                    self.message = cGameMessage("circus", [u"¡".format(chr(0xc3)) + "Perfecto!",
                                                           "Has conseguido", "terminar sin errores",
                                                            u"¡".format(chr(0xc3)) + "Excelente trabajo!"], self);
                elif(self.errors == 1):
                    self.message = cGameMessage("circus", [u"¡".format(chr(0xc3)) + "Muy buen esfuerzo!",
                                                           "Has conseguido", "terminar con 1 error",
                                                            u"¡".format(chr(0xc3)) + "Muy bien hecho!"], self);
                elif(self.errors > 1):
                    self.message = cGameMessage("circus", [u"¡".format(chr(0xc3)) + "Muy buen esfuerzo!",
                                                           "Has conseguido", "terminar con " + str(self.errors) + " errores",
                                                            u"¡".format(chr(0xc3)) + "Muy bien!"], self);                                         
                                                       
            self.gameEnded = True;
            if(self.message == None and self.gameEnded):
                if(self.circusType == "count"):
                    if(cGame.inst().cProgressSave.pics["circus01"] == False):
                        cGame.inst().UnlockPic("circus01");
                        cGame.inst().cProgressSave.newPic = True;
                    self.GetPerformance();
                    self.loadingTransition();
                    cGame.inst().setState(game.states.CCircus.cCircus("sum"));
                else:
                    if(cGame.inst().cProgressSave.pics["circus03"] == False):
                        cGame.inst().UnlockPic("circus03");
                        cGame.inst().cProgressSave.newPic = True;
                    cGame.inst().cProgressSave.stagesPassed["circus"] = True;
                    self.GetPerformance();
                    self.loadingTransition();
                    cGame.inst().setState(game.states.CInterval.cInterval("circusInterval", True));
                    
    def GetPerformance(self):
        self.finalScore = 0;
        if(self.errors > self.MAXERRORS):
            self.finalScore = self.BRONZE;
        elif(self.errors <= self.MAXERRORS and self.errors > self.MINERRORS):
            self.finalScore = self.SILVER;
        elif(self.errors <= self.MINERRORS):
            self.finalScore = self.GOLD;
        if(self.circusType == "count"):
            if(cGame.inst().cProgressSave.circusScore[0] != None):
                if(self.finalScore > cGame.inst().cProgressSave.circusScore[0]):
                    cGame.inst().cProgressSave.circusScore[0] = self.finalScore;
            else:
                cGame.inst().cProgressSave.circusScore[0] = self.finalScore;
        elif(self.circusType == "sum"):
            if(cGame.inst().cProgressSave.circusScore[1] != None):
                if(self.finalScore > cGame.inst().cProgressSave.circusScore[1]):
                    cGame.inst().cProgressSave.circusScore[1] = self.finalScore;
            else:
                cGame.inst().cProgressSave.circusScore[1] = self.finalScore;
        if(cGame.inst().cProgressSave.stagesPassed["circus"]):
            self.rateToDeliver = cGame.inst().cProgressSave.GetPerformanceRate("circus");
            cGame.inst().cProgressSave.circusRate = self.rateToDeliver;
    def removeMessage(self):
        self.allSprites.remove(self.message.sign, self.message.bust, self.message.text);
        self.message.destroy();
        self.message = None;    
    def destroy(self):
        #SAVE DATA BEFORE DESTROY EVERYTHING
        cGame.inst().cProgressSave.SaveValues();
        self.circusBackground = None;
        self.mPause.destroy();
        self.mMouse.destroy();
        self.mMouse = None;
        self.checkBtn.destroy();
        self.checkBtn = None;
        if(self.randomAnimals != None):
            self.randomAnimals = None;
        if(self.greetingText != None):
            self.greetingText.destroy();
        if(self.answerNum != None):
            self.answerNum.destroy();
            self.answerNum = None;
        if(self.circusType != "count"):
            self.tigersLeft.destroy();
            self.tigersLeft = None;
            self.tigersMed.destroy();
            self.tigersMed = None;
            self.mathSign.destroy();
            self.mathSign = None;
            if(self.difficulty != 1):
                if(self.leftNum !=None):
                    self.leftNum.destroy();  
                    self.leftNum = None;  
        else:
            self.choiceNum = None;
            self.solutionNum = None;
            self.grilla.destroy();
            self.grilla = None;
            self.elephantManager.destroy();
            self.elephantManager = None;
        self.SpriteRectangles = None;
        self.allSprites.empty();
        self.allSprites = None;
        self.correct = None;
        self.fatimaOk1 = None;
        self.fatimaOk2 = None;
        self.fxOn = None;
        self.BRONZE = None;
        self.SILVER = None;
        self.GOLD = None;
        self.MAXERRORS = None;
        self.MINERRORS = None;
        self.INTRO = None;
        self.GAME = None;
        self.END = None;
        self.TUTO = None;
        self.name = None;
        self.selectedCharacter = None;
        self.difficulty = None;
        self.display = None;       
        self.circusType = None;
        self.message = None;
        self.tuto = None;
        self.gameEnded = False;
        self.gameState = None;
        self.correctAnswers = None;
        self.errors = None;
        self.round = None;
        self.greetingText = None;
        self.greeting = None;
        self.greetingNot = None;
        self.greetTime = None;
        self.eqCreated = None;
        self.answerNum = None;
        self.nowResta = None;
        self.randomAnimals = None;
        self.started = None;
        self.flipTimer = None;
        pygame.mixer.music.stop();   