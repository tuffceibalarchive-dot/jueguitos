'''
Created on Oct 19, 2013

@author: gustavogonzalezlamarque
'''
from api.CGameState import cGameState;
from api.CGame import cGame;
from CMouse import cMouse;
import Assets.Assets as A;
import Assets.AudioAssets as Audio;
import Assets.button as button;
import game.states.CMainMenu;
import pygame;

class cCredits(cGameState):
    '''
    classdocs
    '''


    def __init__(self):
        '''
        Constructor
        '''
        self.fxOn = cGame.inst().cProgressSave.fxOn;
        self.btnPlaySnd = pygame.mixer.Sound(Audio.BTNPLAY);
        self.btnHoverSnd = pygame.mixer.Sound(Audio.BTNHOVER);
        self.playedHover = False;
        # Loading file & playing music
        if(cGame.inst().cProgressSave.audioOn == False):
            pygame.mixer.music.pause();
        pygame.mouse.set_visible(False);
        self.display = cGame.inst().getDisplay();
        self.MENU = pygame.image.load(A.MENUCREDITS).convert();
        self.btnExit = button.Button(A.BTNCLOSE, 1050, 5);
        self.mMouse = cMouse();
        self.allSprites = cGame.inst().getContainer();
        self.allSprites.add(self.btnExit, self.mMouse);#----Copy the The Menu background one time so it stays behind always---#
        self.display.blit(self.MENU, (0,0));
        pygame.display.flip();
        self.allSprites.update();
        self.started = True;
        self.flipTimer = 0;
            
    def eventUpdate(self):
        if(self.started):
            self.allSprites.update();
            for event in pygame.event.get():
                if event.type == pygame.MOUSEMOTION:
                    if(self.fxOn):
                        if(self.btnExit.mouseOver()):
                            if(self.playedHover != True):
                                self.playedHover = True;
                                self.btnHoverSnd.play();
                        else:
                            self.playedHover = False;
                if event.type==pygame.MOUSEBUTTONDOWN:
                    if(self.btnExit.pressed()):
                        self.btnPlaySnd.play();
                        self.loadingTransition();
                        cGame.inst().setState(game.states.CMainMenu.cMainMenu());    

    def update(self):
        #---Erase sprites from display and refill erased rectangles with the MENU background---#
        self.allSprites.clear(self.display, self.MENU);
        if(cGame.inst().cProgressSave.audioOn):
            if(pygame.mixer.music.get_busy() == False):
                pygame.mixer.music.play();
            
    def render(self):
        self.flipTimer +=1;
        #--- Draw and save sprite rectangles list ---#
        self.SpriteRectangles = self.allSprites.draw(self.display);
        #--- Pass sprite rectangles to display.update so it flips them to the display ---#
        pygame.display.update(self.SpriteRectangles);
        if(self.flipTimer >= 30):
            self.display.blit(self.MENU, (0,0));
            for self.sprite in self.allSprites:
                self.display.blit(self.sprite.image, (self.sprite.rect.topleft))
            pygame.display.flip();
            self.flipTimer = 0; 
    def destroy(self):
        self.started = None;
        self.fxOn = None;
        self.btnHoverSnd = None;
        self.btnPlaySnd = None;
        self.playedHover = None;
        self.display = None;
        self.MENU = None;
        self.btnExit.destroy();
        self.btnExit = None;
        self.mMouse.destroy();
        self.mMouse = None;
        self.allSprites.empty();
        self.allSprites = None;
        self.flipTimer = None;