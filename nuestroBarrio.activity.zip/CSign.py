'''
Created on 28/03/2013

@author: Gus
'''
from api.CSpriteSheet import spritesheet;
import Assets.Assets as A; 
import pygame;



class sign(pygame.sprite.Sprite):
    '''
    classdocs
    '''
    def __init__(self, sType, aWidth, aHeight, aX, aY, aLevelType):
        '''
        Constructor
        '''
        self.isDead = False;
        self.mLevelType = aLevelType;
        self.mType = sType;
        self.mX = aX;
        self.mY = aY;
        pygame.sprite.Sprite.__init__(self);
        if(self.mType != "pet"):
            self.textBoxSheet = spritesheet(A.TEXTSQUARESSHEET);
            self.textBoxList = self.textBoxSheet.load_strip((0, 0, 700, 450), 4, colorkey = (0,0,0));
            if(self.mType == "farm"):
                self.image = self.textBoxList[0];
            elif(self.mType == "museum"):
                self.image = self.textBoxList[1];
            elif(self.mType == "garden"):
                self.image = self.textBoxList[2];
            elif(self.mType == "circus"):
                self.image = self.textBoxList[3];
            self.image = self.image.convert();
        else:
            self.image =  pygame.Surface.convert_alpha(pygame.image.load(A.PETMESSAGE));

        self.rect = self.image.get_rect();
        self.rect.topleft = aX, aY;

        
    def setCords(self,x,y):
        self.rect.topleft = x,y
    
    def destroy(self):
        self.mLevelType.allSprites.remove(self);
        

        
           
