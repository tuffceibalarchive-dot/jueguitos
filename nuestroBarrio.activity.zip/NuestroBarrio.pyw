'''
Created on 13/09/2012

@author: Gus
'''
#I - Import and initialize

from api.CGame import cGame;
from game.states.CMainMenu import cMainMenu;
import pygame;
import sys;

    

def main():
        # Audio initialization    
        pygame.mixer.quit();
        pygame.mixer.pre_init(44100, -16, 2, 2048);
        pygame.init();    
        cGame.inst().setState(cMainMenu());
        # prepare the game clock for this screen
        clock = pygame.time.Clock();
        
        while cGame.inst().keepGoing:
            clock.tick(30);
            cGame.inst().eventUpdate();
            cGame.inst().update();
            cGame.inst().render();
        pygame.quit();
        sys.exit();              
if __name__ == '__main__':
    main();

   

         

    
    
    
    

