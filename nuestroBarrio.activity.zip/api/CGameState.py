'''
Created on 28/12/2012

@author: Gus
'''
import Assets.Assets as A;
import pygame;
from CGame import cGame;

class cGameState:
    '''
    classdocs
    '''
    def __init__(self):
        '''
        Constructor
        '''
        pass
    def update(self):
        pass
        
    def render(self):
        pass
    
    def destroy(self):
        cGame.getState().destroy();
#        for child in CGame.inst().getContainer().getNumChildren():
#            {
#                CGame.inst().getContainer().removeChildAt(0);
#            }
    
    def loadingTransition(self):
        self.loading = A.loading;
        self.display.blit(self.loading, (0,0));
        pygame.display.flip();
        self.loading = None;
        self.destroy();
       

    
        