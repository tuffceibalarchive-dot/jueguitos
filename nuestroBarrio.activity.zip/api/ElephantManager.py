'''
Created on Aug 5, 2013

@author: gustavogonzalezlamarque
'''
import pygame;
import math;
import Assets.Assets as A;
import Assets.AudioAssets as Audio;
from api.CSpriteStripAnim import SpriteStripAnim;
from api.CGame import cGame;
import random;

class Elephant(pygame.sprite.DirtySprite):
    def __init__(self, x, y, circusMap, manager, circus):
        pygame.sprite.DirtySprite.__init__(self);
        self.STAND = 0;
        self.WALKLEFT = 1;
        self.WALKRIGHT = 2;
        self.GOCASE = 3;
        self.INCASE = 4;
        self.velx = 16;
        self.vely = 16;
        self.map = circusMap;
        self.inPlatform = False;
        self.FPS = 30
        self.frames = self.FPS / 15
        self.n = 0;
        self.randomAnimals = random.randint(0,3);
        if(self.randomAnimals == 0):
            self.elephantWalkLeft = SpriteStripAnim(A.ELEPHANTS, (100, 0, 120, 100), 4, (0,0,0), True, self.frames);
            self.elephantWalkRight = SpriteStripAnim(A.ELEPHANTS, (600,0,120,100), 4, (0,0,0), True, self.frames);
            self.elephantStand = SpriteStripAnim(A.ELEPHANTS, (0,0, 100,100), 1, (0,0,0), True, self.frames);
        elif(self.randomAnimals ==1):
            self.elephantWalkLeft = SpriteStripAnim(A.TIGERS, (100, 0, 120, 100), 4, (0,0,0), True, self.frames);
            self.elephantWalkRight = SpriteStripAnim(A.TIGERS, (600,0,120,100), 4, (0,0,0), True, self.frames);
            self.elephantStand = SpriteStripAnim(A.TIGERS, (0,0, 100,100), 1, (0,0,0), True, self.frames);
        elif(self.randomAnimals == 2):
            self.elephantWalkLeft = SpriteStripAnim(A.ZEBRAS, (100, 0, 120, 100), 4, (0,0,0), True, self.frames);
            self.elephantWalkRight = SpriteStripAnim(A.ZEBRAS, (600,0,120,100), 4, (0,0,0), True, self.frames);
            self.elephantStand = SpriteStripAnim(A.ZEBRAS, (0,0, 100,100), 1, (0,0,0), True, self.frames);
        elif(self.randomAnimals == 3):
            self.elephantWalkLeft = SpriteStripAnim(A.LIONS, (100, 0, 120, 100), 4, (0,0,0), True, self.frames);
            self.elephantWalkRight = SpriteStripAnim(A.LIONS, (600,0,120,100), 4, (0,0,0), True, self.frames);
            self.elephantStand = SpriteStripAnim(A.LIONS, (0,0, 100,100), 1, (0,0,0), True, self.frames);
        self.walkLeft = [self.elephantWalkLeft];
        self.walkRight= [self.elephantWalkRight];
        self.standing = [self.elephantStand];
        self.setState(self.WALKRIGHT);
        self.rect = self.image.get_rect();
        self.setCoords(x, y);
        self.yPos = 0;
        self.isDead = False;
        self.manager = manager;
        self.circus = circus;
    def update(self):
        if(self.isDead):
            self.destroy();
        if(self.state == self.STAND):
            pass;
        elif(self.state == self.INCASE):
            pass;
        elif(self.state == self.WALKLEFT):
            self.rect.centerx -= self.velx;
            self.image = self.walkLeft[self.n].next();
        elif(self.state == self.WALKRIGHT):
            self.rect.centerx += self.velx;
            self.image = self.walkRight[self.n].next();
            if(self.checkPos() == (self.map.platform) and self.inPlatform != True):
                self.setState(self.STAND);
                self.setCoords(220, 400);
            elif(self.checkPos() == self.map.case):
                self.setState(self.GOCASE);
                
        elif(self.GOCASE):
            self.goToPlace();

            #al llegar setState = Standing
            pass;
    def pressed(self):
        self.mousePos = pygame.mouse.get_pos();
        if self.mousePos[0] > self.rect.topleft[0]:
            if self.mousePos[1] > self.rect.topleft[1]:
                if self.mousePos[0] < self.rect.topleft[0] + self.rect[2]:
                    if self.mousePos[1] < self.rect.topleft[1] + self.rect[3]:
                        return True
                    else: return False
                else: return False
            else: return False
        else: return False
        pass

    def checkPos(self):
        self.leftX = int(math.floor(self.rect.topleft[0]/self.map.TILE_WIDTH));
        self.leftY = int(math.floor(self.rect.topleft[1]/self.map.TILE_HEIGHT));
        self.leftPoint = (self.leftX, self.leftY);
        #self.center = int(self.map.getTileIndex(self.centerX, self.centerY));
        return self.leftPoint;
        
    def setState(self, state):
        self.state = state;
        if(self.state == self.STAND):    
            self.image = self.standing[self.n].first();
            self.inPlatform = True;
        elif(self.state == self.WALKLEFT):
            pass;
        elif(self.state == self.WALKRIGHT):
            self.image = self.walkRight[self.n].next();
        elif(self.state == self.GOCASE):
            self.LocateElephant();
            self.inPlatform = False;
        elif(self.state == self.INCASE):
            self.image = self.standing[self.n].first();        
    def LocateElephant(self):

        if(len(self.manager.elephantList) <= 6):
            self.yPos = (1 * self.map.TILE_HEIGHT);
        elif(len(self.manager.elephantList) > 6 and len(self.manager.elephantList) <= 11):
            self.yPos = (2 * self.map.TILE_HEIGHT);
        elif(len(self.manager.elephantList) > 11 and len(self.manager.elephantList) <= 16):
            self.yPos = (3 * self.map.TILE_HEIGHT);
        elif(len(self.manager.elephantList) > 16 and len(self.manager.elephantList) <= 21):
            self.yPos = (4 * self.map.TILE_HEIGHT);
        elif(len(self.manager.elephantList) > 21 and len(self.manager.elephantList) <= 26):
            self.yPos = (5 * self.map.TILE_HEIGHT);
        self.map.lastCasePosX = self.map.lastCasePosX + 100;
        return (self.map.lastCasePosX, self.yPos);
    
    def goToPlace(self):
        self.velx = 30;
        self.vely = 20;
        self.distanceX = (self.map.lastCasePosX - self.rect.centerx);
        self.distanceY = (self.yPos - self.rect.centery);
        self.angle = math.atan2(self.distanceY, self.distanceX);
        self.rect.centerx += (math.cos(self.angle)) * self.velx;
        self.rect.centery += (math.sin(self.angle)) * self.vely;
        if((self.rect.topright[0]/self.map.TILE_WIDTH, self.rect.topright[1]/self.map.TILE_HEIGHT) ==
                (self.map.lastCasePosX/self.map.TILE_WIDTH, self.yPos/self.map.TILE_HEIGHT) or
                (self.rect.centerx/self.map.TILE_WIDTH, self.rect.centery/self.map.TILE_HEIGHT) == 
                (self.map.lastCasePosX/self.map.TILE_WIDTH, self.yPos/self.map.TILE_HEIGHT) or
                (self.rect.bottomright[0]/self.map.TILE_WIDTH, self.rect.bottomright[1]/self.map.TILE_HEIGHT) == 
                (self.map.lastCasePosX/self.map.TILE_WIDTH, self.yPos/self.map.TILE_HEIGHT)):
                self.rect.topleft = (self.map.lastCasePosX, self.yPos);
                if(self.map.lastCasePosX >= 1000):
                    self.map.lastCasePosX = 5 * self.map.TILE_WIDTH;
                self.manager.elephantSent = False;
                self.setState(self.INCASE);
                self.circus.choiceNum += 1;
                
                #print(self.rect.topleft)
 
    def setCoords(self, x, y):
        self.rect.topleft = x, y;
    def destroy(self):
        self.elephantStand = None;
        self.elephantWalkLeft = None;
        self.elephantWalkRight = None;
        self.walkLeft = None;
        self.walkRight = None;
        self.image = None;
        self.selectAnimal = None;
        self.eraseAnimal = None;
        self.STAND = None;
        self.WALKLEFT = None;
        self.WALKRIGHT = None;
        self.GOCASE = None;
        self.INCASE = None;
        self.velx = None;
        self.vely = None;
        self.map = None;
        self.inPlatform = None;
        self.FPS = None;
        self.frames = None;
        self.n = None;
        self.randomAnimals = None;
        self.standing = None;
        self.rect = None;
        self.yPos = None;
        self.isDead = None;
        self.manager = None;
        self.circus = None;
        self.theCircus = None;
#===============================================================================
# BEGIN OF MANAGER
#===============================================================================
class elephantManager(object):

    def __init__(self, container, circusMap, circus):
        '''
        Constructor
        '''
        self.fxOn = cGame.inst().cProgressSave.fxOn;
        self.container = container;
        self.circus = circus;
        self.map = circusMap;
        self.elephantList = [];
        self.elephantSent = False;
        #Load FXs
        self.selectAnimal = pygame.mixer.Sound(Audio.SELECTANIMAL);
        self.eraseAnimal = pygame.mixer.Sound(Audio.ERASEANIMAL);
    def destroy(self):
        for elephant in self.elephantList:
            elephant.destroy();
            self.elephantList.remove(elephant);
            if(elephant.isDead != True):
                elephant.destroy();
        self.elephantList = None;
        self.fxOn = None;
        self.container = None;
        self.map = None;
        self.elephantSent = None;
        self.eraseAnimal = None;
        self.selectAnimal = None;
    def update(self):
        for elephant in self.elephantList:
            if(elephant.isDead):
                self.container.remove(elephant);
                elephant.destroy();
            
    def AddElephant(self):
        self.newElephant = Elephant(-200, 400, self.map, self, self.circus);
        self.elephantList.append(self.newElephant);
        self.container.add(self.newElephant);
        self.elephantSent = True;
        if(self.fxOn):
            self.selectAnimal.play();
        
    def CheckPressed(self):
        if(self.elephantSent != True):
            for elephant in self.elephantList:    
                if(elephant.pressed() and elephant.inPlatform):
                    elephant.setState(elephant.WALKRIGHT);
                    self.AddElephant();
                    
    def RemoveElephant(self):
        if(len(self.elephantList) > 1):
            self.elephantToRemove = self.elephantList.pop(-2);
            self.map.lastCasePosX = self.elephantToRemove.rect.topleft[0] - self.map.TILE_WIDTH;
            self.container.remove(self.elephantToRemove);
            self.elephantToRemove.isDead = True;
            if(self.fxOn):
                self.eraseAnimal.play();

    def ClearElephants(self):
        self.n = len(self.elephantList);
        while self.n > 0:
            self.elephantToRemove = self.elephantList.pop(-1);
            self.container.remove(self.elephantToRemove);
            self.elephantToRemove.isDead = True;
            self.n -=1;
            
#         for elephant in self.elephantList:
#             print(elephant)
#             self.elephantList.remove(elephant);
#             if(elephant.isDead != True):
#                 elephant.destroy();
        self.map.lastCasePosX = 5 * self.map.TILE_WIDTH;
            
                    