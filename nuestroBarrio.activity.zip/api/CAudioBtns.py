'''
Created on Oct 1, 2013

@author: gustavogonzalezlamarque
'''
import Assets.Assets as A;
from api.CSpriteStripAnim import SpriteStripAnim;
from api.CGame import cGame;
import pygame;

class Parlante(pygame.sprite.DirtySprite):
    def __init__(self):
        pygame.sprite.DirtySprite.__init__(self);
        self.image = pygame.Surface.convert_alpha(pygame.image.load(A.PARLANTE));
        self.rect = self.image.get_rect();
    def destroy(self):
        self.image  = None;
        self.rect = None;
        
class BtnFx(pygame.sprite.DirtySprite):
    def __init__(self):
        pygame.sprite.DirtySprite.__init__(self);
        self.fxSheet = SpriteStripAnim(A.FXBTN, (0,0,80,115), 2,(0,0,0));
        if(cGame.inst().cProgressSave.fxOn):
            self.image = self.fxSheet.getImageByIndex(1);
        else:
            self.image = self.fxSheet.getImageByIndex(0);
        self.rect = self.image.get_rect();
        self.SetCoords(100,10);
    def update(self):
        self.pressed();
    def pressed(self):
        self.mousePos = pygame.mouse.get_pos();
        if self.mousePos[0] > self.rect.topleft[0]:
            if self.mousePos[1] > self.rect.topleft[1]:
                if self.mousePos[0] < self.rect.topleft[0] + self.rect[2]:
                    if self.mousePos[1] < self.rect.topleft[1] + self.rect[3]:
                        return True
                    else: return False
                else: return False
            else: return False
        else: return False
        pass
    def mouseOver(self):
        self.onMe = False;
        if(self.pressed()):
            self.onMe = True;
        else:
            self.onMe = False;
        return self.onMe;
    def changeSetup(self):
        if(cGame.inst().cProgressSave.fxOn == False):
            self.image = self.fxSheet.getImageByIndex(1);
            cGame.inst().cProgressSave.fxOn = True;
        else:
            self.image = self.fxSheet.getImageByIndex(0);
            cGame.inst().cProgressSave.fxOn = False;
        cGame.inst().cProgressSave.SaveValues();
    def SetCoords(self, x,y):
        self.rect.topleft = (x,y);
    def destroy(self):
        self.fxSheet = None;
        self.image = None;
        self.rect = None;
        
class BtnMusic(pygame.sprite.DirtySprite):
    def __init__(self):
        pygame.sprite.DirtySprite.__init__(self);
        self.musicSheet = SpriteStripAnim(A.MUSICABTN, (0,0,80,115), 2,(0,0,0));
        if(cGame.inst().cProgressSave.audioOn):
            self.image = self.musicSheet.getImageByIndex(1);
        else:
            self.image = self.musicSheet.getImageByIndex(0);
        self.rect = self.image.get_rect();
        self.SetCoords(190,10);
    def update(self):
        self.pressed();
    def pressed(self):
        self.mousePos = pygame.mouse.get_pos();
        if self.mousePos[0] > self.rect.topleft[0]:
            if self.mousePos[1] > self.rect.topleft[1]:
                if self.mousePos[0] < self.rect.topleft[0] + self.rect[2]:
                    if self.mousePos[1] < self.rect.topleft[1] + self.rect[3]:
                        return True
                    else: return False
                else: return False
            else: return False
        else: return False
        pass
    def mouseOver(self):
        self.onMe = False;
        if(self.pressed()):
            self.onMe = True;
        else:
            self.onMe = False;
        return self.onMe;
    def changeSetup(self):
        if(cGame.inst().cProgressSave.audioOn == False):
            cGame.inst().cProgressSave.audioOn = True;
            self.image = self.musicSheet.getImageByIndex(1);
            cGame.inst().cProgressSave.SaveValues();
            pygame.mixer.music.unpause();
        else:
            cGame.inst().cProgressSave.audioOn = False;
            self.image = self.musicSheet.getImageByIndex(0);
            cGame.inst().cProgressSave.SaveValues();
            pygame.mixer.music.pause();
    def SetCoords(self, x,y):
        self.rect.topleft = (x,y);
    def destroy(self):
        self.musicSheet = None;
        self.image = None;
        self.rect = None;

class cAudioBtns(object):
    '''
    classdocs
    '''
    def __init__(self, container):
        '''
        Constructor
        '''
        self.container = container;
        self.btnFx = BtnFx();
        self.btnMusic = BtnMusic();
        self.parlante = Parlante();
        self.container.add(self.btnFx, self.btnMusic, self.parlante);
        
    def destroy(self):
        self.container.remove(self.btnFx, self.btnMusic, self.parlante);
        self.btnFx.destroy();
        self.btnMusic.destroy();
        self.parlante.destroy();
        self.container = None;
        self.btnFx = None;
        self.btnMusic = None;
        self.parlante = None;