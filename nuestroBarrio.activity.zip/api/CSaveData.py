# -*- coding: utf-8 -*-

#--------------------------------------------------------------------------------
# Clase GameData.
# Clase para manejar los datos del juego.
#
# Autor: Mauricio Eguia - Batovi Games Studio - 2013
# Proyecto: Hacete tu Videojuego.
#           Plan CEIBAL, Uruguay
# Licencia: Creative Commons
#--------------------------------------------------------------------------------

import os
import json
import platform

BASE = os.path.dirname(__file__);
APPDATA = os.path.join(BASE, "");

class CSaveData(object):
    mInstance = None
    mInitialized = False
    # Antes esto se activaba en cualquier sistema que no fuera Mac (incluyendo
    # Windows/Linux corridos fuera de Sugar), lo que rompia el juego al buscar
    # la variable de entorno SUGAR_ACTIVITY_ROOT que solo existe dentro de Sugar.
    # Ahora se detecta la XO por la presencia real de esa variable de entorno.
    IS_XO = os.getenv("SUGAR_ACTIVITY_ROOT") is not None
    def __new__(self, *args, **kargs):
        if (CSaveData.mInstance is None):
            CSaveData.mInstance = object.__new__(self, *args, **kargs)
            self.init(CSaveData.mInstance)
        else:
            print "Cuidado: CSaveData(): No se deber�a instanciar m�s de una vez esta clase. Usar CSaveData.inst()."
        return self.mInstance

    @classmethod
    def inst(cls):
        if (not cls.mInstance):
            return cls()
        return cls.mInstance
    
    def init(self):
        if (CSaveData.mInitialized):
            return

        FILENAME_PREFIX = ""    # this is an instance attribute, that's why is defined here
        
        if (CSaveData.IS_XO):
            self.FILENAME_PREFIX = os.path.join(os.getenv("SUGAR_ACTIVITY_ROOT"),'data')
        else:
            # Carpeta de datos portable: funciona en Windows, Mac y Linux
            # corriendo fuera de Sugar, sin depender de variables de entorno
            # que puedan no existir (antes usaba literalmente el string "APPDATA").
            appdata = os.getenv("APPDATA") or os.getenv("XDG_DATA_HOME") or os.path.expanduser("~")
            self.FILENAME_PREFIX = os.path.join(appdata, "NuestroBarrio")
            if not os.path.exists(self.FILENAME_PREFIX):
                os.makedirs(self.FILENAME_PREFIX)
    # This method is used only inside this class
    def getFullPath(self,aGameName,aFilename):
        if( self.IS_XO ):
            return os.path.join(self.FILENAME_PREFIX, aFilename)
        else:
            return os.path.join(self.FILENAME_PREFIX, aGameName,aFilename)
        
    # checks if the save file exists
    def checkFileExists(self,aFilename):
        if (not aFilename):
            return False

        # check if fullFilename exists, if not exists return False
        if (not os.path.exists(aFilename)):
            return False
        
        # check if the fullFilename is a file, if is not a file then return False
        if (not os.path.isfile(aFilename)):
            return False
        
        return True
    
    # Return a boolean if the key is in the file
    # The game name is only used if we are not in XO
    def has_key(self, aKey, aGameName , aFilename):
        fullFilename = self.getFullPath(aGameName, aFilename)
        if not self.checkFileExists(fullFilename):
            return False

        file = open(fullFilename,"r")
        fileContent = file.read()
        file.close()
        data = json.loads(fileContent)

        return data.has_key(aKey)

    # Return an object if the key is in the file, return None otherwise
    # If aGameName or aFilename is "" this functions uses the global filename
    def getData(self, aKey, aGameName, aFilename):
        fullFilename = self.getFullPath(aGameName, aFilename)
        if not self.checkFileExists(fullFilename):
            return None

        file = open(fullFilename,"r")
        fileContent = file.read()
        file.close()
        data = json.loads(fileContent)

        if ( data.has_key(aKey) ):
            return data[aKey]
        else:
            return None

    # Save an object to a file, return True if there were no errors
    # If aNewFile is True, creates a new file is created (if a file already exists is overwritten)
    def saveData(self, aKey, aData, aGameName , aFilename,  aNewFile=False ):
        fullFilename = self.getFullPath(aGameName, aFilename)
        fullDirName = self.getFullPath(aGameName, "")

        # if the directory do not exists, create it!
        if ( not os.path.exists(fullDirName) ):
            os.makedirs(fullDirName)

        if ( aNewFile or not self.checkFileExists(fullFilename) ):
            file = open(fullFilename,"w")
            data = {}
        else:
            file = open(fullFilename,"r+")
            data = json.load(file)
            file.seek(0) # this put the reading position at the begining of the file
            file.truncate(0) # this makes the file empty and ready to be written
        
        data[aKey] = aData
        
        json.dump(data, file, indent=4)
        file.close()

    # Return True if the data was deleted from the file
    def delData(self, aKey, aGameName, aFilename ):
        fullFilename = self.getFullPath(aGameName, aFilename)
        if ( not os.path.exists(fullFilename) ):
            return False

        file = open(fullFilename,"r+")
        data = json.load(file)
        file.seek(0) # this put the reading position at the begining of the file
        file.truncate(0) # this makes the file empty and ready to be written

        if (not data.has_key(aKey)):
            return False
        del data[aKey]
        
        json.dump(data, file, indent=4)
        file.close()
        return True
