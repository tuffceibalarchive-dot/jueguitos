'''
Created on 05/01/2013

@author: Gus
'''
import pygame;

class cGameObject(pygame.sprite.Sprite):
    '''
    classdocs
    '''
    def __init__(self):
        '''
        Constructor
        '''
        pygame.sprite.Sprite.__init__(self);
        self.mX = 0;
        self.mY = 0;
        self.mVelX = 0;
        self.mVelY = 0;
        self.mAccelX = 0;
        self.mAccelY = 0;
        self.mTimeState = 0;

    def update(self):
        self.mVelX = self.mVelX + self.mAccelX;
        self.mVelY = self.mVelY + self.mAccelY;
        self.mX = self.mX + self.mVelX;
        self.mY = self.mY + self.mVelY;
    
    def render(self):
        self.x = self.mX;
        self.y = self.mY;
        
    def setX(self, aX):
        self.mX = aX;
        
    def setY(self, aY):
        self.mY = aY;
        
    def setXY(self, aX, aY):
        self.mX = aX;
        self.mY = aY;
        
    def getX(self):
        return self.mX;
    
    def getY(self):
        return self.mY;
        
    def setVelX(self, aVelX):
        self.mVelX = aVelX;

    def setVelY(self, aVelY):
        self.mVelY = aVelY;
        
    def setVelXY(self, aVelX, aVelY):
        self.mVelX = aVelX;
        self.mVelY = aVelY;
    
    def getVelX(self):
        return self.mVelX;
    
    def getVelY(self):
        return self.mVelY;
    
    def setAccelX(self, aAccelX):
        self.mAccelX = aAccelX;
        
    def setAccelY(self, aAccelY):
        self.mAccelY = aAccelY;
        
    def setAccelXY(self, aAccelX, aAccelY):
        self.mAccelX = aAccelX;
        self.mAccelY = aAccelY;
        
    def getAccelX(self):
        return self.mAccelX;
    
    def getAccelY(self):
        return self.mAccelY;
    
    def setTimeState(self, aTimeState):
        self.mTimeState = aTimeState;
        
    def getTimeState(self):
        return self.mTimeState;    
    
    