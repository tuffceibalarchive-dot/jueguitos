'''
Created on 28/12/2012

@author: Gus
'''
import pygame;

pygame.mixer.init();

import Assets.Assets as A;
from api.CProgressSave import cProgressSave;
from api.CKeyPoll import cKeyPoll;
#===============================================================================
# BEGIN OF SINGLETON
#===============================================================================
class cGame:
    # Create a class variable that will hold a reference
    # to the single instance of TestSingleton.

    instance = None

    # Define a helper class that will override the __call___
    # method in order to provide a factory method for TestSingleton.

    class TestSingletonHelper:

        def __call__( self, *args, **kw ) :

            # If an instance of TestSingleton does not exist,
            # create one and assign it to TestSingleton.instance.

            if cGame.instance is None :
                toBeInst = cGame()
                cGame.instance = toBeInst

            # Return TestSingleton.instance, which should contain
            # a reference to the only instance of TestSingleton
            # in the system.

            return cGame.instance
    # Create a class level method that must be called to
    # get the single instance of TestSingleton.

    inst = TestSingletonHelper()
    
    # Initialize an instance of the TestSingleton class.

    def __init__(self):
        # Optionally, you could go a bit further to guarantee
        # that no one created more than one instance of TestSingleton:

        if not cGame.instance == None :
            raise RuntimeError
        
        #Window Name
        pygame.display.set_caption("Mi Barrio");
        # Prepare background (black)
        self.display = A.display;
#        self.background=pygame.Surface(self.display.get_size())
#        self.background = self.background.convert()
#        self.background.fill((0, 0, 0))
#        self.display.blit(self.background, (0, 0))
        
        self.allSprites = pygame.sprite.OrderedUpdates();
        self.actualState = None;
        self.keepGoing = True;
        self.cProgressSave = cProgressSave();
        #create sound
        #wooHoo = pygame.mixer.Sound("wooHoo.ogg");
        #sprites handle
        #self.clear_sprites()
        self.gardenSprites = pygame.sprite.OrderedUpdates();
        self.keyboard = cKeyPoll();

    
    #===========================================================================
    # END OF SINGLETON
    #===========================================================================
    
    
    def getDisplay(self):
        return self.display;
       
    def stop(self):
            """ stop the loop """
            self.keepGoing=False;
            self.abort=True;
            pygame.display.get_surface().set_clip(None);
       
    def getNumChildren(self):
        return self.allSprites.sprites()

    def render(self):
        """ render game state """
        if(self.getState() != None):
            self.getState().render();    
        pass
        
    def update(self):
        """ updates game state """
        if(self.getState() != None):
            #self.keyboard.update();
            self.getState().update();


   
    def eventUpdate(self):
        self.getState().eventUpdate();
    
    def getContainer(self):
        """ get the list of all registred sprites """
        return self.allSprites;
    
    def addToContainer(self, toAdd):
        """ Add object to sprite group"""
        #cGame.allSprites.add(toAdd);
       
    def set_background(self, bckimg, coordinates=(0, 0)):
        """ define the screen background """
        if bckimg==None:
            self.background.fill((0, 0, 0))
        else:
            self.background.blit(bckimg, (coordinates[0]+self._offsetx, coordinates[1]+self._offsety))
        self.refreshBackground=True
        self.addToContainer(bckimg);
        
    def getObject(self, typeName):
        """ get a list of objects a certain type (ie. all buttons) """
        l=[]
        for o in self.allSprites:
            try:
                if o.type==typeName:
                    l.append(o)
            except:
                pass
        return l
    
    def get_clock(self):
        """ get the game clock : updated only on each frame refresh (see update) """
        return self.gameClock

    def spam(self):
        """ Test method, return singleton id """
        return id(self)

    
    def setState(self, aState):
        
        self.actualState = aState;
#            if (mState != None):
#                mState.destroy();
#                mState = None;
#                #CHelper.removeAllChildrenDisplayObject(mContainer);
#                                            
#                #CKeyPoll.regainFocus();
##            print(type(mState))
#            mState.__init__();

    def getState(self):
        return self.actualState;

    def getStage(self):
        return pygame.display;
        

    def UnlockPic(self, name):
        self.cProgressSave.pics[name] = True;
        
    def LockPic(self, name):
        self.cProgressSave.pics[name] = False;





    
               
    
    