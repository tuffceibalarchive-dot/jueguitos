'''
Created on 22/04/2013

@author: Gus
'''
import pygame;
import Assets.Assets as A;
from Assets.button import Button;
from api.CAudioBtns import cAudioBtns;
from api.CGame import cGame;
from api.CSpriteStripAnim import SpriteStripAnim;

class DistractorOnOff(pygame.sprite.DirtySprite):
    def __init__(self):
        pygame.sprite.DirtySprite.__init__(self);
        self.DistractorSheet = SpriteStripAnim(A.DISTRACTORONOFF, (0,0,330,140), 2,(0,0,0));
        if(cGame.inst().cProgressSave.config["distractorOn"]):
            self.image = self.DistractorSheet.getImageByIndex(1);
        else:
            self.image = self.DistractorSheet.getImageByIndex(0);
        self.rect = self.image.get_rect();
        self.SetCoords(0,0);
    def update(self):
        self.pressed();
    def destroy(self):
        self.DistractorSheet = None;
        self.image = None;
        self.rect = None;
    def pressed(self):
        self.mousePos = pygame.mouse.get_pos();
        if self.mousePos[0] > self.rect.topleft[0]:
            if self.mousePos[1] > self.rect.topleft[1]:
                if self.mousePos[0] < self.rect.topleft[0] + self.rect[2]:
                    if self.mousePos[1] < self.rect.topleft[1] + self.rect[3]:
                        return True
                    else: return False
                else: return False
            else: return False
        else: return False
        pass
    
    def SetCoords(self, x,y):
        self.rect.topleft = (x,y);
        
    def changeSetup(self):
        if(cGame.inst().cProgressSave.config["distractorOn"] == False):
            self.image = self.DistractorSheet.getImageByIndex(1);
            cGame.inst().cProgressSave.config["distractorOn"] = True;
        else:
            self.image = self.DistractorSheet.getImageByIndex(0);
            cGame.inst().cProgressSave.config["distractorOn"] = False;
        cGame.inst().cProgressSave.SaveValues();
class cPause(pygame.sprite.DirtySprite):
    '''
    classdocs
    '''


    def __init__(self, aLevel, mouse):
        '''
        Constructor
        '''
        pygame.sprite.DirtySprite.__init__(self);
        self.spriteList = pygame.sprite.OrderedUpdates();
        self.mLevel = aLevel;
        self.mouse = mouse;
        self.audioBtns = None;
        self.btnDistractorOnOff = None;
        if(self.mLevel.name == "town"):
            self.image =  A.transparency;
            self.btnGotoAlbum = Button(A.GOTOALBUM, 683, 345);
            self.btnGotoMenu = Button(A.GOTOMENU, 217, 300);
            self.btnDistractorOnOff = DistractorOnOff();
            self.spriteList.add(self, self.btnGotoAlbum, self.btnGotoMenu, self.btnDistractorOnOff, self.mouse);
            
        elif(self.mLevel.name != "town"):
            self.image = A.pauseInGameBck;
            self.btnContinue = Button(A.BTNRIGHT, 725, 500);
            self.btnQuit = Button(A.BTNLEFT, 265, 500);
            self.spriteList.add(self, self.btnContinue, self.btnQuit);
            self.audioBtns = cAudioBtns(self.spriteList);
            self.spriteList.add(self.mouse);
        self.rect = self.image.get_rect();
    def update(self):
        pass;
        
    def setCords(self, coords):
        """coords is a tuple with the format (x, y)"""
        self.rect.topleft = coords;
    
    def destroy(self):
        if(self.mLevel.name == "town"):
            self.spriteList.remove(self.btnGotoAlbum, self.btnGotoMenu, self.btnDistractorOnOff, self.mouse);
            self.btnGotoAlbum.destroy();
            self.btnGotoMenu.destroy();
            self.btnDistractorOnOff.destroy();
            self.btnDistractorOnOff=None;
            self.btnGotoAlbum = None;
            self.btnGotoMenu = None;
        else:
            self.spriteList.remove(self.btnContinue, self.btnQuit, self.mouse);
            self.btnContinue.destroy();
            self.btnQuit.destroy();
            self.audioBtns.destroy();
            self.audioBtns = None;
            self.btnContinue = None;
            self.btnQuit = None;
        self.mouse = None;
        self.mLevel = None;
        self.spriteList = None;
        self.image = None;
        self.rect = None;
        