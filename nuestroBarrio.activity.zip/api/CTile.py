'''
Created on 11/03/2013

@author: Gus
'''
import pygame;
from api.CGame import cGame;
from api.CSpriteSheet import spritesheet;
import Assets.Assets as A; 
import random;

class tilePath(pygame.sprite.Sprite):
    def __init__(self, difficulty):
        self.difficulty = difficulty;
        pygame.sprite.Sprite.__init__(self);
        if(self.difficulty == 1):
            self.tileSheet = spritesheet(A.GARDENTILES_100);
            self.tileList = self.tileSheet.load_strip((0, 0, 100, 100), 5, colorkey = (0,0,0));
            self.image = pygame.Surface.convert_alpha((self.tileList[random.randint(3, 4)]));
        elif(self.difficulty == 2):
            self.tileSheet = spritesheet(A.GARDENTILES_75);
            self.image = pygame.Surface((75, 75));
            self.tileList = self.tileSheet.load_strip((0, 0, 75, 75), 5, colorkey = (0,0,0));
            self.image = pygame.Surface.convert_alpha((self.tileList[random.randint(3, 4)]));
        elif(self.difficulty == 3):
            self.tileSheet = spritesheet(A.GARDENTILES_60);
            self.tileList = self.tileSheet.load_strip((0, 0, 60, 60), 5, colorkey = (0,0,0));
            self.image = pygame.Surface.convert_alpha((self.tileList[random.randint(3, 4)]));
            
        self.image = self.image.convert();
#        self.image.fill((0, 0, 0));
        self.rect = self.image.get_rect();
    def destroy(self):
        self.tileSheet = None;
        self.tileList = None;
        self.image = None;
        self.rect = None;
class tileWall(pygame.sprite.Sprite):
    def __init__(self, difficulty):
        self.difficulty = difficulty;
        pygame.sprite.Sprite.__init__(self);
        
        if(self.difficulty == 1):
            self.tileSheet = spritesheet(A.GARDENTILES_100);
            self.tileList = self.tileSheet.load_strip((0, 0, 100, 100), 3, colorkey = (0,0,0));
            self.image = pygame.Surface.convert_alpha((self.tileList[random.randint(0, 2)]));
        elif(self.difficulty == 2):
            self.tileSheet = spritesheet(A.GARDENTILES_75);
            self.image = pygame.Surface((75, 75));
            self.tileList = self.tileSheet.load_strip((0, 0, 75, 75), 3, colorkey = (0,0,0));
            self.image = pygame.Surface.convert_alpha((self.tileList[random.randint(0, 2)]));
        elif(self.difficulty == 3):
            self.tileSheet = spritesheet(A.GARDENTILES_60);
            self.tileList = self.tileSheet.load_strip((0, 0, 60, 60), 3, colorkey = (0,0,0));
            self.image = pygame.Surface.convert_alpha((self.tileList[random.randint(0, 2)]));
        self.image = self.image.convert();
#        self.image.fill((255, 255, 255));
        self.rect = self.image.get_rect();
    def destroy(self):
        self.tileSheet = None;
        self.tileList = None;
        self.image = None;
        self.rect = None;
class tileNothing(pygame.sprite.Sprite):
    def __init__(self, difficulty):
        self.difficulty = difficulty;
        pygame.sprite.Sprite.__init__(self);

        if(self.difficulty == 1):
            self.image = pygame.Surface((100, 100));
        elif(self.difficulty == 2):
            self.image = pygame.Surface((75, 75));
        elif(self.difficulty == 3):
            self.image = pygame.Surface((60, 60));
        self.image = self.image.convert();
        self.image.fill((255, 255, 255));
        self.rect = self.image.get_rect();
    def destroy(self):
        self.image = None;
        self.rect = None;
    
        

class cTile(object):
    '''
    classdocs
    '''
        
    def __init__(self, aX, aY, aTileIndex, aMapName, aCreated):
        '''
        Constructor
        '''
        self.mX = aX;
        self.mY = aY;
        self.mTileIndex = aTileIndex;
        self.mMapName = aMapName;
        self.mCreated = aCreated;  
        
        
        if(self.mMapName == "garden" and self.mCreated):
            if(self.mTileIndex == 0):
                self.tile = tileWall(cGame.inst().cProgressSave.difficultySelected);
                self.tile.rect.topleft = (aX, aY);
            elif(self.mTileIndex == 2):
                self.tile = tilePath(cGame.inst().cProgressSave.difficultySelected);
                self.tile.rect.topleft = (aX, aY);
            elif(self.mTileIndex == 1):
                self.tile = tileNothing(cGame.inst().cProgressSave.difficultySelected);
                self.tile.rect.topleft = (aX, aY);
                     
            cGame.inst().gardenSprites.add(self.tile);
#                cGarden.background.add(self.tile);
         
    def getTileIndex(self):
        return self.mTileIndex;
    
    def setTileIndex(self, aTileIndex):
        self.mTileIndex = aTileIndex;
        
    def destroy(self):
        if(self.mTileIndex == 0 or self.mTileIndex == 2):
            self.tileSheet = None;
            self.tileList = None;
        self.image = None;