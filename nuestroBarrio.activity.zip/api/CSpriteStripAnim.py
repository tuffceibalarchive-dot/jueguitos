'''
Created on 05/03/2013

@author: Gus
'''
import pygame.sprite;
from api.CSpriteSheet import spritesheet;
 
class SpriteStripAnim(pygame.sprite.Sprite):
    """sprite strip animator
    
    This class provides an iterator (iter() and next() methods), and a
    __add__() method for joining strips which comes in handy when a
    strip wraps to the next row.
    """
    def __init__(self, filename, rect, count, colorkey=None, loop=False, frames=1):
        """construct a SpriteStripAnim
        
        filename, rect, count, and colorkey are the same arguments used
        by spritesheet.load_strip.
        
        loop is a boolean that, when True, causes the next() method to
        loop. If False, the terminal case raises StopIteration.
        
        frames is the number of ticks to return the same image before
        the iterator advances to the next image.
        """
        pygame.sprite.Sprite.__init__(self);
        self.filename = filename
        ss = spritesheet(filename)
        self.images = ss.load_strip(rect, count, colorkey)
        self.i = 0
        self.loop = loop
        self.frames = frames
        self.f = frames
        self.oneLoop = False;
    def iter(self):
        self.i = 0
        self.f = self.frames
        return self
    def next(self):
        if self.i >= len(self.images):
            if not self.loop:
                raise StopIteration
            else:
                self.i = 0
                self.oneLoop = True;
        image = self.images[self.i]
        self.f -= 1
        if self.f == 0:
            self.i += 1
            self.f = self.frames
        return image
    
    def first(self):
        self.i = 0;
        image = self.images[self.i];
        return image;
    def last(self):
        self.i = -1;
        image = self.images[self.i];
        return image;
    def getImageByIndex(self, i):
        self.i = i;
        image = self.images[self.i];
        return image;
    
    def __add__(self, ss):
        self.images.extend(ss.images)
        return self