'''
Created on 10/03/2013

@author: user
'''

from api.CTile import cTile;
from api.CGame import cGame;
import random;

class cMap(object):
    '''
    classdocs
    '''

    
    #Tile 1 walkable
    #Tile 0 not walkable
    
    
    def __init__(self, mapa):
        '''
        Constructor
        '''
        self.OUT_OF_RANGE = 99999;
        self.mapName = mapa
        
        self.TILE_WALL = 0;
        self.TILE_EMPTY = 1;
        #-----------------------------Mapa del Barrio---------------------------------#
        
        if (self.mapName == "town"):
            self.mMap1 = [
                      [ 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0],
                      [ 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0],
                      [ 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0],
                      [ 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0],
                      [ 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0],
                      [ 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0],
                      [ 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0],
                      [ 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0],
                      [ 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 0, 0, 0, 0, 1, 0, 0, 1, 0],
                      [ 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0, 0, 0, 1, 0, 0, 1, 0],
                      [ 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 1, 1, 1, 1, 1, 1, 0, 0, 1, 0],
                      [ 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0],
                      [ 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0],
                      [ 1, 1, 1, 1, 1, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0],
                      [ 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0],
                      ];
            self.TILE_WIDTH = 60;
            self.TILE_HEIGHT = 60;
            self.museumDoor = (3, 13);
            self.museumDoor2 = (3, 12);
            self.circDoor = (4, 5);
            self.farmDoor = (16, 7);
            self.farmDoor2 = (16, 6);
            self.gardenDoor = (14, 9);
            self.gardenDoor2 = (14, 10);
    #-----------------------------Mapa del Barrio---------------------------------#
        
        #----------------------------gardens--------------------------------------#
        
        elif (self.mapName == "garden"):
            if(cGame.inst().cProgressSave.difficultySelected == 1):
                self.TILE_WIDTH = 100;
                self.TILE_HEIGHT = 100;
                                             
                self.mMap1 = [
                              [0,0,0,0,0,0,0,0,0,0,0,0],
                              [0,1,1,1,1,1,1,1,1,1,1,0],
                              [0,1,1,1,1,1,1,1,1,1,1,0],
                              [0,1,1,1,1,1,1,1,1,1,1,0],
                              [0,1,1,1,1,1,1,1,1,1,1,0],
                              [0,1,1,1,1,1,1,1,1,1,1,0],
                              [0,1,1,1,1,1,1,1,1,1,1,0],
                              [0,1,1,1,1,1,1,1,1,1,1,0],
                              [0,0,0,0,0,0,0,0,0,0,0,0]
                              ];
                
                
            elif(cGame.inst().cProgressSave.difficultySelected == 2):
                self.TILE_WIDTH = 75;
                self.TILE_HEIGHT = 75;
                
                self.mMap1 = [
                              [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
                              [0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0],
                              [0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0],
                              [0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0],
                              [0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0],
                              [0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0],
                              [0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0],
                              [0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0],
                              [0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0],
                              [0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0],
                              [0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0],
                              [0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0],
                              [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
                              ];
            elif(cGame.inst().cProgressSave.difficultySelected == 3):
                self.TILE_WIDTH = 60;
                self.TILE_HEIGHT = 60;
                
                self.mMap1 = [
                      [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                      [ 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
                      [ 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
                      [ 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
                      [ 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
                      [ 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
                      [ 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
                      [ 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
                      [ 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
                      [ 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
                      [ 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
                      [ 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
                      [ 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
                      [ 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
                      [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                      ];
            
        elif(self.mapName == "interval"):
            self.TILE_WIDTH = 100;
            self.TILE_HEIGHT = 100;
            
            self.mMap1 = [
                          [0,0,0,0,0,0,0,0,0,0,0,0],
                          [0,0,0,0,0,0,0,0,0,0,0,0],
                          [0,0,0,0,0,0,0,0,0,0,0,0],
                          [0,0,0,0,0,0,0,0,0,0,0,0],
                          [0,0,0,0,0,0,0,0,0,0,0,0],
                          [0,0,0,0,0,0,0,0,0,0,0,0],
                          [1,1,1,1,1,1,1,1,1,1,1,1],
                          [0,0,0,0,0,0,0,0,0,0,0,0],
                          [0,0,0,0,0,0,0,0,0,0,0,0]
                          ];
            self.leftExit = (0, 6);
            self.rightExit = (11, 6);
            self.neighbourPlace = (9, 6);
            self.distractorEnded = False;
            
        elif( self.mapName == "farm"):
            self.TILE_WIDTH = 60;
            self.TILE_HEIGHT = 60;
            self.mMap1 =[
                      [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                      [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                      [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                      [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                      [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                      [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                      [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                      [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                      [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                      [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                      [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                      [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                      [ 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
                      [ 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
                      [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                      ];
            self.farmBegin = (10, 12);
            self.tomatos = (2, 12);
            self.carrotLeft = (4, 12);
            self.carrotRight = (5, 12);
            self.cow = (9, 12);
            self.oranges = (12, 12);
            self.orangesRight = (13,12);
            self.chicken = (15, 12);
            self.basket = (18, 12);
            
        elif(self.mapName == "circus"):
            self.TILE_WIDTH = 100;
            self.TILE_HEIGHT = 100;
                                             
            self.mMap1 = [
                          [0,0,0,0,0,0,0,0,0,0,0,0],
                          [0,1,1,1,1,1,1,1,1,1,1,0],
                          [0,1,1,1,1,1,1,1,1,1,1,0],
                          [0,1,1,1,1,1,1,1,1,1,1,0],
                          [0,1,1,1,1,1,1,1,1,1,1,0],
                          [0,1,1,1,1,1,1,1,1,1,1,0],
                          [0,1,1,1,1,1,1,1,1,1,1,0],
                          [0,1,1,1,1,1,1,1,1,1,1,0],
                          [0,0,0,0,0,0,0,0,0,0,0,0]
                          ];
            self.platform = (2, 4);
            self.case = (4, 4);
            self.lastCasePosX = 5 * self.TILE_WIDTH;
        self.mWidth =  len(self.mMap1[0]);
        self.mHeight = len(self.mMap1);          
        self.tiles = [];
        self.created = False;
        i = 0;
         
        while i < self.mHeight:
            j = 0;
            col = [];
            while j < self.mWidth:
                col.append( cTile(j * self.TILE_WIDTH, i * self.TILE_HEIGHT, self.mMap1[i][j], self.mapName, self.created ));
                j += 1;
            i += 1;
            self.tiles.append(col);
            
        if(self.mapName == "garden"):     
            # for selecting random direction in mazeGenerator        
        #               N   E   S   O
            self.xOffset = [ 0, 1, 0, -1 ];
            self.yOffset = [ -1, 0, 1, 0 ];
            #------- maze start ----------#        
            self.setTile(0, 6, 2);
            self.setTile(1, 6, 2);
            #------- maze exit -----------#
            self.setTile(self.getTileListIndex(self.tiles[-7][-1])[0], self.getTileListIndex(self.tiles[-7][-1])[1], 2);
            self.setTile(self.getTileListIndex(self.tiles[-7][-2])[0], self.getTileListIndex(self.tiles[-7][-2])[1], 2);
            self.gardenExit = (self.getTileListIndex(self.tiles[-7][-1])[0],self.getTileListIndex(self.tiles[-7][-1])[1] );
            
            #------- generate maze -------#
            self.generateMaze(1, 6);
            
            for i in range(self.mWidth): 
                for j in range(self.mHeight):     
                    if (self.getTileIndex(i, j) == 1):
                        self.setTile(i, j, 0);
            
                                         
            self.mWidthGarden =  len(self.tiles[0]);
            self.mHeightGarden = len(self.tiles);          
            self.tilesGarden = [];
            
            self.created = True;
            i = 0;
                    
            while i < self.mHeightGarden:
                j = 0;
                col = [];
                while j < self.mWidthGarden:
                    col.append( cTile(j * self.TILE_WIDTH, i * self.TILE_HEIGHT, self.tiles[i][j].getTileIndex(), self.mapName, self.created ));
                    j += 1;
                i += 1;
                self.tilesGarden.append(col);
  
    def numberOfPaths(self, x, y):
        self.n = 0;
        if (x < 0 or y < 0 or x >= self.mWidth or y >= self.mHeight):
            return self.OUT_OF_RANGE;
        else:
            if (self.getTileIndex(x-2,y) == 1):
                self.n +=1;
            if (self.getTileIndex(x+2,y) == 1):
                self.n +=1;
            if (self.getTileIndex(x,y-2) == 1):
                self.n +=1;
            if (self.getTileIndex(x,y+2) == 1):
                self.n +=1;
        return self.n;
   
    def getTileListIndex(self, tile):
        self.listIndex = (int(tile.mX / self.TILE_WIDTH), int(tile.mY / self.TILE_HEIGHT));
        return self.listIndex;
    
    def setTile(self, x, y, aTileIndex):
        if (x < 0 or y < 0 or x >= self.mWidth or y >= self.mHeight):
#            print("Coordenadas fuera de rango: x=" + str(x) + " y=" + str(y));
            pass;
        else:
            self.tiles[y][x].setTileIndex(aTileIndex);
    
    def getTileIndex(self, x, y):
        if (x < 0 or y < 0 or x >= self.mWidth or y >= self.mHeight ):
#            print("Coordenadas fuera de rango: x=" + str(x) + " y=" + str(y));
            return self.OUT_OF_RANGE;
        else:
            return self.tiles[y][x].getTileIndex();
    
    def getWorldMaxX(self):
        return self.mWidth * self.TILE_WIDTH;
        
    def getWorldMaxY(self):
        return self.mHeight * self.TILE_HEIGHT;
        
    def getTileHeight(self):
        return self.TILE_HEIGHT;
    
    def getTileWidth(self):
        return self.TILE_WIDTH;
            
    def generateMaze(self, x, y):
    
        self.n = self.numberOfPaths(x, y);
        if (self.n == self.OUT_OF_RANGE or self.n == 0):
            return;
        
        self.i = random.randint(0, 3);

        for self.j in range(4):
            if (self.getTileIndex(x + (self.xOffset[self.i]) * 2, y + (self.yOffset[self.i] * 2)) == 1):
                
                self.setTile(x + (self.xOffset[self.i]) * 1, y + (self.yOffset[self.i] * 1), 2);
                self.setTile(x + (self.xOffset[self.i]) * 2, y + (self.yOffset[self.i] * 2), 2);
                self.generateMaze(x + (self.xOffset[self.i]) * 2, y + (self.yOffset[self.i] * 2));
            self.i += 1;
            if (self.i > 3):
                self.i = 0;
        
    def returnPlayerStartX(self):
        return (0 * self.TILE_WIDTH + 60);
    def returnPlayerStartY(self):
        return (6 * self.TILE_HEIGHT);  
     
    def destroy(self):
        self.mMap1 = None;
        self.OUT_OF_RANGE = None;
        self.TILE_EMPTY = None;
        self.TILE_HEIGHT = None;
        self.TILE_WALL = None;
        self.TILE_WIDTH = None;
        for self.tileList in self.tiles:
            for self.tile in self.tileList:
                self.tile.destroy();
        self.tiles = None;
        if(self.mapName == "interval"):
            self.leftExit = None;
            self.rightExit = None;
            self.neighbourPlace = None;
            self.distractorEnded = None;
        elif(self.mapName == "town"):
            self.museumDoor = None;
            self.museumDoor2 = None;
            self.circDoor = None;
            self.farmDoor = None;
            self.farmDoor2 = None;
            self.gardenDoor = None;
            self.gardenDoor2 = None;
        elif(self.mapName == "garden"):
            self.xOffset = None;
            self.yOffset = None;
            self.gardenExit = None;
            if(self.tilesGarden != None):
                for self.tileList in self.tilesGarden:
                    for self.gardenTile in self.tileList:
                        self.gardenTile.destroy();
                self.tilesGarden = None; 
            self.mWidthGarden =  None;
            self.mHeightGarden = None;        
            self.created = None;
        elif(self.mapName == "circus"):
            self.platform = None;
            self.case = None;
            self.lastCasePosX = None;  
        self.mWidth = None;
        self.mHeight = None;
        self.mapName = None;