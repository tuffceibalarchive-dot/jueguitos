'''
Created on Aug 14, 2013

@author: gustavogonzalezlamarque
'''
import pygame;
import Assets.Assets as A;

class Tutorial(pygame.sprite.DirtySprite):
    def __init__(self, container, aType):
        pygame.sprite.DirtySprite.__init__(self);
        self.container = container;
        self.isDead = False;    
        if(aType.name == "circ"):
            if(aType.circusType == "count"):
                self.image = pygame.Surface.convert_alpha(pygame.image.load(A.CIRCUSCONTUTO));
            else:
                if(aType.nowResta):
                    self.image = pygame.Surface.convert_alpha(pygame.image.load(A.CIRCUSRESTUTO));
                else:
                    self.image = pygame.Surface.convert_alpha(pygame.image.load(A.CIRCUSSUMTUTO));
        elif(aType.name == "farm"):  
            self.image = pygame.Surface.convert_alpha(pygame.image.load(A.FARMTUTO));
        elif(aType.name == "garden"):
            self.image = pygame.Surface.convert_alpha(pygame.image.load(A.GARDENTUTO));
        elif(aType.name == "museum"):
            self.image = pygame.Surface.convert_alpha(pygame.image.load(A.MUSEUMTUTO));
        elif(aType.name == "interval"):
            self.image = pygame.Surface.convert_alpha(pygame.image.load(A.INTERVALTUTO));
        elif(aType.name == "town"):
            self.image = pygame.Surface.convert_alpha(pygame.image.load(A.TOWNTUTO));
        elif(aType.name == "distractor"):
            self.image = pygame.Surface.convert_alpha(pygame.image.load(A.PETMESSAGE));
        
        self.rect = self.image.get_rect();
        self.rect.topleft = (50, 100);
        self.container.add(self);
    
    def destroy(self):
        self.container.remove(self);
        self.image = None;