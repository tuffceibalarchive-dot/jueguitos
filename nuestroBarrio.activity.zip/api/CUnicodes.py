# -*- coding: utf-8 -*- 
'''
Created on 04/04/2013

@author: Gus
'''

import unicodedata;

class cUnicodes(object):
    '''
    classdocs
    '''
    
    a = (b'\xc3\xa1').decode('utf-8');
    e = (b'\xc3\xa9').decode('utf-8');
    i = (b'\xc3\xad').decode('utf-8');
    o = (b'\xc3\xb3').decode('utf-8');
    u = (b'\xc3\xba').decode('utf-8');
    excl = (b'\xc2\xa1').decode('utf-8');
    preg = (b'\xc2\xbf').decode('utf-8');
    
#def to_unicode_or_bust(obj, encoding='utf-8'):
#    if (isinstance(obj, basestring)):
#        if not isinstance(obj, unicode):
#            obj = unicode(obj, encoding);
#            return obj