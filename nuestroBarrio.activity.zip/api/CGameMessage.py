'''
Created on 09/04/2013

@author: Gus
'''

from CSign import sign;
from CBust import cBust;
from api.CText import cText;
import pygame;
class cGameMessage(object):
    '''
    classdocs
    '''

    def __init__(self, aType, textList, aLevelType):
        '''
        Level name in string format, list of strings, every index of the list is a line in the paragraph
         to include in the level, the level where we want the sign.
        '''
        
        self.mLevelType = aLevelType;
        if(aType != None):
            if(aType != "pet"):
                self.sign = sign(aType, 600, 400, 300, 200, aLevelType);
            else:
                self.sign = sign(aType, 795, 476, 200, 100, aLevelType);
                
            self.bust = cBust(self.sign.mX, self.sign.mY, aType, aLevelType);
        else:
            self.sign = None;
            self.bust = None;
            
        self.text = pygame.sprite.OrderedUpdates();
        self.i = 0;
        while self.i < len(textList):
            if(aType != "pet"):
                self.textToAdd = cText(textList[self.i], self.i + 1, self.sign, 40, self.text);
            else:
                self.textToAdd = cText(textList[self.i], self.i + 1, self.sign, 30, self.text);
            self.i += 1;
        
#        for line in textList:
#            self.text = cText(line, textList[line + 1], self.sign, self.text);
        if(self.mLevelType.name != "town"):
            if(aType != None):
                self.mLevelType.allSprites.add(self.sign, self.bust, self.text);
            else:
                self.mLevelType.allSprites.add(self.text);
        
    def destroy(self):
        if(self.sign !=None):
            self.sign.destroy();
            self.sign = None;
        if(self.bust != None):
            self.bust.destroy();
            self.bust = None;
        for self.texts in self.text:
            self.texts.destroy();
        self.text = None;
        self.mLevelType = None;
        self.i = 0;

        
        
        
        