'''
Created on 30/04/2013

@author: Gus
'''

import pygame;

#===============================================================================
# BEGIN OF SINGLETON
#===============================================================================
class cKeyPoll:
    # Create a class variable that will hold a reference
    # to the single instance of TestSingleton.

    instance = None

    # Define a helper class that will override the __call___
    # method in order to provide a factory method for TestSingleton.

    class TestSingletonHelper:

        def __call__( self, *args, **kw ) :

            # If an instance of TestSingleton does not exist,
            # create one and assign it to TestSingleton.instance.

            if cKeyPoll.instance is None :
                toBeInst = cKeyPoll()
                cKeyPoll.instance = toBeInst

            # Return TestSingleton.instance, which should contain
            # a reference to the only instance of TestSingleton
            # in the system.

            return cKeyPoll.instance
    # Create a class level method that must be called to
    # get the single instance of TestSingleton.

    inst = TestSingletonHelper()
    
    # Initialize an instance of the TestSingleton class.

    def __init__(self):
        # Optionally, you could go a bit further to guarantee
        # that no one created more than one instance of TestSingleton:

        if not cKeyPoll.instance == None :
            raise RuntimeError
    
        self.ESCAPE = pygame.K_ESCAPE;
        self.SPACE = pygame.K_SPACE;
        self.UP = pygame.K_UP;
        self.DOWN = pygame.K_DOWN;
        self.LEFT = pygame.K_LEFT;
        self.RIGHT = pygame.K_RIGHT;
        
        self.KEYCOUNT = 256;
        self.mList = [];
        self.mPrevList = [];
        
        self.i = 0;
        for self.i in range(self.KEYCOUNT):
            self.mList.append(False);
            self.mPrevList.append(False);
            
        
    
    #===========================================================================
    # END OF SINGLETON
    #===========================================================================
    
      
    def keyDownHandler(self, event):
        self.keyCode = event.key;
        if(self.keyCode < self.KEYCOUNT):
            self.mList[self.keyCode] = True;
        
    def keyUpHandler(self, event):
        self.keyCode = event.key;
        if(self.keyCode < self.KEYCOUNT):
            self.mList[self.keyCode] = False;
    
    
    def clearKeys(self, event):
        for self.keyCode in range(self.KEYCOUNT):
            self.mList[self.keyCode] = self.mPrevList[self.keyCode] = False;
                
    def anyKeyPressed(self):
        for self.keyCode in range(self.KEYCOUNT):
            if(self.mList[self.keyCode] == True):
                return True;
                print("anyKey")
        return False;
    
    def update(self):
        for self.keyCode in range(self.KEYCOUNT):
            self.mPrevList[self.keyCode] = self.mList[self.keyCode];


    def pressed(self, aKeyCode):
        if(aKeyCode < self.KEYCOUNT):
            return self.mList[aKeyCode];
        return False;
    
    def firstPress(self, aKeyCode):
        if self.mPrevList[aKeyCode] == False and self.mList[aKeyCode]:
            return True;
        return False;
    
    def release(self, aKeyCode):
        if self.mPrevList[aKeyCode] == True and self.mPrevList[aKeyCode]:
            return True;
        return False;

    def destroy(self):
        if(cKeyPoll.instance != None):
            self.mPrevList.remove(0);
            self.mPrevList = None;
            self.mList.remove(0);
            self.mList = None;
            cKeyPoll.instance = False;
        
    