'''
Created on 19/03/2013

@author: Gus
'''
import math;

    
def dist( aX1, aY1, aX2, aY2):

    return math.sqrt((aX2 - aX1) * (aX2 - aX1) + (aY2 - aY1) * (aY2 - aY1));
    
    
def rectRectCollision(self, aX1, aY1, aW1, aH1, aX2, aY2, aW2, aH2):
    
    if ((((aX1 + aW1) > aX2) and (aX1 < (aX2 + aW2))) and (((aY1 + aH1) > aY2) and (aY1 < (aY2 + aH2)))):
        return True;
    else:
        return False;
    