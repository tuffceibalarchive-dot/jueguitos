
'''
Created on 02/04/2013

@author: Gus
'''
import pygame;
import Assets.Assets as A;
class cText(pygame.sprite.Sprite):
    '''
    classdocs
    '''


    def __init__(self, aText, aLine, aSign, aLetterSize, aSpriteGroup):
        '''
        Constructor
        '''
        pygame.sprite.Sprite.__init__(self);
        self.isDead = False;
        self.mText = aText.upper();
        if(aSign != None):
            self.mSign = aSign;
            if(self.mSign.mType != "pet"):
                self.mLine = aLine * 40;
                self.x = self.mSign.mX + 50 + (self.mLine/3);
                self.y = self.mSign.mY + self.mLine;
            else:
                self.mLine = aLine * 40;
                self.x = self.mSign.mX + 230 + (self.mLine/3);
                self.y = (self.mSign.mY + 200) + self.mLine;
        else:
#             self.x = 400;
#             self.y = 200;
            self.mLine = aLine * 40;
            self.x = 590 + (self.mLine/3);
            self.y = 95 + self.mLine;
            
        self.mSpriteGroup = aSpriteGroup;
        self.font= pygame.font.Font(A.DEJAVUFONT, aLetterSize);
        self.image = pygame.Surface.convert_alpha(self.font.render(self.mText, 1, (255,255,255)));
 
        self.rect = self.image.get_rect();
        self.rect.topleft = self.x,self.y;
        
        self.mSpriteGroup.add(self);
        #self.mSpriteGroup.allSprites.add(self);
    def setCoords(self, x, y):
        self.x = x;
        self.y = y;
        self.rect.topleft = self.x,self.y;
        
    def SetCenterReg(self, x, y):
        self.x = x;
        self.y = y;
        self.rect.center = self.x, self.y;
    def destroy(self):
        self.mSpriteGroup.remove(self);
        self.image = None;
        self.rect = None;
        self.mText = None;
        self.isDead = None;
        self.mSign = None;
        self.x = None;
        self.y = None;
        self.mLine = None;
        self.font = None;