'''
Created on 25/02/2013

@author: Gus
'''
from api.CSaveData import CSaveData;
class cProgressSave(object):
    '''
    classdocs
    '''
    def __init__(self):
        '''
        Constructor
        '''
        self.characterSelected = None;
        self.difficultySelected = None;
        
        if( CSaveData.inst().has_key("circusRate","miBarrio", "save.txt") ):
            self.circusRate = CSaveData.inst().getData("circusRate", "miBarrio", "save.txt")
        else:
            self.circusRate = None; 
            
        if( CSaveData.inst().has_key("museumRate","miBarrio", "save.txt") ):
            self.museumRate = CSaveData.inst().getData("museumRate", "miBarrio", "save.txt")
        else:
            self.museumRate = None;      

        if( CSaveData.inst().has_key("gardenRate","miBarrio", "save.txt") ):
            self.gardenRate = CSaveData.inst().getData("gardenRate", "miBarrio", "save.txt")
        else:
            self.gardenRate = None;
                                                 
        if( CSaveData.inst().has_key("medal","miBarrio", "save.txt") ):
            self.newMedal = CSaveData.inst().getData("newMedal", "miBarrio", "save.txt")
        else:
            self.newMedal = False;
        #MedalAwarded
        if( CSaveData.inst().has_key("medal","miBarrio", "save.txt") ):
            self.medal = CSaveData.inst().getData("medal", "miBarrio", "save.txt")
        else:
            self.medal = None;
        #Scores
        if( CSaveData.inst().has_key("circusScore","miBarrio", "save.txt") ):
            self.circusScore = CSaveData.inst().getData("circusScore", "miBarrio", "save.txt")
        else:
            self.circusScore = [None,None];
#       
        if( CSaveData.inst().has_key("museumScore","miBarrio", "save.txt") ):
            self.museumScore = CSaveData.inst().getData("museumScore", "miBarrio", "save.txt")
        else:
#             self.museumScore = {"stage01":None, "stage02":None,"stage03":None, "stage04":None,"stage05":None};
            self.museumScore = [None,None,None,None,None];
        if( CSaveData.inst().has_key("gardenScore","miBarrio", "save.txt") ):
            self.gardenScore = CSaveData.inst().getData("gardenScore", "miBarrio", "save.txt")
        else:
            self.gardenScore = [None,None,None];
            
        if( CSaveData.inst().has_key("farmScore","miBarrio", "save.txt") ):
            self.farmScore = CSaveData.inst().getData("farmScore", "miBarrio", "save.txt")
        else:
            self.farmScore = None;
        #Neighbour list    
        if( CSaveData.inst().has_key("toHelpList","miBarrio", "save.txt") ):
            self.toHelpList = CSaveData.inst().getData("toHelpList", "miBarrio", "save.txt")
        else:
            self.toHelpList = [0,1,2,3,4];
        
        #If a new pic is given
        if( CSaveData.inst().has_key("newPic","miBarrio", "save.txt") ):
            self.newPic = CSaveData.inst().getData("newPic", "miBarrio", "save.txt")
        else:
            self.newPic = False;
        
        #Is first time play    
        if( CSaveData.inst().has_key("config","miBarrio", "save.txt") ):
            self.config = CSaveData.inst().getData("config", "miBarrio", "save.txt")
        else:
            self.config = {"firstTimeTuto":True, "distractorOn": True};
            
        #Game Completed bool
        if( CSaveData.inst().has_key("gameCompleted","miBarrio", "save.txt") ):
            self.gameCompleted = CSaveData.inst().getData("gameCompleted", "miBarrio", "save.txt")
        else:
            self.gameCompleted = False;

        #Pantallas pasadas
        if( CSaveData.inst().has_key("stagesPassed","miBarrio", "save.txt") ):
            self.stagesPassed = CSaveData.inst().getData("stagesPassed", "miBarrio", "save.txt")
        else:
            self.stagesPassed = {"circus":False, "museum":False, "garden":False, "farm":False};
            
        #Audio variables
        if( CSaveData.inst().has_key("fxOn","miBarrio", "save.txt") ):
            self.fxOn = CSaveData.inst().getData("fxOn", "miBarrio", "save.txt")
        else:
            self.fxOn = True;    
        if(CSaveData.inst().has_key("audioOn","miBarrio", "save.txt") ):
            self.audioOn = CSaveData.inst().getData("audioOn", "miBarrio", "save.txt")
        else:
            self.audioOn = True; 
        #Pic management
        if( CSaveData.inst().has_key("pics","miBarrio", "save.txt") ):
            self.pics = CSaveData.inst().getData("pics", "miBarrio", "save.txt")
        else:           
            self.pics = {"circus01":False, "circus02":False, "circus03":False,
                          "museum01":False, "museum02":False, "garden01":False,
                          "garden02":False, "farm01":False, "farm02":False,
                          "vecino00":False, "vecino01":False, "vecino02":False,
                          "vecino03":False, "vecino04":False, "gameCompleted":False}
                
        if( CSaveData.inst().has_key("playerLastPos","miBarrio", "save.txt") ):
            self.playerLastPos = CSaveData.inst().getData("playerLastPos", "miBarrio", "save.txt")
        else:
            self.playerLastPos = (325, 500);
        self.SaveValues();
         
    def SaveValues(self):
        CSaveData.inst().saveData("toHelpList", self.toHelpList, "miBarrio", "save.txt");
        CSaveData.inst().saveData("fxOn", self.fxOn, "miBarrio", "save.txt");
        CSaveData.inst().saveData("audioOn", self.audioOn, "miBarrio", "save.txt");
        CSaveData.inst().saveData("pics",self.pics,"miBarrio", "save.txt");
        CSaveData.inst().saveData("playerLastPos", self.playerLastPos,"miBarrio", "save.txt");
        CSaveData.inst().saveData("stagesPassed",self.stagesPassed,"miBarrio", "save.txt");
        CSaveData.inst().saveData("gameCompleted",self.gameCompleted,"miBarrio", "save.txt")
        CSaveData.inst().saveData("config",self.config,"miBarrio", "save.txt")
        CSaveData.inst().saveData("newPic", self.newPic, "miBarrio", "save.txt"); 
        CSaveData.inst().saveData("circusScore", self.circusScore, "miBarrio", "save.txt"); 
        CSaveData.inst().saveData("museumScore", self.museumScore, "miBarrio", "save.txt"); 
        CSaveData.inst().saveData("gardenScore", self.gardenScore, "miBarrio", "save.txt"); 
        CSaveData.inst().saveData("farmScore", self.farmScore, "miBarrio", "save.txt"); 
        CSaveData.inst().saveData("medal", self.medal, "miBarrio", "save.txt"); 
        CSaveData.inst().saveData("newMedal", self.newMedal, "miBarrio", "save.txt"); 
        CSaveData.inst().saveData("circusRate", self.circusRate, "miBarrio", "save.txt"); 
        CSaveData.inst().saveData("gardenRate", self.gardenRate, "miBarrio", "save.txt"); 
        CSaveData.inst().saveData("museumRate", self.museumRate, "miBarrio", "save.txt"); 
            
    def ResetValues(self): 
        self.circusRate = None;
        self.gardenRate = None;
        self.museumRate = None;
        self.newMedal = False;
        self.medal = None;
        self.circusScore = [None,None];
        self.museumScore = [None,None,None,None,None];
        self.gardenScore = [None,None,None];
        self.farmScore = None    
        self.toHelpList = [0,1,2,3,4];
        self.newPic = False;
        self.characterSelected = None;
        self.difficultySelected = None;
        self.config = {"firstTimeTuto":True, "distractorOn": True};
        self.gameCompleted = False;
        self.stagesPassed = {"circus":False, "museum":False, "garden":False, "farm":False};
        self.playerLastPos = (325, 500);
        self.pics = {"circus01":False, "circus02":False, "circus03":False,
                          "museum01":False, "museum02":False, "garden01":False,
                          "garden02":False, "farm01":False, "farm02":False,
                          "vecino00":False, "vecino01":False, "vecino02":False,
                          "vecino03":False, "vecino04":False, "gameCompleted":False};
        self.SaveValues();
    
    def GetPerformanceRate(self, gameType):
        self.rateToReturn = 0;
        if(gameType == "circus"):
            for circusVal in self.circusScore:
                self.rateToReturn +=circusVal;
            self.rateToReturn = self.rateToReturn/2;
        elif(gameType == "museum"):
            for museumVal in self.museumScore:
                self.rateToReturn += museumVal;
            self.rateToReturn = self.rateToReturn/5;
        elif(gameType == "garden"):
            for gardenVal in self.gardenScore:
                self.rateToReturn += gardenVal;
            self.rateToReturn = self.rateToReturn/3;
        return self.rateToReturn;  
    def DeliverMedal(self):
        self.averageScore = 0;
        #promedio total y seteo medalla
#         print("museumRate " + str(self.museumRate))
#         print("gardenRate " + str(self.gardenRate))
#         print("circusRate " + str(self.circusRate))
#         print("farm " + str(self.farmScore))
        self.averageScore = (self.museumRate + self.circusRate + self.gardenRate + self.farmScore)/4;
#         print("total rate " + str(self.averageScore))
        if(self.medal == None or (self.medal < self.averageScore - 1)): #Medal va de 0 a 2 y average de 1 a 3 por eso.
            if(self.averageScore == 3):
                self.medal = 2;
            elif(self.averageScore == 2):
                self.medal = 1;
            elif(self.averageScore == 1):
                self.medal = 0;
            self.newMedal = True;
        
#         print("medal " + str(self.medal))
        self.SaveValues();