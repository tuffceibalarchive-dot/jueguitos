'''
Created on Jul 11, 2013

@author: gustavogonzalezlamarque
'''

import os;


# ---------------- Game audio assets paths ---------------- #

BASE = os.path.dirname(__file__);
MUSICS = os.path.join(BASE, "audio/musics");
MAIN = os.path.join(BASE, "audio/main");
DISTRACTOR = os.path.join(BASE, "audio/distractor");
CIRCUS = os.path.join(BASE, "audio/circus");
FARM = os.path.join(BASE, "audio/farm");
GARDEN = os.path.join(BASE, "audio/garden");
MUSEUM = os.path.join(BASE, "audio/museum");
PIQUITO = os.path.join(BASE, "audio/piquito");
FATIMA = os.path.join(BASE, "audio/fatima");
JAIME = os.path.join(BASE, "audio/jaime");
PEDRO = os.path.join(BASE, "audio/pedro");
LAURA = os.path.join(BASE, "audio/laura");
#------------------ Background musics-----------------------#

MUSICMAIN = os.path.join(MUSICS, "nb_bgmusic_menu.ogg");
MUSICTOWN = os.path.join(MUSICS, "nb_bgmusic_barrio.ogg");
MUSICINTERVALS = os.path.join(MUSICS, "nb_bgmusic_barrio.ogg");
MUSICCIRCUS = os.path.join(MUSICS, "nb_bgmusic_circo.ogg");
MUSICMUSEUM = os.path.join(MUSICS, "nb_bgmusic_museo.ogg");
MUSICGARDEN = os.path.join(MUSICS, "nb_bgmusic_laberinto.ogg");
MUSICFARM = os.path.join(MUSICS, "nb_bgmusic_granja.ogg");
MUSICALBUM = os.path.join(MUSICS, "nb_bgmusic_barrio.ogg");
MUSICDISTRACTOR = os.path.join(MUSICS, "nuestrobarrio_bgmusic_memoria[musica+ambiente].ogg");

#------------------ Main Menu -----------------------------#
BTNPLAY = os.path.join(MAIN, "nuestrobarrio_sfx_menu_click.ogg");
BTNHOVER = os.path.join(MAIN, "nuestrobarrio_sfx_menu_mouseover.ogg");

#------------------ Distractor ----------------------------#
PAIRMATCH = os.path.join(DISTRACTOR, "nuestrobarrio_sfx_memoria_pareja.ogg");
SHOWCARD = os.path.join(DISTRACTOR, "nuestrobarrio_sfx_memoria_carta.ogg");

#-------------------Circus-----------------------#
SELECTANIMAL = os.path.join(CIRCUS, "nuestrobarrio_sfx_circo_click[op1].ogg");
ERASEANIMAL = os.path.join(CIRCUS, "nuestrobarrio_sfx_circo_click[op2].ogg");

#---------------------Farm----------------------#
COLOCAR = os.path.join(FARM, "nuestrobarrio_sfx_granja_colocar.ogg");
RECOLECTAR = os.path.join(FARM, "nuestrobarrio_sfx_granja_recolectar.ogg");
GALLINA = os.path.join(FARM, "nuestrobarrio_sfx_granja_gallina.ogg");
VACA = os.path.join(FARM, "nuestrobarrio_sfx_granja_vaca.ogg");
#--------------------Garden---------------------#
CANILLA = os.path.join(GARDEN, "nuestrobarrio_sfx_laberinto_cierracanilla.ogg");
BASURA = os.path.join(GARDEN, "nuestrobarrio_sfx_laberinto_basura.ogg");
CONTENEDOR = os.path.join(GARDEN, "nuestrobarrio_sfx_laberinto_contenedorOP2.ogg");

#-------------------Museum--------------------$
PINTARBIEN = os.path.join(MUSEUM, "nuestrobarrio_sfx_museo_bienpintado.ogg");
PINTARMAL = os.path.join(MUSEUM, "nuestrobarrio_sfx_museo_malpintado.ogg");
CARGAR = os.path.join(MUSEUM, "nuestrobarrio_sfx_museo_cargapintura.ogg");
LIMPIAR = os.path.join(MUSEUM, "nuestrobarrio_sfx_museo_limpiarpincel.ogg");

#-------------------Voices-----------------------#
#-------------------Piquito----------------------#
INTRO = os.path.join(PIQUITO, "piquito_introduccion.ogg");
OUTRO = os.path.join(PIQUITO, "piquito_emprendedorgenial.ogg");
PIQUITOUPS1=os.path.join(PIQUITO, "piquito_ups1.ogg");
PIQUITOUPS2=os.path.join(PIQUITO, "piquito_ups2.ogg");
PIQUITOYAHOO = os.path.join(PIQUITO, "piquito_yahoo.ogg");
PIQUITOGENIAL = os.path.join(PIQUITO, "piquito_genial.ogg");
PIQUITOGENIAL2 = os.path.join(PIQUITO, "piquito_genial2.ogg");
PIQUITOVAMOSOTRAVEZ = os.path.join(PIQUITO, "piquito_vamosotravez.ogg");
PIQUITOBIBLIOTECA = os.path.join(PIQUITO, "piquito_biblioteca.ogg");
PIQUITOABUELO = os.path.join(PIQUITO, "piquito_abuelo.ogg");
PIQUITOBILLETERA = os.path.join(PIQUITO, "piquito_billetera.ogg");
PIQUITOBIENHECHO = os.path.join(PIQUITO, "piquito_bienhecho.ogg");
PIQUITOBOLSA = os.path.join(PIQUITO, "piquito_bolsas.ogg");
PIQUITOPERRITO= os.path.join(PIQUITO, "piquito_perrito.ogg");
#-------------------Fatima------------------------#
FATIMABIENVENIDA = os.path.join(FATIMA, "fatima_introduccion.ogg");
FATIMABIENHECHO = os.path.join(FATIMA, "fatima_bienhecho.ogg");
FATIMAGENIAL = os.path.join(FATIMA, "fatima_genial.ogg");
FATIMAGRACIAS = os.path.join(FATIMA, "fatima_graciasporlaayuda.ogg");
FATIMADENUEVO = os.path.join(FATIMA, "fatima_intentalodenuevo.ogg");
#-------------------Jaime-------------------------#
JAIMEBIENVENIDA = os.path.join(JAIME, "jaime_introduccion.ogg");
JAIMEGRACIAS = os.path.join(JAIME, "jaime_gracias.ogg");
JAIMEOHLALA = os.path.join(JAIME, "jaime_ohlala.ogg");
JAIMEMUYBIEN = os.path.join(JAIME, "jaime_muybien.ogg");
#--------------------Pedro------------------------#
PEDROBIENVENIDA = os.path.join(PEDRO, "pedro_introduccion.ogg");
PEDROBIENHECHO = os.path.join(PEDRO, "pedro_bienhecho.ogg");
PEDROGRACIAS = os.path.join(PEDRO, "pedro_muchasgracias.ogg");
PEDROEXCELENTE = os.path.join(PEDRO, "pedro_excelente.ogg");
PEDRODENUEVO = os.path.join(PEDRO, "pedro_intentalodenuevo.ogg");
#-------------------Laura--------------------------#
LAURABIENVENIDA = os.path.join(LAURA, "laura_introduccion.ogg");
LAURABIENHECHO = os.path.join(LAURA, "laura_bienhecho.ogg");
LAURAFANTASTICO = os.path.join(LAURA, "laura_fantastico.ogg");
LAURADENUEVO = os.path.join(LAURA, "laura_intentalodenuevo.ogg");
LAURAGRACIAS = os.path.join(LAURA, "laura_muchasgracias.ogg");
LAURAGENIAL = os.path.join(LAURA, "laura_genial.ogg");