'''
Created on 18/02/2013

@author: Gus
'''
import pygame.sprite;

class Button(pygame.sprite.Sprite):
    """Class used to create a button, use setCords to set 
        position of topleft corner. Method pressed() returns
        a boolean to be used inside eventUpdate."""
    def __init__(self, imgName, x, y):
        pygame.sprite.Sprite.__init__(self);
        self.image =  pygame.Surface.convert_alpha(pygame.image.load(imgName));
        self.rect = self.image.get_rect();
        self.originalRect = self.rect;
        self.originalImg = self.image;
        self.originalCoords = (x, y);
        self.setCords((x, y));
    def setCords(self, coords):
        """coords is a tuple with the format (x, y)"""
        self.rect.topleft = coords;
    def pressed(self):
        self.mousePos = pygame.mouse.get_pos();
        if self.mousePos[0] > self.rect.topleft[0]:
            if self.mousePos[1] > self.rect.topleft[1]:
                if self.mousePos[0] < self.rect.topleft[0] + self.rect[2]:
                    if self.mousePos[1] < self.rect.topleft[1] + self.rect[3]:
                        return True
                    else: return False
                else: return False
            else: return False
        else: return False
        pass
    
    def mouseOver(self):
        self.onMe = False;
        if(self.pressed()):
            #self.image = self.resize(self.image, 2);
            #self.setCords((self.originalCoords[0] - self.rect[2]/2, self.originalCoords[1] - self.rect[3]/2));
            self.onMe = True;
        else:
            self.onMe = False;
            #self.image = self.originalImg;
            #self.setCords(self.originalCoords)
        return self.onMe;
    def resize(self, surface, size):
        self.scale = (self.rect[2] * size, self.rect[3] * size);
        return pygame.transform.smoothscale(surface, self.scale);
    
    def update(self):
        self.pressed();
#        self.mouseOver();
    def destroy(self):
        self.image = None;
        self.rect = None;
        self.originalCoords = None;
        self.originalImg = None;
        self.originalRect = None;
        self.onMe = None;