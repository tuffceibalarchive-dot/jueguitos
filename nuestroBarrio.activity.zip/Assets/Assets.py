
'''
Created on 03/01/2013

@author: Gus
'''
import os
import pygame;


RES = (1200, 900);
FLAGS = pygame.FULLSCREEN;

# ---------------- Game assets paths ---------------- #
BASE = os.path.dirname(__file__);
IMAGES = os.path.join(BASE, "");

MAIN = os.path.join(BASE, "mainMenu");
CREDITS = os.path.join(BASE,"credits");
TOWNMAP = os.path.join(BASE, "townMap");
GARDENS = os.path.join(BASE, "gardens");
DIFFICULTYMENU = os.path.join(BASE, "difficultiesSelector") ;
PLAYERSELECTMENU = os.path.join(BASE, "playerSelection");
MUSEUM = os.path.join(BASE, "museum");
MUSEUMBEACH = os.path.join(BASE, "museum/Playa");
MUSEUMCAMPO = os.path.join(BASE, "museum/Campo");
MUSEUMCIUDAD = os.path.join(BASE, "museum/Ciudad");
MUSEUMMOUNT = os.path.join(BASE, "museum/montana");
MUSEUMLAKE = os.path.join(BASE, "museum/lago");
CIRCUS = os.path.join(BASE, "circus");
FARM = os.path.join(BASE, "farm");
INTERVALS = os.path.join(BASE, "intervals");
FONTSFOLDER = os.path.join(BASE, "fonts");
DISTRACTOR = os.path.join(BASE, "distractor");
PAUSE = os.path.join(BASE, "pause");
ALBUM = os.path.join(BASE, "album");
TUTORIALS = os.path.join(BASE, "instrucciones"); 
#---------------------------------------------------- #

#---------------------album menu---------------------#
ALBUMCOVER = os.path.join(ALBUM, "album_00.png");
ALBUMPAGEONE = os.path.join(ALBUM, "album_01.png");
ALBUMPAGETWO = os.path.join(ALBUM, "album_02.png");
BTNCLOSE = os.path.join(ALBUM, "close.png");
BTNLEFT = os.path.join(ALBUM, "left.png");
BTNRIGHT = os.path.join(ALBUM, "right.png");
MEDALS = os.path.join(ALBUM, "medals.png");
LABELS = os.path.join(ALBUM, "labels.png");
#Fotos
CIRCUS01 = os.path.join(ALBUM, "01.png");
CIRCUS02 = os.path.join(ALBUM, "02.png");
CIRCUS03 = os.path.join(ALBUM, "03.png");
MUSEUM01 = os.path.join(ALBUM, "04.png");
MUSEUM02 = os.path.join(ALBUM, "05.png");
GARDEN01 = os.path.join(ALBUM, "06.png");
GARDEN02 = os.path.join(ALBUM, "07.png");
FARM01 = os.path.join(ALBUM, "08.png");
FARM02 = os.path.join(ALBUM, "09.png");
DISTRACTOR01 = os.path.join(ALBUM, "10.png");
DISTRACTOR02 = os.path.join(ALBUM, "11.png");
DISTRACTOR03 = os.path.join(ALBUM, "12.png");
DISTRACTOR04 = os.path.join(ALBUM, "13.png");
DISTRACTOR05 = os.path.join(ALBUM, "14.png");
ENDGAME = os.path.join(ALBUM, "15.png");
#-----------------------Pause menu---------------------#
TRANSPARENCY = os.path.join(PAUSE, "transparencia.png");
GOTOMENU = os.path.join(PAUSE, "quit.png");
GOTOALBUM = os.path.join(PAUSE, "gotoAlbum.png");
PAUSEINGAMEBTN = os.path.join(PAUSE, "pauseInGameBtn.png");
PAUSEINGAMEBCK = os.path.join(PAUSE, "pauseInGameBck.png");
#---------------------- Main menu -------------------- #
BTNJUGAR = os.path.join(MAIN, "nuevojuego.png");
BTNCONTINUAR = os.path.join(MAIN, "continuar.png");
BTNCREDITOS = os.path.join(MAIN, "credits.png");
NEWGAME = os.path.join(MAIN, "newgame.png");
MAINMENU = os.path.join(MAIN, "mainMenu.png");
MAINANIM = os.path.join(MAIN, "main3.png");
PARLANTE = os.path.join(MAIN, "parlante.png");
MUSICABTN = os.path.join(MAIN, "musica.png");
FXBTN = os.path.join(MAIN, "sonido.png");
MAINFOREGROUND = os.path.join(MAIN, "main2.png");

#---------------------Credits---------------------- #
MENUCREDITS = os.path.join(CREDITS, "creditos.png");
#------------------- Difficulties menu ----------------- #

DIFFICULTYBACK = os.path.join(DIFFICULTYMENU, "dificultades.png");
FACIL = os.path.join(DIFFICULTYMENU, "facil.png");
NORMAL = os.path.join(DIFFICULTYMENU, "normal.png");
DIFICIL = os.path.join(DIFFICULTYMENU, "dificil.png");
#---------------------------------------------------- #

#-------------------------Player Selection Menu----------------- #
PLAYERSELECTBACK = os.path.join(PLAYERSELECTMENU, "SPBack.png");
BTNGOTOTOWN = os.path.join(PLAYERSELECTMENU, "goTown.png");
            #----------Botones -----------#
PLAYER_1C = os.path.join(PLAYERSELECTMENU, "player_01c.png");
PLAYER_1G = os.path.join(PLAYERSELECTMENU, "player_01g.png");
PLAYER_2C = os.path.join(PLAYERSELECTMENU, "player_02c.png");
PLAYER_2G = os.path.join(PLAYERSELECTMENU, "player_02g.png");
PLAYER_3C = os.path.join(PLAYERSELECTMENU, "player_03c.png");
PLAYER_3G = os.path.join(PLAYERSELECTMENU, "player_03g.png");
PLAYER_4C = os.path.join(PLAYERSELECTMENU, "player_04c.png");
PLAYER_4G = os.path.join(PLAYERSELECTMENU, "player_04g.png");
PLAYER_5C = os.path.join(PLAYERSELECTMENU, "player_05c.png");
PLAYER_5G = os.path.join(PLAYERSELECTMENU, "player_05g.png");
PLAYER_6C = os.path.join(PLAYERSELECTMENU, "player_06c.png");
PLAYER_6G = os.path.join(PLAYERSELECTMENU, "player_06g.png");
            #----------------------------#
CHARACTERSPRITESHEET = os.path.join(PLAYERSELECTMENU, "chars.png");
#-----------------------------------------------------------------#

#------------------------ Text Signs---------------------------#
TEXTSQUARESSHEET = os.path.join(TOWNMAP, "recuadros_dialogos.png");
BUSTSHEET = os.path.join(TOWNMAP, "bustos.png");
DEJAVUFONT = os.path.join(FONTSFOLDER, "DejaVuLGCSans.ttf");
#----------------- Town Map --------------------------#
TOWN = os.path.join(TOWNMAP, "mapa_barrio.png");
MUSEO = os.path.join(TOWNMAP, "museo.png")
PLAYERSSPRITES = os.path.join(TOWNMAP, "Chars_Anim.png");
CARTELITO = os.path.join(TOWNMAP, "cartelito.png");
ACHIEVEMENT = os.path.join(TOWNMAP, "achievement.png");
MEDALSIGN = os.path.join(TOWNMAP, "aviso_medallas.png");
DISTRACTORONOFF = os.path.join(TOWNMAP, "distractoresonoff.png");
#-----------------------------------------------------#

#--------------------Garden maps ---------------------#
GARDENTILES_60 = os.path.join(GARDENS, "tiles_60.png");
GARDENTILES_75 = os.path.join(GARDENS, "tiles_75.png");
GARDENTILES_100 = os.path.join(GARDENS, "tiles_100.png");
TRASH_60 = os.path.join(GARDENS, "trash_60.png");
TRASH_75 = os.path.join(GARDENS, "trash_75.png");
TRASH_100 = os.path.join(GARDENS, "trash_100.png");
CANILLAS_60 = os.path.join(GARDENS, "canillas_60.png");
CANILLAS_75 = os.path.join(GARDENS, "canillas_75.png");
CANILLAS_100 = os.path.join(GARDENS, "canillas_100.png");
TRASHCAN_60 = os.path.join(GARDENS, "trashcan_60.png");
TRASHCAN_75 = os.path.join(GARDENS, "trashcan_75.png");
TRASHCAN_100 = os.path.join(GARDENS, "trashcan_100.png");
GARDENTIMERUP = os.path.join(GARDENS, "barra_up.png");
GARDENTIMERDOWN = os.path.join(GARDENS, "barra_down.png");
#--------------------------------------------------------#


#-------------------Museum----------------------------#
MUSEUMBACKGROUND = os.path.join(MUSEUM, "museum_background.png");
PAINTSHEET = os.path.join(MUSEUM, "paints.png");
BUCKETSHEET = os.path.join(MUSEUM, "bucket.png");
#-------------PLAYA----------#
MUSEUMBACKGROUNDBEACH = os.path.join(MUSEUMBEACH, "museum_background_beach.png");
SOL = os.path.join(MUSEUMBEACH, "02_sol.png");
NUBES = os.path.join(MUSEUMBEACH, "03_nubes.png");
CASTILLOS = os.path.join(MUSEUMBEACH, "04_castillitos.png");
SHELLS = os.path.join(MUSEUMBEACH, "05_shells.png");
SOMBRILLA = os.path.join(MUSEUMBEACH, "06_sombrilla.png");
SOMBRERO = os.path.join(MUSEUMBEACH, "07_sombrero.png");
FLOTADOR = os.path.join(MUSEUMBEACH, "08_flotador.png");
ISLA = os.path.join(MUSEUMBEACH, "09_isla.png");
FARO = os.path.join(MUSEUMBEACH, "10_faro.png");
PELOTA = os.path.join(MUSEUMBEACH, "11_pelota.png");
RELLENO = os.path.join(MUSEUMBEACH, "12_rellenos.png");
SANDIA = os.path.join(MUSEUMBEACH, "13_sandia.png");
PLANTA = os.path.join(MUSEUMBEACH, "14_planta.png");
PALMERA = os.path.join(MUSEUMBEACH, "15_palmera.png");
SURFBOARD = os.path.join(MUSEUMBEACH, "16_surfboard.png");
#-----------CAMPO--------------#
MUSEUMBACKGROUNDCAMPO = os.path.join(MUSEUMCAMPO, "fondocampo.png");
BERENJENA = os.path.join(MUSEUMCAMPO, "berenjena.png");
CHOCLO = os.path.join(MUSEUMCAMPO, "choclo.png");
ZAPALLO = os.path.join(MUSEUMCAMPO, "zapallo.png");
HUEVO = os.path.join(MUSEUMCAMPO, "huevo.png");
ARANA = os.path.join(MUSEUMCAMPO, "arana.png");
VIOLETAS = os.path.join(MUSEUMCAMPO, "violetas.png");
LADYBUG = os.path.join(MUSEUMCAMPO, "ladybug.png");
PLANTACION = os.path.join(MUSEUMCAMPO, "plantacion.png");
PAJARO = os.path.join(MUSEUMCAMPO, "pajaro.png");
MARIPOSA = os.path.join(MUSEUMCAMPO, "mariposa.png");
ARBOL = os.path.join(MUSEUMCAMPO, "arbol.png");
GIRASOLES = os.path.join(MUSEUMCAMPO, "girasoles.png");
#--------------CIUDAD-------------------#
MUSEUMBACKGROUNDCIUDAD = os.path.join(MUSEUMCIUDAD, "ciudad_fondo.png");
LINEAS = os.path.join(MUSEUMCIUDAD, "lineas.png");
BANCO = os.path.join(MUSEUMCIUDAD, "banco.png");
FLORES = os.path.join(MUSEUMCIUDAD, "flores.png");
PASTO = os.path.join(MUSEUMCIUDAD, "pasto.png");
AUTO = os.path.join(MUSEUMCIUDAD, "auto.png");
HIDRANTE = os.path.join(MUSEUMCIUDAD, "hidrante.png");
SEMAFORO = os.path.join(MUSEUMCIUDAD, "semaforo.png");
ARBOLCITY = os.path.join(MUSEUMCIUDAD, "arbol.png");
SOLCITY = os.path.join(MUSEUMCIUDAD, "sol.png");
CASA = os.path.join(MUSEUMCIUDAD, "casa.png");
TECHO = os.path.join(MUSEUMCIUDAD, "techo.png");
VENTANAS = os.path.join(MUSEUMCIUDAD, "ventanas.png");

MUSEUMBACKGROUNDMOUNT = os.path.join(MUSEUMMOUNT, "montana_fondo.png");
PLANTAMOUNT = os.path.join(MUSEUMMOUNT, "planta.png");
SNOWBOARD = os.path.join(MUSEUMMOUNT, "snowboard.png");
GORRA = os.path.join(MUSEUMMOUNT, "gorra.png");
ZANAHORIAMOUNT = os.path.join(MUSEUMMOUNT, "zanahoria.png");
BUFANDA = os.path.join(MUSEUMMOUNT, "bufanda.png");
TRINEO = os.path.join(MUSEUMMOUNT, "trineo.png");
CERCA = os.path.join(MUSEUMMOUNT, "cerca.png");
GUANTE = os.path.join(MUSEUMMOUNT, "guante.png");
PINOS = os.path.join(MUSEUMMOUNT, "pinos.png");
TECHOMOUNT = os.path.join(MUSEUMMOUNT, "techo.png");
AVION = os.path.join(MUSEUMMOUNT, "avion.png");
CABLECAR = os.path.join(MUSEUMMOUNT, "cablecar.png");

MUSEUMBACKGROUNDLAKE = os.path.join(MUSEUMLAKE, "lago_fondo.png");
TORTUGA = os.path.join(MUSEUMLAKE, "tortuga.png");
PEZ = os.path.join(MUSEUMLAKE, "pez.png");
BOLSA = os.path.join(MUSEUMLAKE, "bolsa.png");
BANANAS = os.path.join(MUSEUMLAKE, "bananas.png");
MANTEL = os.path.join(MUSEUMLAKE, "mantel.png");
JUNCOS = os.path.join(MUSEUMLAKE, "juncos.png");
MUELLE = os.path.join(MUSEUMLAKE, "muelle.png");
BOTE = os.path.join(MUSEUMLAKE, "bote.png");
PLANTASFLOTANTES = os.path.join(MUSEUMLAKE, "plantas_flotantes.png");
COMETA = os.path.join(MUSEUMLAKE, "cometa.png");
GLOBO = os.path.join(MUSEUMLAKE, "globo.png");
CASALAKE = os.path.join(MUSEUMLAKE, "casa.png");
#------------------Circus-----------------------------#
CIRCUSBACKGROUND = os.path.join(CIRCUS, "circus_background.png");
CIRCUSBACKGROUNDCOUNT = os.path.join(CIRCUS, "circus_background_count.png");
SUMTIGERS = os.path.join(CIRCUS, "sum_tigre.png");
SUMELEPHANTS = os.path.join(CIRCUS, "sum_elefante.png");
SUMZEBRAS = os.path.join(CIRCUS, "sum_cebra.png");
SUMLIONS = os.path.join(CIRCUS, "sum_leon.png");
ELEPHANTS = os.path.join(CIRCUS, "elephantSheet.png");
LIONS = os.path.join(CIRCUS, "lionSheet.png");
TIGERS = os.path.join(CIRCUS, "tigerSheet.png");
ZEBRAS = os.path.join(CIRCUS, "zebraSheet.png");
MATHSIGNS = os.path.join(CIRCUS, "mathSigns.png");
MAS = os.path.join(CIRCUS, "mas.png");
MENOS = os.path.join(CIRCUS, "menos.png");
CHECKBTN = os.path.join(CIRCUS, "checkBtn.png");
STAFF = os.path.join(CIRCUS, "staff.png");
#-------------------Farm-------------------------------#
FARMBACKGROUND = os.path.join(FARM, "farm_background.png");
SMALLOBJECTS = os.path.join(FARM, "smallObjects.png");
BIGOBJECTS = os.path.join(FARM, "bigObjects.png");
DIALOGO = os.path.join(FARM, "dialogo.png");
COWHEAD = os.path.join(FARM, "cowHead.png");
COWTAIL = os.path.join(FARM, "cowTail.png");
CHICKEN = os.path.join(FARM, "chicken.png");
BARRADOWNFARM = os.path.join(FARM, "barra_down_granja.png");
BARRAUPFARM = os.path.join(FARM, "barra_up_granja.png");
#---------------------Distractor-----------------------#
DISTRACTORBACKGROUND = os.path.join(DISTRACTOR, "distractorBackground.png");
CARDSHEET = os.path.join(DISTRACTOR, "cards.png");

#------------------------Intervals -------------------------#
GARDENINTERVAL = os.path.join(INTERVALS, "garden_interval.png");
GARDENINTERVALSIGNS = os.path.join(INTERVALS, "garden_interval_signs.png");
CIRCOINTERVAL = os.path.join(INTERVALS, "circo_interval.png");
CIRCOCRATES = os.path.join(INTERVALS, "circo_crates.png");
MUSEUMINTERVAL = os.path.join(INTERVALS, "museum_interval.png");
MUSEUMTREE = os.path.join(INTERVALS, "museum_tree.png");
FARMINTERVAL = os.path.join(INTERVALS, "farm_interval.png");
FARMSIGN = os.path.join(INTERVALS, "farm_sign.png");
DISTRACTORINTERVAL = os.path.join(INTERVALS, "distractor_interval.png");
DISTRACTORSIGN = os.path.join(INTERVALS, "distractor_sign.png");
NEIGHBOURSHEET = os.path.join(INTERVALS, "neighbours.png");
DIALOGOINTERVAL = os.path.join(INTERVALS, "dialogo_interval.png");
#----------------- Mouse cursor ---------------------#
MOUSE = os.path.join(IMAGES, "puntero.png");  
BRUSHSHEET = os.path.join(MUSEUM, "pinceles.png");      
#---------------------------------------------------- #

LOADING = os.path.join(IMAGES, "loading.png");
#---------------- Tutorials---------------------------#
TOWNTUTO = os.path.join(TUTORIALS, "townTuto.png");
PETMESSAGE = os.path.join(TUTORIALS, "petMessage.png");
GRANJATUTO = os.path.join(TUTORIALS, "farmTuto.png");
GARDENTUTO = os.path.join(TUTORIALS, "gardenTuto.png");
CIRCUSCONTUTO = os.path.join(TUTORIALS, "circusContTuto.png");
CIRCUSSUMTUTO = os.path.join(TUTORIALS, "circusSumTuto.png");
CIRCUSRESTUTO = os.path.join(TUTORIALS, "circusResTuto.png");
MUSEUMTUTO = os.path.join(TUTORIALS, "museumTuto.png");
INTERVALTUTO = os.path.join(TUTORIALS, "intervalTuto.png");
DISTRACTORTUTO = os.path.join(TUTORIALS, " distractorTuto.png");
FARMTUTO = os.path.join(TUTORIALS, "farmTuto.png");

pygame.init();

# --------------------------------------------------------------------------
# Pantalla completa "de verdad" sin depender de que el monitor soporte
# exactamente 1200x900 como modo de video (muchos monitores modernos no lo
# soportan y pygame tira "No video mode large enough").
#
# Truco: "display" sigue siendo una superficie de 1200x900 (el tamano para
# el que esta hecho todo el arte del juego), pero NO es la pantalla real.
# Es un lienzo virtual. La pantalla real se abre en fullscreen a la
# resolucion nativa del monitor, y cada vez que el juego llama a
# pygame.display.flip() o pygame.display.update() (llamadas que estan
# repartidas por todo el codigo de los estados del juego), en vez de
# mostrar directamente, escalamos ese lienzo virtual a la pantalla real
# (dejando franjas negras arriba/abajo o a los costados si la relacion de
# aspecto no coincide, en vez de romper o deformar el arte) y recien ahi
# se hace el flip real.
# --------------------------------------------------------------------------
try:
    _realScreen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN);
except pygame.error:
    # Por las dudas, si ni siquiera el fullscreen nativo funciona, caemos
    # a modo ventana con el tamano propio del juego.
    _realScreen = pygame.display.set_mode(RES);

display = pygame.Surface(RES);

def _scaledRectAndSize():
    screenW, screenH = _realScreen.get_size();
    gameW, gameH = RES;
    scale = min(float(screenW) / gameW, float(screenH) / gameH);
    newW, newH = int(gameW * scale), int(gameH * scale);
    x, y = (screenW - newW) // 2, (screenH - newH) // 2;
    return (x, y, newW, newH);

_origFlip = pygame.display.flip;
_origUpdate = pygame.display.update;
_origGetPos = pygame.mouse.get_pos;
_scaleInfo = [0, 0, RES[0], RES[1]];  # x, y, scaledW, scaledH (se actualiza en cada flip)

def _scaledFlip():
    x, y, newW, newH = _scaledRectAndSize();
    _scaleInfo[0], _scaleInfo[1], _scaleInfo[2], _scaleInfo[3] = x, y, newW, newH;
    _realScreen.fill((0, 0, 0));
    scaled = pygame.transform.smoothscale(display, (newW, newH));
    _realScreen.blit(scaled, (x, y));
    _origFlip();

def _scaledUpdate(*args, **kwargs):
    # Los rects parciales estan calculados sobre el lienzo virtual de
    # 1200x900, asi que lo mas simple y seguro es siempre re-escalar y
    # redibujar todo el frame en la pantalla real.
    _scaledFlip();

def _scaledGetPos():
    # Todo el juego (botones, cursor propio, clicks) espera coordenadas
    # dentro del lienzo virtual de 1200x900. Como la pantalla real puede
    # tener otro tamano/relacion de aspecto, traducimos la posicion real
    # del mouse a la posicion equivalente dentro del lienzo virtual,
    # dejandola pegada a los bordes (clamp) si el mouse esta sobre alguna
    # de las franjas negras del letterbox.
    realX, realY = _origGetPos();
    x, y, scaledW, scaledH = _scaleInfo;
    if scaledW == 0 or scaledH == 0:
        return (0, 0);
    scale = float(scaledW) / RES[0];
    virtualX = (realX - x) / scale;
    virtualY = (realY - y) / scale;
    virtualX = max(0, min(RES[0] - 1, int(virtualX)));
    virtualY = max(0, min(RES[1] - 1, int(virtualY)));
    return (virtualX, virtualY);

pygame.display.flip = _scaledFlip;
pygame.display.update = _scaledUpdate;
pygame.mouse.get_pos = _scaledGetPos;
#--------------Background Imgs loaded-------------------#
transparency = pygame.Surface.convert_alpha(pygame.image.load(TRANSPARENCY));
pauseInGameBck = pygame.image.load(PAUSEINGAMEBCK).convert();
mainMenu = pygame.image.load(MAINMENU).convert();
townMap = pygame.image.load(TOWN).convert();
museumBackground = pygame.image.load(MUSEUMBACKGROUND).convert();
museumBackgroundBeach = pygame.image.load(MUSEUMBACKGROUNDBEACH).convert();
museumBackgroundCampo = pygame.image.load(MUSEUMBACKGROUNDCAMPO).convert();
museumBackgroundCiudad = pygame.image.load(MUSEUMBACKGROUNDCIUDAD).convert();
museumBackgroundMountain = pygame.image.load(MUSEUMBACKGROUNDMOUNT).convert();
museumBackgroundLake = pygame.image.load(MUSEUMBACKGROUNDLAKE).convert();
circusBackground = pygame.image.load(CIRCUSBACKGROUND).convert();
circusBackgroundCount = pygame.image.load(CIRCUSBACKGROUNDCOUNT).convert();
farmBackground = pygame.image.load(FARMBACKGROUND).convert();
gardenInterval = pygame.image.load(GARDENINTERVAL).convert();
circoInterval = pygame.image.load(CIRCOINTERVAL).convert();
museumInterval = pygame.image.load(MUSEUMINTERVAL).convert();
distractorInterval = pygame.image.load(DISTRACTORINTERVAL).convert();
farmInterval = pygame.image.load(FARMINTERVAL).convert();
Difficulties = pygame.image.load(DIFFICULTYBACK).convert();
playerSelection = pygame.image.load(PLAYERSELECTBACK).convert();
loading = pygame.image.load(LOADING).convert();
distractorBackground = pygame.image.load(DISTRACTORBACKGROUND).convert();
albumCover = pygame.image.load(ALBUMCOVER).convert();
albumPageOne = pygame.image.load(ALBUMPAGEONE).convert();
albumPageTwo = pygame.image.load(ALBUMPAGETWO).convert();      

      
        