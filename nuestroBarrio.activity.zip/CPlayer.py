'''
Created on 14/03/2013

@author: Gus
'''
import pygame;
from api.CGame import cGame;
import Assets.Assets as A; 
from api.CSpriteStripAnim import SpriteStripAnim;
import math;

class Player(pygame.sprite.Sprite):
    def __init__(self, cMap, start):
        pygame.sprite.Sprite.__init__(self);
        #self.image =  pygame.Surface.convert_alpha(pygame.image.load(A.PLAYER));
        #self.rect = self.image.get_rect();           
        self.isDead = False;
        self.auto = False;
        self.map = cMap;
        self.PLAYER_WIDTH = 115;
        self.PLAYER_HEIGHT = 95;
        self.velx = 7;
        self.vely = 7;
        self.STANDING = 0;
        self.WALKUP = 1;
        self.WALKDOWN = 2;
        self.WALKLEFT = 3;
        self.WALKRIGHT = 4;
        self.startX = start[0];
        self.startY = start[1];
        self.leftPressed = False;
        self.rightPressed = False;
        self.upPressed = False;
        self.downPressed = False;
        
        #----------Data for the sprite sheet---------#
        FPS = 120
        frames = FPS / 30
        if(cGame.inst().cProgressSave.characterSelected == 0):
            self.goDown = SpriteStripAnim(A.PLAYERSSPRITES, (0, 0, 115, 95), 4, (0,0,0), True, frames);
            self.goUp = SpriteStripAnim(A.PLAYERSSPRITES, (460, 0, 115, 95), 4, (0,0,0), True, frames);
            self.goRight = SpriteStripAnim(A.PLAYERSSPRITES, (920, 0, 115, 95), 4, (0,0,0), True, frames);
            self.goLeft = SpriteStripAnim(A.PLAYERSSPRITES, (1380, 0, 115, 95), 4, (0,0,0), True, frames);
            
        elif(cGame.inst().cProgressSave.characterSelected == 1):
            self.goDown = SpriteStripAnim(A.PLAYERSSPRITES, (0, 95, 115, 95), 4, (0,0,0), True, frames);
            self.goUp = SpriteStripAnim(A.PLAYERSSPRITES, (460, 95, 115, 95), 4, (0,0,0), True, frames);
            self.goRight = SpriteStripAnim(A.PLAYERSSPRITES, (920, 95, 115, 95), 4, (0,0,0), True, frames);
            self.goLeft = SpriteStripAnim(A.PLAYERSSPRITES, (1380, 95, 115, 95), 4, (0,0,0), True, frames);
            
        elif(cGame.inst().cProgressSave.characterSelected == 2):
            self.goDown = SpriteStripAnim(A.PLAYERSSPRITES, (0, 190, 115, 95), 4, (0,0,0), True, frames);
            self.goUp = SpriteStripAnim(A.PLAYERSSPRITES, (460, 190, 115, 95), 4, (0,0,0), True, frames);
            self.goRight = SpriteStripAnim(A.PLAYERSSPRITES, (920, 190, 115, 95), 4, (0,0,0), True, frames);
            self.goLeft = SpriteStripAnim(A.PLAYERSSPRITES, (1380, 190, 115, 95), 4, (0,0,0), True, frames);
            
        elif(cGame.inst().cProgressSave.characterSelected == 3):
            self.goDown = SpriteStripAnim(A.PLAYERSSPRITES, (0, 285, 115, 95), 4, (0,0,0), True, frames);
            self.goUp = SpriteStripAnim(A.PLAYERSSPRITES, (460, 285, 115, 95), 4, (0,0,0), True, frames);
            self.goRight = SpriteStripAnim(A.PLAYERSSPRITES, (920, 285, 115, 95), 4, (0,0,0), True, frames);
            self.goLeft = SpriteStripAnim(A.PLAYERSSPRITES, (1380, 285, 115, 95), 4, (0,0,0), True, frames); 
         
        elif(cGame.inst().cProgressSave.characterSelected == 4):
            
            self.goDown = SpriteStripAnim(A.PLAYERSSPRITES, (0, 380, 115, 95), 4, (0,0,0), True, frames);
            self.goUp = SpriteStripAnim(A.PLAYERSSPRITES, (460, 380, 115, 95), 4, (0,0,0), True, frames);
            self.goRight = SpriteStripAnim(A.PLAYERSSPRITES, (920, 380, 115, 95), 4, (0,0,0), True, frames);
            self.goLeft = SpriteStripAnim(A.PLAYERSSPRITES, (1380, 380, 115, 95), 4, (0,0,0), True, frames);
                     
        elif(cGame.inst().cProgressSave.characterSelected == 5):
            self.goDown = SpriteStripAnim(A.PLAYERSSPRITES, (0, 475, 115, 95), 4, (0,0,0), True, frames);
            self.goUp = SpriteStripAnim(A.PLAYERSSPRITES, (460, 475, 115, 95), 4, (0,0,0), True, frames);
            self.goRight = SpriteStripAnim(A.PLAYERSSPRITES, (920, 475, 115, 95), 4, (0,0,0), True, frames);
            self.goLeft = SpriteStripAnim(A.PLAYERSSPRITES, (1380, 475, 115, 95), 4, (0,0,0), True, frames);
                
        self.walkUp = [ self.goUp ];
        self.walkDown = [ self.goDown ];
        self.walkRight = [ self.goRight ];
        self.walkLeft = [ self.goLeft ];
        self.n = 0;
        self.image = self.walkDown[self.n].next();
        self.rect = self.image.get_rect();
        self.rect.centerx = self.startX;
        self.rect.centery = self.startY;
        self.setState(self.STANDING);
        self.checkCollisions();
        self.keyPressed = False;
        #--------------------------------------------#

    def update(self):
        if(self.auto != True):
            eventos_republicar= [];
            for event in pygame.event.get(pygame.KEYDOWN):
                    if(event.key == pygame.K_LEFT):
                        self.leftPressed = True;
                        self.keyPressed = True;
                        if(self.mState != self.WALKLEFT):
                            self.setState(self.WALKLEFT);
                                             
                    elif(event.key == pygame.K_RIGHT):
                        self.rightPressed = True;
                        self.keyPressed = True;
                        if(self.mState != self.WALKRIGHT):
                            self.setState(self.WALKRIGHT);
                        
                    elif(event.key == pygame.K_UP):
                        self.upPressed = True;
                        self.keyPressed = True;
                        if(self.mState != self.WALKUP):
                            self.setState(self.WALKUP);
                            
                    elif(event.key == pygame.K_DOWN):
                        self.downPressed = True;
                        self.keyPressed = True;
                        if(self.mState != self.WALKDOWN):
                            self.setState(self.WALKDOWN);
            #---------------- Republish events -----------------------#
                    if event.key == pygame.K_ESCAPE:
                        if not event in eventos_republicar: eventos_republicar.append(event);
                        continue
                    elif event.key == pygame.K_SPACE:
                        if not event in eventos_republicar: eventos_republicar.append(event);
                        continue
                    
                    elif event.key == pygame.K_0:
                        if not event in eventos_republicar: eventos_republicar.append(event);
                        continue
                    elif event.key == pygame.K_1:
                        if not event in eventos_republicar: eventos_republicar.append(event);
                        continue
                    
                    elif event.key == pygame.K_LEFT:
                        if not event in eventos_republicar: eventos_republicar.append(event);
                        continue                
                    elif event.key == pygame.K_UP:
                        if not event in eventos_republicar: eventos_republicar.append(event);
                        continue
                    elif event.key == pygame.K_DOWN:
                        if not event in eventos_republicar: eventos_republicar.append(event);
                        continue
                    elif event.key == pygame.K_RIGHT:
                        if not event in eventos_republicar: eventos_republicar.append(event);
                        continue
                    else:
                        continue
                    
            for event in eventos_republicar:
                pygame.event.post(event);
              
            if(pygame.key.get_pressed()[pygame.K_RIGHT] == False and pygame.key.get_pressed()[pygame.K_LEFT] == False
               and pygame.key.get_pressed()[pygame.K_UP] == False and pygame.key.get_pressed()[pygame.K_DOWN] == False):
                if(self.mState != self.STANDING):
                    self.checkCollisions();
                    self.setState(self.STANDING);
            
            self.getState();
        #---------------------------------------------------------#            
    def setState(self, aState):
        self.mState = aState;
    
    def getState(self):
        if(self.mState == self.WALKLEFT):
            self.rect.centerx -= self.velx;
            self.image = self.walkLeft[self.n].next();
        elif(self.mState == self.WALKRIGHT):
            self.rect.centerx += self.velx;
            self.image = self.walkRight[self.n].next();
        elif(self.mState == self.WALKDOWN):
            self.rect.centery += self.vely;
            self.image = self.walkDown[self.n].next();
        elif(self.mState == self.WALKUP):
            self.rect.centery -= self.vely;
            self.image = self.walkUp[self.n].next();
        elif(self.mState == self.STANDING):
            self.leftPressed = False;
            self.rightPressed = False;
            self.upPressed = False;
            self.downPressed = False;
            self.n = 0;
            self.image = self.walkDown[self.n].first();
        self.checkCollisions();
        #---------------- Player Level Boundaries-----------------# 
        if(self.map.mapName == "town"):
                
            if((self.rect.centerx - 35) <= 0):
                self.rect.centerx = 35;
            if ((self.rect.centery - 45) <=0):
                self.rect.centery = 45; 
            if ((self.rect.centerx + 35) >= 1200):
                self.rect.centerx = 1200 - 35;
            if ((self.rect.centery + 35) >= 900):
                self.rect.centery = 900 - 35;

        elif(self.map.mapName == "garden"):
            if((self.rect.centerx - 35) <= 0):
                self.rect.centerx = 35;
            if ((self.rect.centery - 45) <=0):
                self.rect.centery = 45; 
            if ((self.rect.centery + 35) >= 900):
                self.rect.centery = 900 - 35;
        elif(self.map.mapName == "farm"):
            if((self.rect.centerx - 35) <= 0):
                self.rect.centerx = 35;
            if ((self.rect.centerx + 35) >= 1200):
                self.rect.centerx = 1200 - 35;
        elif(self.map.mapName == "interval" and self.map.distractorEnded):
            if ((self.rect.centerx + 35) >= 1200):
                self.rect.centerx = 1200 - 35;
            #---------------------------------------------------------#
                
    def checkCollisions(self):
        self.downY = int(math.floor((self.rect.centery + self.PLAYER_HEIGHT / 2 ) / self.map.TILE_HEIGHT));  
        self.upY = int(math.floor((self.rect.centery + self.PLAYER_HEIGHT / 2 - 20)  / self.map.TILE_HEIGHT));
        self.leftX = int(math.floor((self.rect.centerx - self.PLAYER_WIDTH / 10) / self.map.TILE_WIDTH));
        self.rightX = int(math.floor((self.rect.centerx + self.PLAYER_WIDTH / 10 ) / self.map.TILE_WIDTH));
        self.centerX = int(math.floor(self.rect.centerx / self.map.TILE_WIDTH));
        self.centerY = int(math.floor(self.rect.centery / self.map.TILE_HEIGHT));
        self.qtrDown = int(math.floor((self.rect.centery + (self.PLAYER_HEIGHT / 2 - 10)) /self.map.TILE_HEIGHT));
        self.qtrUp = int(math.floor((self.rect.centery + self.PLAYER_HEIGHT/ 2 - 10 ) / self.map.TILE_HEIGHT));

        self.down1 = int(self.map.getTileIndex(self.rightX, self.downY));
        self.down2 = int(self.map.getTileIndex(self.centerX, self.downY));
        self.down3 = int(self.map.getTileIndex( self.leftX, self.downY));
        
        self.up1 = int(self.map.getTileIndex( self.centerX, self.upY));
        self.up2 = int(self.map.getTileIndex( self.leftX, self.upY));
        self.up3 = int(self.map.getTileIndex( self.rightX, self.upY));
        
        self.left1 = int(self.map.getTileIndex( self.leftX, self.qtrDown));
#        self.left2 = int(self.map.getTileIndex(self.leftX, self.centerY));
        self.left3 = int(self.map.getTileIndex( self.leftX, self.qtrUp));
        
#        self.right1 = int(self.map.getTileIndex(self.rightX, self.centerY));
        self.right2 = int(self.map.getTileIndex(self.rightX, self.qtrDown));
        self.right3 = int(self.map.getTileIndex(self.rightX, self.qtrUp));
        
        
        if(self.mState == self.WALKLEFT):
            if( self.left1 == self.map.TILE_WALL or self.left3 == self.map.TILE_WALL):
                self.rect.centerx = ((self.leftX * self.map.TILE_WIDTH) + self.map.TILE_WIDTH + self.PLAYER_WIDTH / 10 + 1);

        elif(self.mState == self.WALKRIGHT):
            if ( self.right2 == self.map.TILE_WALL or self.right3 == self.map.TILE_WALL):
                self.rect.centerx = (self.rightX * self.map.TILE_WIDTH - self.PLAYER_WIDTH / 10 - 1);
        
        elif(self.mState == self.WALKUP):
            if (self.up1 == self.map.TILE_WALL or self.up2 == self.map.TILE_WALL ):
                self.rect.centery = ((self.upY * self.map.TILE_HEIGHT) + self.map.TILE_HEIGHT - (self.PLAYER_HEIGHT / 2 - 25)  );
            
        elif(self.mState == self.WALKDOWN):
            if(self.down2 == self.map.TILE_WALL or self.down1 == self.map.TILE_WALL or self.down3 == self.map.TILE_WALL):
                self.rect.centery = (self.downY * self.map.TILE_HEIGHT - self.PLAYER_HEIGHT / 2 );  
    
    def setVel(self, newVelX, newVelY):
        self.velx = newVelX;
        self.vely = newVelY;
        
    def destroy(self):
        self.isDead = None;
        self.auto = None;
        self.PLAYER_HEIGHT = None;
        self.PLAYER_WIDTH = None;
        self.velx = None;
        self.vely = None;
        self.STANDING = None;
        self.WALKDOWN = None;
        self.WALKLEFT = None;
        self.WALKRIGHT = None;
        self.WALKUP = None;
        self.walkDown = None;
        self.walkLeft = None;
        self.walkRight = None;
        self.walkUp = None;
        self.goDown = None;
        self.goUp = None;
        self.goLeft = None;
        self.goRight = None
        self.n = None;
        self.image = None;
        self.rect = None;
        self.startX = None;
        self.startY = None;
        self.leftPressed = None;
        self.rightPressed = None;
        self.upPressed = None;
        self.downPressed = None;
        self.keyPressed = None;
        