'''
Created on 02/04/2013

@author: Gus
'''

from api.CSpriteSheet import spritesheet;
import Assets.Assets as A; 
import pygame;


class cBust(pygame.sprite.DirtySprite):
        
    def __init__(self, aX, aY, aType, aLevelType):
        pygame.sprite.Sprite.__init__(self);
        self.isDead = False;
        self.mType = aType;
        self.mLevelType = aLevelType;
        if(self.mType != "pet"):
            self.bustSheet = spritesheet(A.BUSTSHEET);
            self.bustList = self.bustSheet.load_strip((0, 0, 200, 200), 4, colorkey = (0,0,0));
            
            if(self.mType == "farm"):
                self.image = self.bustList[0];
            elif(self.mType == "museum"):
                self.image = self.bustList[1];
            elif(self.mType == "garden"):
                self.image = self.bustList[2];
            elif(self.mType == "circus"):
                self.image = self.bustList[3];
            
        else:
            self.rectangle = pygame.Surface((0,0));
            self.image = self.rectangle;
            
        self.rect = self.image.get_rect();
        self.rect.topleft = (aX + (200 * 2.6), aY + 250); 
    
    def setCords(self, x, y):
        self.rect.topleft = x,y
        
    def destroy(self):
        
        self.mLevelType.allSprites.remove(self);