'''
Created on 20/05/2013

@author: Gus
'''
from api.CSpriteStripAnim import SpriteStripAnim;
import Assets.Assets as A;
import pygame;

class museumButton(pygame.sprite.DirtySprite):
    def __init__(self, color, position, aBrush):
        pygame.sprite.DirtySprite.__init__(self);
        self.n = 0;
        self.FPS = 30;
        self.mBrush = aBrush
        self.stateAnim = "";
        self.state = "static";
        self.color = color;
        self.justPressed = False;
        if(color == self.mBrush.EMPTY):
            self.frames = self.FPS / 5;
        else:
            self.frames = self.FPS / 3;
        
        if(color == self.mBrush.RED):
            self.redAnim = SpriteStripAnim(A.PAINTSHEET, (0, 0, 220, 200), 2, (0,0,0), True, self.frames);
            self.red = [self.redAnim];
            self.image = self.red[self.n].first();
        elif(color == self.mBrush.YELLOW):
            self.yellowAnim = SpriteStripAnim(A.PAINTSHEET, (440, 0, 220, 200), 2, (0,0,0), True, self.frames);
            self.yellow = [self.yellowAnim];
            self.image = self.yellow[self.n].first();
        elif(color == self.mBrush.BLUE):
            self.blueAnim = SpriteStripAnim(A.PAINTSHEET, (880, 0, 220, 200), 2, (0,0,0), True, self.frames);
            self.blue = [self.blueAnim];
            self.image = self.blue[self.n].first();
        elif(color == self.mBrush.EMPTY):
            self.waterAnim = SpriteStripAnim(A.BUCKETSHEET, (0, 0, 265, 285), 5, (0,0,0), True, self.frames);
            self.water = [self.waterAnim];
            self.image = self.water[self.n].first();
            
        self.rect = self.image.get_rect();
        self.image = self.image.convert();
        self.rect.topleft = position;
            

    def update(self):
        if(self.justPressed):
            #empty brush
            if(self.mBrush.paint == self.mBrush.EMPTY):
                self.mBrush.changeColor(self.color);
            #red Brush
            elif(self.mBrush.paint == self.mBrush.RED):
                if(self.color == self.mBrush.BLUE):
                    self.mBrush.changeColor(self.mBrush.PURPLE);
                elif(self.color == self.mBrush.YELLOW):
                    self.mBrush.changeColor(self.mBrush.ORANGE);
            #Yellow Brush        
            elif(self.mBrush.paint == self.mBrush.YELLOW):
                if(self.color == self.mBrush.RED):
                    self.mBrush.changeColor(self.mBrush.ORANGE);
                elif(self.color == self.mBrush.BLUE):
                    self.mBrush.changeColor(self.mBrush.GREEN);
            #Blue Brush        
            elif(self.mBrush.paint == self.mBrush.BLUE):
                if(self.color == self.mBrush.RED):
                    self.mBrush.changeColor(self.mBrush.PURPLE);
                elif(self.color == self.mBrush.YELLOW):
                    self.mBrush.changeColor(self.mBrush.GREEN);
            
            self.state = "anim";
            self.justPressed = False;
            if(self.mBrush.paint != self.mBrush.EMPTY and self.color == self.mBrush.EMPTY):
                self.mBrush.changeColor(self.color);
        
        if(self.state == "anim"):
            if(self.color == self.mBrush.RED):
                self.image = self.red[self.n].next();
                if(self.redAnim.oneLoop):
                    self.redAnim.oneLoop = False;
                    self.state = "static";
            elif(self.color == self.mBrush.YELLOW):
                self.image = self.yellow[self.n].next();
                if(self.yellowAnim.oneLoop):
                    self.yellowAnim.oneLoop = False;
                    self.state = "static";
            elif(self.color == self.mBrush.BLUE):
                self.image = self.blue[self.n].next();
                if(self.blueAnim.oneLoop):
                    self.blueAnim.oneLoop = False;
                    self.state = "static";
            elif(self.color == self.mBrush.EMPTY):
                self.image = self.water[self.n].next();
                if(self.waterAnim.oneLoop):
                    self.waterAnim.oneLoop = False;
                    self.state = "static";         
                    
    def pressed(self):
        self.mousePos = pygame.mouse.get_pos();
        if self.mousePos[0] > self.rect.topleft[0]:
            if self.mousePos[1] > self.rect.topleft[1]:
                if self.mousePos[0] < self.rect.topleft[0] + self.rect[2]:
                    if self.mousePos[1] < self.rect.topleft[1] + self.rect[3]:
                        return True
                    else: return False
                else: return False
            else: return False
        else: return False
        pass
    
    def animState(self, aType):
        self.mType = aType;
        if (self.getState() == "anim"):
            self.image = self.mType[self.n].next();
    def destroy(self):
        if(self.color == self.mBrush.RED):
            self.redAnim = None;
            self.red = None;
        elif(self.color == self.mBrush.YELLOW):
            self.yellowAnim = None;
            self.yellow = None;
        elif(self.color == self.mBrush.BLUE):
            self.blueAnim = None;
            self.blue = None;
        elif(self.color == self.mBrush.EMPTY):
            self.waterAnim = None;
            self.water = None;
        self.image = None;
#-----------------------------------------