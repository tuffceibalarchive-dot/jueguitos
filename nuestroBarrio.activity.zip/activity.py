#!/usr/bin/python
# -*- coding: iso-8859-1 -*-

##import sys
##import os
##import zipfile
##import pygtk
##import gtk
##import pango
##from olpcgames import activity
##from gettext import gettext as _
##import gtk
##from sugar.activity import activity
##from sugar.graphics import style
##from main import *
from sugar.activity.activity import ActivityToolbox, ActivityToolbar
from olpcgames import activity
from gettext import gettext as _
import gtk



class Activity(activity.PyGameActivity):

    game_name = 'main'
    game_title = _('Nuestro Barrio')
    game_size = None
    #def __init__(self,handle):
     #   super(Activity, self).__init__(handle)
      #  init()
