'''
Created on 23/05/2013

@author: Gus
'''
import pygame;
from api.CSpriteStripAnim import SpriteStripAnim;

class museumObject(pygame.sprite.DirtySprite):
    '''
    classdocs
    '''

    def __init__(self, imgName, x, y, width, height, isButton, aColor, aBrush):
        pygame.sprite.DirtySprite.__init__(self);
        self.n = 0;
        self.FPS = 30;
        self.frames = self.FPS / 3;
        self.isButton = isButton;
        self.mColor = aColor;
        self.painted = False;
        self.mBrush = aBrush;
        
        if(self.isButton):
            self.btnSheet = SpriteStripAnim(imgName, (0, 0, width, height), 2, (0,0,0), True, self.frames);
            self.btnAnim = [self.btnSheet];
            self.image = self.btnAnim[self.n].last();
            
        else:
            self.image =  pygame.Surface.convert_alpha(pygame.image.load(imgName));
            
        self.rect = self.image.get_rect();        
        self.setCords((x, y));
        
    def setCords(self, coords):
        """coords is a tuple with the format (x, y)"""
        self.rect.topleft = coords;


    def pressed(self):
        self.mousePos = pygame.mouse.get_pos();
        if self.mousePos[0] > self.rect.topleft[0]:
            if self.mousePos[1] > self.rect.topleft[1]:
                if self.mousePos[0] < self.rect.topleft[0] + self.rect[2]:
                    if self.mousePos[1] < self.rect.topleft[1] + self.rect[3]:
                        return True
                    else: return False
                else: return False
            else: return False
        else: return False
        pass
    
    def update(self):
        if(self.isButton):
            if(self.painted):
                self.image = self.btnAnim[self.n].first();

    
    def destroy(self):
        if(self.isButton):
            self.btnSheet = None;
            self.btnAnim = None;
        self.image = None;
        
    def checkPaint(self):
        if(self.mBrush.paint == self.mColor):
            self.painted = True;

        