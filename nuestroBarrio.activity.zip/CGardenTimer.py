'''
Created on 04/04/2013

@author: Gus
'''
import Assets.Assets as A;
import pygame;

class cGardenTimer(pygame.sprite.Sprite):
    '''
    classdocs
    '''

    
    def __init__(self, aGardenSprites, aDifficulty, gameType):
        '''
        Constructor
        '''
        self.isDead = False;
        pygame.sprite.Sprite.__init__(self);
        self.mDifficulty = aDifficulty;
        self.gameType = gameType;
        self.mGardenSprites = aGardenSprites;
        if(self.gameType.name == "garden"):
            self.image =  pygame.Surface.convert_alpha(pygame.image.load(A.GARDENTIMERDOWN));
        else:
            self.image =  pygame.Surface.convert_alpha(pygame.image.load(A.BARRADOWNFARM));
        self.rect = self.image.get_rect();
        self.setCords(30, 22);
        self.mGardenSprites.add(self);
        
        self.timerCover = cGardenTimerUp(self.mGardenSprites, self.gameType);
        self.timerCover.setCords(0, 15);
        self.mGardenSprites.add(self.timerCover);
        
        if(self.mDifficulty == 1):
            self.timeLimit = 30*60;
        elif(self.mDifficulty == 2):
            self.timeLimit = 30*90;
        elif(self.mDifficulty == 3):
            self.timeLimit = 30*120;  
        self.timer = self.timeLimit;
        self.count = 0;
    def setCords(self,x,y):
        self.rect.topleft = x,y
        
    def update(self):
        self.timer +=1;
        self.timeLimit -=1;
        if(self.timer >= 30):
            if(self.mDifficulty == 1):
                self.rect.right -= 19;
            
            elif(self.mDifficulty ==2):
                self.rect.right -= 13;
                
            elif(self.mDifficulty == 3):
                self.rect.right -= 9;
            self.timer = 0;
            self.count +=1;
            
        
        
    def destroy(self):
        self.gameType = None;
        self.mDifficulty=None;
        self.mGardenSprites.remove(self.timerCover, self);
        self.image = None;
        self.rect = None;
        self.isDead = None;
class cGardenTimerUp(pygame.sprite.Sprite):
     
    def __init__(self, aGardenSprites, gameType):
        pygame.sprite.Sprite.__init__(self);
        self.isDead = False;
        self.gameType = gameType;
        self.mGardenSprites = aGardenSprites;
        if(self.gameType.name == "garden"):
            self.image =  pygame.Surface.convert_alpha(pygame.image.load(A.GARDENTIMERUP));
        else:
            self.image =  pygame.Surface.convert_alpha(pygame.image.load(A.BARRAUPFARM));
        self.rect = self.image.get_rect();
    def setCords(self,x,y):
        self.rect.topleft = x,y

    def destroy(self):
        self.image = None;
        self.rect = None;
        self.gameType = None;
        self.isDead = None;
        