# -*- coding: utf-8 -*-
# Lanzador grafico de Fruitix (Python 2 + Tkinter).
# Guardar como "Fruitix.pyw" junto a "Fruitix.py" y las carpetas
# "data" y "levels". Al ser .pyw, Windows lo abre con pythonw.exe,
# que NO muestra ninguna ventana de consola.

import os
import sys
import subprocess
import Tkinter as tk

# Nos aseguramos de trabajar siempre desde la carpeta del juego,
# sin importar desde donde se haga doble clic.
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(SCRIPT_DIR)


def iniciar_juego():
    try:
        width = int(width_var.get())
        height = int(height_var.get())
    except ValueError:
        width, height = 1200, 825

    args = ["py", "-2", "Fruitix.py"]

    if not fullscreen_var.get():
        args.append("%dx%d" % (width, height))
    else:
        if usar_resolucion_var.get():
            args.append("%dx%d" % (width, height))
        args.append("full")

    # CREATE_NO_WINDOW evita que aparezca una consola al lanzar el proceso hijo.
    creationflags = 0
    if hasattr(subprocess, "CREATE_NO_WINDOW"):
        creationflags = subprocess.CREATE_NO_WINDOW

    subprocess.Popen(args, cwd=SCRIPT_DIR, creationflags=creationflags)
    root.destroy()


def toggle_resolucion():
    state = tk.NORMAL if usar_resolucion_var.get() or not fullscreen_var.get() else tk.DISABLED
    width_entry.config(state=state)
    height_entry.config(state=state)


def toggle_fullscreen():
    if fullscreen_var.get():
        check_resolucion.config(state=tk.NORMAL)
    else:
        check_resolucion.config(state=tk.DISABLED)
    toggle_resolucion()


root = tk.Tk()
root.title(u"Fruitix - Lanzador")
root.resizable(False, False)

pad = {"padx": 10, "pady": 6}

tk.Label(
    root, text=u"Fruitix", font=("Arial", 14, "bold")
).grid(row=0, column=0, columnspan=2, sticky="w", **pad)

tk.Label(root, text=u"Resolución", font=("Arial", 11, "bold")).grid(
    row=1, column=0, columnspan=2, sticky="w", **pad
)

tk.Label(root, text=u"Ancho:").grid(row=2, column=0, sticky="e", **pad)
width_var = tk.StringVar(value="1200")
width_entry = tk.Entry(root, textvariable=width_var, width=8)
width_entry.grid(row=2, column=1, sticky="w", **pad)

tk.Label(root, text=u"Alto:").grid(row=3, column=0, sticky="e", **pad)
height_var = tk.StringVar(value="825")
height_entry = tk.Entry(root, textvariable=height_var, width=8)
height_entry.grid(row=3, column=1, sticky="w", **pad)

fullscreen_var = tk.BooleanVar(value=False)
tk.Checkbutton(
    root, text=u"Pantalla completa", variable=fullscreen_var, command=toggle_fullscreen
).grid(row=4, column=0, columnspan=2, sticky="w", **pad)

usar_resolucion_var = tk.BooleanVar(value=False)
check_resolucion = tk.Checkbutton(
    root,
    text=u"Usar el ancho/alto de arriba en pantalla completa\n(si no, usa la resolución del escritorio)",
    variable=usar_resolucion_var,
    command=toggle_resolucion,
    state=tk.DISABLED,
    justify="left",
)
check_resolucion.grid(row=5, column=0, columnspan=2, sticky="w", **pad)

tk.Label(
    root,
    text=u"Tip: dentro del juego, F11 también\ncambia a pantalla completa.",
    justify="left",
    fg="#555555",
).grid(row=6, column=0, columnspan=2, sticky="w", **pad)

tk.Button(
    root,
    text=u"Iniciar Fruitix",
    command=iniciar_juego,
    font=("Arial", 11, "bold"),
    bg="#4CAF50",
    fg="white",
).grid(row=7, column=0, columnspan=2, sticky="we", padx=10, pady=12)

root.mainloop()
