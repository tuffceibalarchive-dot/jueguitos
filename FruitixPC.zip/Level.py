import os, sys, random
import pygame
from pygame.locals import *
from helpers import *

class Level:
	def __init__(self, gamecore, levelfile, powerupshoes, powerupbasket):
		self.active = 1
		self.winstatus = -1
		self.splashduration = 3000
		self.screen = gamecore.screen
		self.gamecore = gamecore
		self.width, self.height = self.screen.get_size()
		self.background, self.backgroundrect = load_image("UI.png")
		self.vertpadding = self.horizpadding = 10
		self.board, self.boardrect = load_image("board.png")
		self.boardrect.topleft = (self.horizpadding, self.vertpadding)
		self.levelfruit = 0
		self.level = levelfile
		self.leveltime = 0
		self.gamestarted = 0
		self.gamesetup = 1
		self.starttime = self.endtime = 0
		self.trucksoundplay = 0
		self.trucksound = load_sound("truck_drives_in.ogg")
		self.nofruit = load_sound("no_fruit.ogg")
		self.getfruit = load_sound("fruit_pick.ogg")
		self.dropfruit = load_sound("truck_deposit.ogg")
		self.totalfruit = 0
		self.timerunningout = load_sound("timer_warning.ogg")
		self.timeout = load_sound("alarm_final.ogg")
		self.missedfruitallowed = 0
		self.timewarningplayed = 0
		self.fruitimage, self.fruitimagerect = load_image("f_turn_r.png")
		self.LoadLevel()
		self.LoadSprites()
		
		pygame.mixer.music.load(os.path.join("data", "jos_fuc.xm"))
		pygame.mixer.music.play(-1)
		
		if powerupshoes == 1:
			self.xman.changeIntoShoes()
		if powerupbasket == 1:
			self.xman.changeIntoBasket()
		
	def getTotalCollected(self):
		return self.totalfruit
		
	def getRunResult(self):
		return self.winstatus
		
	def LoadMusic(self):
		"""pygame.mixer.music.set_volume(0.60)
		pygame.mixer.music.load(os.path.join("data", "king.mid"))
		pygame.mixer.music.play(10)"""
		return
		
	def LoadLevel(self):
		level = []
		f = open(os.path.join("levels", self.level), "r")
		counter = 0
		stopcount = 0
		for line in f:
			if counter == 0:
				desc, leveltime = line.split(":", 2)
				self.leveltime = int(leveltime.strip()) * 1000
				counter += 1
			elif counter == 1:
				desc, missedallowed = line.split(":", 2)
				self.missedfruitallowed = int(missedallowed.strip())
				counter += 1
			elif counter == 2:
				counter += 1
			else:
				temprow = []
				if stopcount > 15:
					break
				for character in line.strip():
					if character == "@":
						self.levelfruit += 1	
					temprow.append(character)
				level.append(temprow)
				stopcount += 1
		f.close()
		self.levelinfo = level
	def gettimeremaining(self):
		if self.gamesetup == 1:
			return self.leveltime / 1000
		elif self.gamesetup == 2:
			return 0
		else:
			return (self.endtime-pygame.time.get_ticks())/1000
	
	def drawtext(self):
		font = pygame.font.Font(None, 72)
		font.set_bold(True)
		amountremaining = ((self.levelfruit - self.missedfruitallowed)-self.totalfruit)
		if amountremaining < 0:
			amountremaining = 0
		
		inhand = font.render("%i/%i" % (self.xman.fruits, self.xman.maxfruits), 1, (255, 255, 0))
		inhandpos = inhand.get_rect(x = 1070, y = 220)

		truckcount = font.render("%i" % (self.totalfruit), 1, (255, 255, 0))
		truckcountpos = truckcount.get_rect(x = 1095, y = 278)
		
		toget = font.render("%i" % (amountremaining), 1, (255, 255, 0))
		togetpos = toget.get_rect(x = 1055, y = 335)
		
		timeleft = self.gettimeremaining()
		
		timecount = font.render("%s" % (timeleft), 1, (255, 255, 0))
		
		timecountpos = timecount.get_rect(x = 983, y = 608)
		self.screen.blit(truckcount, truckcountpos)
		self.screen.blit(inhand, inhandpos)
		self.screen.blit(toget, togetpos)
		self.screen.blit(timecount, timecountpos)
	
		vertcount = 0
		horizcount = 0
		initialx = 840
		initialy = 405
		xpad = 6
		ypad = 7
		
		for i in range(amountremaining):
			if horizcount > 13:
				horizcount = 0
				vertcount += 1
			if vertcount > 6:
				break

			self.fruitimagerect.left = initialx + (self.fruitimagerect.width+xpad) * horizcount
			self.fruitimagerect.top = initialy + (self.fruitimagerect.height+ypad) * vertcount
			
			self.screen.blit(self.fruitimage, self.fruitimagerect)			
			horizcount += 1
		
		
	def move_check(self):
		colcount = 0		
		lstcols = pygame.sprite.spritecollide(self.xman, self.rock_sprites, False)
		colcount += len(lstcols)
		lstcols = pygame.sprite.spritecollide(self.xman, self.log_sprites, False)
		colcount += len(lstcols)
		if self.xman.rect.left < self.horizpadding:
			colcount += 1
		if self.xman.rect.top < self.vertpadding:
			colcount += 1
		if self.xman.rect.bottom > (800 + self.vertpadding):
			colcount += 1
		if self.xman.rect.right > (800 + self.horizpadding):
			colcount += 1
		return colcount
		
	def Run(self):
		theclock = pygame.time.Clock()
		
		while self.active:
			if self.gamesetup == 1:
				for event in pygame.event.get():
					if self.gamecore.handle_global_event(event):
						continue
					if event.type == pygame.QUIT:
						sys.exit()
					elif event.type == KEYDOWN:
						if (event.key == K_ESCAPE):
							sys.exit()
				if self.trucksoundplay == 0:
					self.trucksound.play()
					self.trucksoundplay = 1
					
				if self.truck.rect.left > 655:
					self.truck.rect.move_ip(-10, 0)
				else:
					self.gamesetup = 0
					self.trucksoundplay = 0
					self.truck.initStayFrames()
					self.starttime = pygame.time.get_ticks()
					self.LoadMusic()
					self.endtime = self.starttime + self.leveltime
			elif self.gettimeremaining() > 0 and self.levelfruit != self.totalfruit:
				
				oldpos = self.xman.rect
				self.xman.movex()
				if self.move_check() > 0:
					self.xman.rect.move_ip(-self.xman.lastx, 0)
				self.xman.movey()
				if self.move_check() > 0:
					self.xman.rect.move_ip(0, -self.xman.lasty)
				if self.gettimeremaining() <= 5:
					if not pygame.mixer.get_busy():
						self.timerunningout.play()
				
				for event in pygame.event.get():
					if self.gamecore.handle_global_event(event):
						continue
					if event.type == pygame.QUIT:
						sys.exit()
					elif event.type == KEYDOWN:
						if (event.key == K_ESCAPE):
							sys.exit()
			elif self.gamesetup == 2:
				for event in pygame.event.get():
					if self.gamecore.handle_global_event(event):
						continue
					if event.type == pygame.QUIT:
						sys.exit()
					elif event.type == KEYDOWN:
						if (event.key == K_ESCAPE):
							sys.exit()
				if self.trucksoundplay == 0:
					self.trucksound.play()
					self.trucksoundplay = 1
				if self.truck.rect.left < 1250:
					self.truck.rect.move_ip(10, 0)
				else:
					self.gamesetup = 0
					self.active = 0
					self.trucksoundplay = 0
			else:
				self.timerunningout.stop()
				self.timeout.play()
				self.truck.initRightFrames()
				for event in pygame.event.get():
					if self.gamecore.handle_global_event(event):
						continue
					if event.type == pygame.QUIT:
						sys.exit()
					elif event.type == KEYDOWN:
						if (event.key == K_ESCAPE):
							sys.exit()
				goal = (self.levelfruit - self.missedfruitallowed)
				if goal > self.totalfruit:
					"""Lose: User did not collect enough fruit to pass the level"""
					self.winstatus = 0
				elif goal < self.totalfruit:
					"""Win: User has extra fruit too:  Store"""
					self.winstatus = 2
				else:
					"""Win: No extra fruit though"""
					self.winstatus = 1
					
				self.gamesetup = 2
				
					
			self.screen.blit(self.board, self.boardrect)
			
			lstCols = pygame.sprite.spritecollide(self.xman, self.fruit_sprites, False)
			if len(lstCols) > 0:
				if self.xman.fruits + 1 <= self.xman.maxfruits:
					pygame.sprite.spritecollide(self.xman, self.fruit_sprites, True)
					self.xman.fruits += 1
					self.getfruit.play()
				else:
					if not pygame.mixer.get_busy():
						self.nofruit.play()
			if self.xman.fruits > 0:
				lstCols = pygame.sprite.spritecollide(self.xman, self.truck_sprites,  False)
				if len(lstCols) > 0:
					self.totalfruit += self.xman.fruits
					self.xman.fruits = 0
					self.dropfruit.play()
		
			self.rock_sprites.draw(self.screen)
			self.log_sprites.draw(self.screen)
			self.treebottom_sprites.draw(self.screen)
			self.fruit_sprites.update(pygame.time.get_ticks())
			self.fruit_sprites.draw(self.screen)
			self.monkey_sprites.update(pygame.time.get_ticks(), self.xman)
			self.monkey_sprites.draw(self.screen)
			self.xman_sprites.update(pygame.time.get_ticks())
			self.xman_sprites.draw(self.screen)
			self.treetop_sprites.draw(self.screen)
			#draw background
			self.screen.blit(self.background, self.backgroundrect)
			self.truck_sprites.update(pygame.time.get_ticks())
			self.truck_sprites.draw(self.screen)
			self.drawtext()
			
			self.gamecore.present()
			theclock.tick(30)
		endtime = pygame.time.get_ticks() + self.splashduration
		self.active = 1
		while pygame.time.get_ticks() < endtime and self.active == 1:
			for event in pygame.event.get():
				if self.gamecore.handle_global_event(event):
					continue
				if event.type == pygame.QUIT:
					sys.exit()
				elif event.type == KEYDOWN:
					self.active = 0
		
			if self.winstatus >= 1:
				self.win_sprite.draw(self.screen)
			elif self.winstatus == 0:
				self.lose_sprite.draw(self.screen)
			
			self.gamecore.present()
			theclock.tick(30)


			
	def LoadSprites(self):
		self.fruit_sprites = pygame.sprite.Group()
		self.nogo_sprites = pygame.sprite.Group()
		self.treetop_sprites = pygame.sprite.Group()
		self.treebottom_sprites = pygame.sprite.Group()
		self.rock_sprites = pygame.sprite.Group()
		self.monkey_sprites = pygame.sprite.Group()
		self.log_sprites = pygame.sprite.Group()
		self.win = Win()
		self.lose = Lose()
		self.win_sprite = pygame.sprite.RenderPlain((self.win))
		self.lose_sprite = pygame.sprite.RenderPlain((self.lose))
		self.truck = Truck()
		self.truck_sprites = pygame.sprite.RenderPlain((self.truck))
		skipnext = 0
		x = y = 0
		for row in self.levelinfo:
			skipnext = 0
			for col in row:
				if skipnext > 0:
					skipnext -= 1
				elif col == "@":
					self.fruit_sprites.add(Fruit(pygame.Rect(self.horizpadding + 20 + x*50, self.vertpadding + y*50, 18, 19)))
				elif col == "T":
					self.treetop_sprites.add(TreeTop(pygame.Rect(self.horizpadding + x*50 , self.vertpadding - 120+ y*50, 100, 70)))
					self.treebottom_sprites.add(TreeBottom(pygame.Rect(self.horizpadding + x*50 , self.vertpadding - 50+ y*50, 100, 50)))
					skipnext = 1
					#skip to the end of the tree
				elif col == "R":
					self.rock_sprites.add(Rock((self.horizpadding+ x*50, self.vertpadding+y*50)))
				elif col == "L":
					self.log_sprites.add(Log((self.horizpadding + x*50, self.vertpadding + y*50)))
					skipnext = 3
					#skip to the end of the log
				elif col == "S":
					self.xman = XMan((self.horizpadding+x*50, self.vertpadding+y*50))
					self.xman_sprites = pygame.sprite.RenderPlain((self.xman))
				elif col == "M":
					self.monkey_sprites.add(Monkey(pygame.Rect(self.horizpadding+x*50, self.vertpadding+x*50, 48, 49)))
				x += 1
			skipnext = 0
			x = 0
			y += 1


class XMan(pygame.sprite.Sprite):
	def getlastmove(self):
		return self.lastx, self.lasty
		
	def __init__(self, initial_position, fps = 10):
		pygame.sprite.Sprite.__init__(self)
		self.start = pygame.time.get_ticks()
		self.delay = 1000 / fps
		self.fruiteat = load_sound("fruit_eat.ogg")
		self.frames = []
		self.frames.append(load_image("b_stay_l.png"))
		self.frames.append(load_image("b_stay_x.png"))
		self.frames.append(load_image("b_stay_r.png"))
		self.frames.append(load_image("b_stay_x.png"))
		self.rect = pygame.Rect(initial_position, (34, 45))
		self.changeframe(0)
		self.frame = 0
		self.last_update = 0
		self.fruits = 0
		self.maxfruits = 3
		self.lastx = self.lasty = 0
		self.x_dist = self.y_dist = 4
		self.lastrapedbymonkey = 0

	def changeIntoBasket(self):
		self.frames = []
		self.frames.append(load_image("b_bask_l.png"))
		self.frames.append(load_image("b_bask_x.png"))
		self.frames.append(load_image("b_bask_r.png"))
		self.frames.append(load_image("b_bask_x.png"))
		self.maxfruits = 5
		
	def changeIntoShoes(self):
		self.x_dist = self.y_dist = 6
	
	def movex(self):
		xMove = 0;
		pygame.event.pump()
		key = pygame.key.get_pressed()
		if key[K_RIGHT]:
			xMove  = self.x_dist
		if key[K_LEFT]:
			xMove = -self.x_dist
		self.lastx = xMove
		
		self.rect.move_ip(xMove, 0)
	def dropapple(self, monkeyobj):
		if monkeyobj.rect.colliderect(self.rect):
			if pygame.time.get_ticks() - self.lastrapedbymonkey > (1000 * 2):
				if self.fruits > 0:
					self.fruits -= 1
					self.fruiteat.play()
					self.lastrapedbymonkey = pygame.time.get_ticks()
		
	def movey(self):
		yMove = 0;
		pygame.event.pump()
		key = pygame.key.get_pressed()
		if key[K_UP]:
			yMove = -self.y_dist
		if key[K_DOWN]:
			yMove = self.y_dist
		self.lasty = yMove
		
		self.rect.move_ip(0, yMove)
		
	def changeframe(self, num):
		frameimg, framerect = self.frames[num]
		self.image = frameimg
	
	def update(self, t):
		if t-self.last_update > self.delay:
			self.frame += 1
			if self.frame >= len(self.frames): self.frame = 0
			self.changeframe(self.frame)
			self.last_update = t

				
		
class AnimatedSprite(pygame.sprite.Sprite):
	def __init__(self, images, fps = 10):
		pygame.sprite.Sprite.__init__(self)
		self._images = images
		self._start = pygame.time.get_ticks()
		self._delay = 1000 / fps
		self._last_update = 0
		self._frame = 0
		self.update(pygame.time.get_ticks())
	def update(self, t):
		if t - self._last_update > self._delay:
			self._frame += 1
			if self._frame >= len(self._images): self._frame = 0
			self.image = self._images[self._frame]
			self._last_update = t
	
class TreeTop(pygame.sprite.Sprite):
	def __init__(self, initial_position, fps = 5):
		pygame.sprite.Sprite.__init__(self)
		self.image, self.rect = load_image("t_top_70.png")
		self.rect = initial_position

		
class TreeBottom(pygame.sprite.Sprite):
	def __init__(self, initial_position, fps = 5):
		pygame.sprite.Sprite.__init__(self)
		self.image, self.rect = load_image("t_low.png")
		self.rect = initial_position
		

class Fruit(pygame.sprite.Sprite):
	def __init__(self, initial_position, fps = 5):
		pygame.sprite.Sprite.__init__(self)
		self.start = pygame.time.get_ticks()
		self.delay = 1000 / fps
		
		self.frames = []
		self.frames.append(load_image("f_turn_l.png"))
		self.frames.append(load_image("f_turn_x.png"))
		self.frames.append(load_image("f_turn_r.png"))
		self.frames.append(load_image("f_turn_x.png"))
		
		self.rect = initial_position
		self.frame = random.randint(0, 3)
		self.last_update = 0	
		
	def changeframe(self, num):
		frameimg, framerect = self.frames[num]
		self.image = frameimg
	
	def update(self, t):
		if t-self.last_update > self.delay:
			self.frame += 1
			if self.frame >= len(self.frames): self.frame = 0
			self.changeframe(self.frame)
			self.last_update = t
			
class Truck(pygame.sprite.Sprite):
	def __init__(self, fps = 5):
		pygame.sprite.Sprite.__init__(self)
		self.start = pygame.time.get_ticks()
		self.delay = 1000 / fps
		self.rect = pygame.Rect(0,0, 150, 150)
		self.rect.topleft = (1210, -30)
		self.initLeftFrames()
		self.frame = 0
		self.last_update = 0	
		
	def initLeftFrames(self):
		self.frames = []
		self.frames.append(load_image("tr_l_1.png"))
		self.frames.append(load_image("tr_l_2.png"))

	def initRightFrames(self):
		self.frames = []
		self.frames.append(load_image("tr_r_1.png"))
		self.frames.append(load_image("tr_r_2.png"))

	def initStayFrames(self):
		self.frames = []
		self.frames.append(load_image("tr_x.png"))

	def changeframe(self, num):
		frameimg, framerect = self.frames[num]
		self.image = frameimg
	
	def update(self, t):
		if t-self.last_update > self.delay:
			self.frame += 1
			if self.frame >= len(self.frames): self.frame = 0
			self.changeframe(self.frame)
			self.last_update = t

class Monkey(pygame.sprite.Sprite):
	def __init__(self, initial_position, fps = 5):
		pygame.sprite.Sprite.__init__(self)
		self.start = pygame.time.get_ticks()
		self.delay = 1000 / fps
		self.speeddelay = 1000 / 30
		self.curdirection = random.randint(0, 1)
		self.leftimg1, self.leftrect1 = load_image("m_move1.png")
		self.leftimg2, self.leftrect2 = load_image("m_move2.png")
		self.rightimg1 = pygame.transform.flip(self.leftimg1, True, False)
		self.rightimg2 = pygame.transform.flip(self.leftimg2, True, False)
		self.changedirection(self.curdirection)
		self.rect = initial_position
		self.last_update = 0	
		self.movelast_update = 0	
		self.frame = 0
		self.normalspeed = 5
		self.rushspeed = 15
		self.speed = self.normalspeed
		self.seensound = load_sound("monkey_attack.ogg")
	def loadleft(self):
		self.frames = []
		self.frames.append((self.leftimg1, self.leftrect1))
		self.frames.append((self.leftimg2, self.leftrect2))
		
	def loadright(self):
		self.frames = []
		self.frames.append((self.rightimg1, self.leftrect1))
		self.frames.append((self.rightimg2, self.leftrect2))
		
	def CanSeePlayer(self, xmanobject):
		if self.curdirection == 0:
			#look left
			testrect = pygame.Rect(10,self.rect.top, self.rect.left-10, self.rect.height)
		else:
			#look right
			testrect = pygame.Rect(self.rect.left, self.rect.top, 810-self.rect.left, self.rect.height)
		if testrect.colliderect(xmanobject.rect):
			self.speed = self.rushspeed
			xmanobject.dropapple(self)
			if not pygame.mixer.get_busy():
				self.seensound.play()
			self.lastate = pygame.time.get_ticks()	
		else:
			self.speed = self.normalspeed
		
	def move(self):
		if self.curdirection == 0:
			self.rect.move_ip(-self.speed, 0)
		else:
			self.rect.move_ip(self.speed, 0)
		
		if self.rect.left < 10:
			self.changedirection(1)
			self.rect.move_ip(self.speed, 0)
		if self.rect.right > (800 + 10):
			self.changedirection(0)
			self.rect.move_ip(-self.speed, 0)
	
	def changedirection(self, dir):
		self.curdirection = dir
		if dir == 0:
			self.loadleft()
		else:
			self.loadright()
		
	
	def changeframe(self, num):
		frameimg, framerect = self.frames[num]
		self.image = frameimg
	
	def update(self, t, xmanobj):
		self.CanSeePlayer(xmanobj)
		if t-self.last_update > self.delay:
			self.frame += 1
			if self.frame >= len(self.frames): self.frame = 0
			self.changeframe(self.frame)
			self.last_update = t
		if t-self.movelast_update > self.speeddelay:
			self.move()
			self.movelast_update = t
			

class Nogo(pygame.sprite.Sprite):
	def __init__(self, initial_position):
		pygame.sprite.Sprite.__init__(self)
		self.image = pygame.Surface([initial_position.width, initial_position.height])
		self.image.fill((random.randint(1, 255),0,0))
		self.rect = self.image.get_rect()
		self.rect.topleft = initial_position.topleft
class FruitNogo(pygame.sprite.Sprite):
	def __init__(self, initial_position):
		pygame.sprite.Sprite.__init__(self)
		self.image = pygame.Surface([initial_position.width, initial_position.height])
		self.image.fill((0, random.randint(1, 255),0))
		self.rect = self.image.get_rect()
		self.rect.topleft = initial_position.topleft
		
class Rock(pygame.sprite.Sprite):
	def __init__(self, initial_position):
		pygame.sprite.Sprite.__init__(self)
		if random.randint(0, 1) == 1:
			self.image, self.rect = load_image("r_1.png")
		else:
			self.image, self.rect = load_image("r_2.png")
		self.rect.topleft = initial_position
		
class Log(pygame.sprite.Sprite):
	def __init__(self, initial_position):
		pygame.sprite.Sprite.__init__(self)
		self.image, self.rect = load_image("l_h.png")
		if random.randint(0, 1) == 1:
			self.image = pygame.transform.flip(self.image, True, False)
		self.rect.topleft = initial_position

class Win(pygame.sprite.Sprite):
	def __init__(self):
		pygame.sprite.Sprite.__init__(self)
		self.image, self.rect = load_image("win.png")
		self.rect.topleft = (0, 0)
class Lose(pygame.sprite.Sprite):
	def __init__(self):
		pygame.sprite.Sprite.__init__(self)
		self.image, self.rect = load_image("lose.png")
		self.rect.topleft = (0, 0)
