import os, sys
import pygame
from pygame.locals import *
from helpers import *
from Menu import *
from HighScores import *
from Level import *
from Shop import *

# asegura que las rutas relativas a "data" y "levels" funcionen sin
# importar desde donde se ejecute o se haga doble clic en Windows
os.chdir(os.path.dirname(os.path.abspath(__file__)))

if not pygame.font: print "Warning, fonts disabled"
if not pygame.mixer: print "Warning, sound disabled"

class MainGame:	
	def __init__(self, width=1200, height=825, start_fullscreen=False):
		pygame.init()
		self.width = width
		self.height = height
		pygame.display.set_caption("Fruitix")
		self.fullscreen = False
		self.windowed_size = (self.width, self.height)

		# The original game is designed around a fixed 1200x825 canvas.
		# Keep that canvas untouched and scale it proportionally onto the PC display.
		self.display = pygame.display.set_mode(self.windowed_size)
		self.screen = pygame.Surface((self.width, self.height)).convert()
		self._last_present_size = self.windowed_size
		pygame.key.set_repeat(500, 30)
		self.menuchoice = ""
		self.score = 0
		self.lives = 0
		self.currentlevel = 1
		self.levels = ["level1.txt", "level2.txt", "level3.txt", "level4.txt", "level5.txt", "level6.txt", "level7.txt", "level8.txt", "level9.txt", "level10.txt"]
		pygame.mixer.music.set_volume(0.5)
		pygame.mixer.music.load(os.path.join("data", "jos_brb.mod"))
		pygame.mixer.music.play(-1)
		if start_fullscreen:
			self.toggle_fullscreen()

	def toggle_fullscreen(self):
		"""F11: cambia entre ventana y fullscreen usando un modo compatible con SDL."""
		if not self.fullscreen:
			# Older pygame/SDL builds can reject (0, 0) and can also reject
			# the original 1200x825 size in fullscreen. Ask SDL which modes
			# actually exist and use the largest one available.
			modes = pygame.display.list_modes()
			if modes == -1:
				modes = []

			# Prefer a mode close to the game's 1200x825 aspect ratio, while
			# still choosing the largest usable resolution.
			target_ratio = float(self.width) / float(self.height)
			if modes:
				def mode_score(mode):
					w, h = mode
					ratio_error = abs((float(w) / float(h)) - target_ratio)
					area = w * h
					return (ratio_error, -area)
				mode = sorted(modes, key=mode_score)[0]
			else:
				mode = self.windowed_size

			try:
				self.display = pygame.display.set_mode(mode, pygame.FULLSCREEN)
			except pygame.error:
				# Try every reported mode, largest first, until SDL accepts one.
				self.display = None
				for fallback in sorted(modes, key=lambda m: m[0] * m[1], reverse=True):
					try:
						self.display = pygame.display.set_mode(fallback, pygame.FULLSCREEN)
						break
					except pygame.error:
						pass
				if self.display is None:
					# Fullscreen is not available on this backend; remain windowed.
					self.fullscreen = False
					self.display = pygame.display.set_mode(self.windowed_size)
					self.display.fill((0, 0, 0))
					self.screen.fill((0, 0, 0))
					self.present()
					return

			self.fullscreen = True
		else:
			self.fullscreen = False
			self.display = pygame.display.set_mode(self.windowed_size)

		# Force a clean frame after changing video modes.
		self.display.fill((0, 0, 0))
		self.screen.fill((0, 0, 0))
		self.present()

	def present(self):
		"""Draw the fixed game canvas centered and uniformly scaled on any PC display."""
		dw, dh = self.display.get_size()
		sw, sh = self.screen.get_size()

		scale = min(float(dw) / float(sw), float(dh) / float(sh))
		w = max(1, int(sw * scale))
		h = max(1, int(sh * scale))

		x = (dw - w) / 2
		y = (dh - h) / 2

		self.display.fill((0, 0, 0))
		if (w, h) == (sw, sh):
			frame = self.screen
		else:
			frame = pygame.transform.scale(self.screen, (w, h))
		self.display.blit(frame, (int(x), int(y)))
		pygame.display.flip()

	def handle_global_event(self, event):
		if event.type == KEYDOWN and event.key == K_F11:
			self.toggle_fullscreen()
			return True
		return False

	def MainLoop(self):
		theclock = pygame.time.Clock()
		while 1:
			menu = Menu(self)
			menu.Run()
			
			self.runningscore = 0
			self.powerup_basket = 0
			self.powerup_shoes = 0
			
			if self.menuchoice == "exit":
				sys.exit()
			elif self.menuchoice == "highscores":
				highscores = HighScores(self)
				highscores.Run()
				continue
			elif self.menuchoice == "credits":
				runme = 1
				picture = pygame.image.load(os.path.join("data", "credits.png"))
				pygame.mixer.music.fadeout(100)
				pygame.mixer.music.load(os.path.join("data", "vodka.xm"))
				pygame.mixer.music.play(-1)

				while runme:
					for event in pygame.event.get():
						if self.handle_global_event(event):
							continue
						if event.type == KEYDOWN:
							runme = 0
					self.screen.blit(picture, (0, 0))
					scorefont = pygame.font.Font(None, 32)
					scorefont.set_bold(True)			
					pressany = scorefont.render("Press any key to return to the main menu", 1, (255, 255, 255))
					pressanypos = pressany.get_rect(centerx = self.width / 2, y = self.height - 40)
					self.screen.blit(pressany, pressanypos)
					self.present()
					theclock.tick(30)
				continue
					
			pygame.mixer.music.fadeout(1000)
			
			hs = HighScores(self)
			for lev in self.levels:
				level = Level(self, lev, self.powerup_shoes, self.powerup_basket)
				level.Run()
				
				self.runningscore += level.getTotalCollected()
				
				if level.getRunResult() == 0:
					#user lost
					break
				elif level.getRunResult() == 2:
					
					#user goes to store
					sp = Shop(self, self.powerup_shoes, self.powerup_basket, self.runningscore)
					newscore, newshoes, newbasket = sp.Run()
					self.runningscore = newscore
					self.powerup_shoes = newshoes
					self.powerup_basket = newbasket
					
				self.currentlevel += 1
				
			if hs.isElgible(self.runningscore) == 1:
				#high score will make it on the high score page.  Ask for name
				username = hs.askForName(self.runningscore)
				if len(username) == 3:
					hs.addscore(username, self.runningscore)
			
			theclock.tick(30)
			

def main():
	# Se puede pasar por linea de comandos:
	#   Fruitix.py            -> ventana 1200x825 (tamano original)
	#   Fruitix.py 1024x768   -> ventana con esa resolucion
	#   Fruitix.py full       -> pantalla completa (resolucion del escritorio)
	#   Fruitix.py 1024x768 full -> pantalla completa partiendo de ese ancho/alto
	width, height = 1200, 825
	start_fullscreen = False
	for arg in sys.argv[1:]:
		if arg.lower() == "full":
			start_fullscreen = True
		elif "x" in arg.lower():
			try:
				w_str, h_str = arg.lower().split("x")
				width, height = int(w_str), int(h_str)
			except ValueError:
				pass

	MainWindow = MainGame(width, height, start_fullscreen)
	MainWindow.MainLoop()

if __name__ == "__main__":
	main()
