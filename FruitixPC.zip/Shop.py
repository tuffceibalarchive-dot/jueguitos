import os, sys, time, random
import pygame
from pygame.locals import *
from helpers import *

if not pygame.font: print "Warning, fonts disabled"
if not pygame.mixer: print "Warning, sound disabled"

class Shop:
	def __init__(self, gamecore, shoepowerup, basketpowerup, score):
		self.active = 1
		self.screen = gamecore.screen
		self.gamecore = gamecore
		self.score = score
		self.shoepowerup = shoepowerup
		self.basketpowerup = basketpowerup
		
		self.width, self.height = self.screen.get_size()
		"""Create the background"""
		self.background = pygame.image.load(os.path.join("data", "sh_bg.png"))
		self.curcounter = 0
		self.changesound = load_sound("change_option.ogg")
		self.selectsound = load_sound("select_option.ogg")
		self.finishedsound = load_sound("cash_register.ogg")
		self.errorsound = load_sound("no_fruit.ogg")
		
		self.bgpos = 0
		self.LoadSprites()

	def LoadSprites(self):
		self.buttons = pygame.sprite.Group()
		if self.shoepowerup == 1:
			self.buttons.add(ImageButton(0, (932, 10), "sh_shoe_2_check.png", ["sh_shoe_1_check.png"]))
		else:
			self.buttons.add(ImageButton(0, (932, 10), "sh_shoe_2.png", ["sh_shoe_1.png"]))
		if self.basketpowerup == 1:
			self.buttons.add(ImageButton(1, (780, 150), "sh_bas_2_check.png", ["sh_bas_1_check.png"]))
		else:
			self.buttons.add(ImageButton(1, (780, 150), "sh_bas_2.png", ["sh_bas_1.png"]))
			
		self.buttons.add(ImageButton(2, (830, 690), "sc_exit_x.png", ["sc_exit_1.png", "sc_exit_2.png", "sc_exit_3.png"]))
	def drawScore(self, initials, centers):
		initialfont = pygame.font.Font(None, 100)
		initialfont.set_bold(True)
		text = initialfont.render(str(initials), 1, (255, 255, 0))
		centerxa, centerya = centers
		textrect = text.get_rect(left = centerxa, centery = centerya)
		self.screen.blit(text, textrect)
	
	def Run(self):
		theclock = pygame.time.Clock()
		self.curcounter = 2
		while self.active == 1:
			
			for event in pygame.event.get():
				if self.gamecore.handle_global_event(event):
					continue
				if event.type == KEYDOWN:
					if (event.key == pygame.QUIT):
						sys.exit()
					elif (event.key == K_ESCAPE):
						sys.exit()
					elif (event.key == K_RETURN):
						if (self.curcounter == 0):
							self.gamecore.menuchoice = "shoe"
							if self.shoepowerup == 1:
								self.errorsound.play()
							elif self.score < 40:
								self.errorsound.play()
							else:
								#user can purchase shoes
								self.score -= 40
								self.shoepowerup = 1
								self.curcounter = 2
								self.finishedsound.play()
						elif (self.curcounter == 1):
							self.gamecore.menuchoice = "basket"
							if self.basketpowerup == 1:
								self.errorsound.play()
							elif self.score < 50:
								self.errorsound.play()
							else:
								#user can purchase basket
								self.score -= 50
								self.basketpowerup = 1
								self.curcounter = 2
								self.finishedsound.play()
						elif (self.curcounter == 2):
							self.gamecore.menuchoice = "exit"
							self.active = 0
							self.finishedsound.play()
							break
					elif (event.key == K_UP):
						self.curcounter -= 1
						self.changesound.play()
					elif (event.key == K_DOWN):
						self.curcounter += 1
						self.changesound.play()
					
					if self.curcounter < 0:
						self.curcounter = 2
					elif self.curcounter > 2:
						self.curcounter = 0
			self.screen.blit(self.background, (0,0))
			self.drawScore(self.score, (544, 742))
			self.buttons.update(pygame.time.get_ticks(), self.curcounter)
			self.buttons.draw(self.screen)
			self.gamecore.present()
			theclock.tick(30)
		return self.score, self.shoepowerup, self.basketpowerup
			
class ImageButton(pygame.sprite.Sprite):
	def __init__(self, selectedid, initial_position, nonselectedimage, animlist):
		pygame.sprite.Sprite.__init__(self)
		self.selectedid = selectedid
		self.initialimage, self.initialrect = load_image(nonselectedimage)
		self.rect = self.initialrect
		self.rect.topleft = initial_position
		self.frames = []
		self.frames.append((self.initialimage, self.initialrect))
		for i in animlist:
			self.frames.append(load_image(i))
		
		self.changeframe(0)
		self.frame = 0
		self.last_update = 0
		
		self.fps = 8
		self.delay = 1000 / self.fps
		
		
	def changeframe(self, num):
		frameimg, framerect = self.frames[num]
		self.image = frameimg
	
	def update(self, t, selectedid):
		if self.selectedid == selectedid:
			if t-self.last_update > self.delay:
				self.frame += 1
				if self.frame >= len(self.frames): self.frame = 1
				self.changeframe(self.frame)
				self.last_update = t
		else:
			if self.frame != 0:
				self.changeframe(0)
				self.frame = 0

		
class ImageSprite(pygame.sprite.Sprite):
	def __init__(self, filepath, centerpos):
		pygame.sprite.Sprite.__init__(self)
		self.image, self.rect = load_image(filepath)
		self.rect.center = centerpos

