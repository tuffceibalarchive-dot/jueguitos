import os, sys, time, random
import pygame
from pygame.locals import *
from helpers import *

if not pygame.font: print "Warning, fonts disabled"
if not pygame.mixer: print "Warning, sound disabled"

class Menu:
	def __init__(self, gamecore):
		self.active = 1
		self.screen = gamecore.screen
		self.gamecore = gamecore
		self.width, self.height = self.screen.get_size()
		"""Create the background"""
		self.background = pygame.Surface(self.screen.get_size())
		self.background = self.background.convert()
		self.background.fill((255,255,255))
		self.curcounter = 0
		self.menuchange = load_sound("change_option.ogg")
		self.menuselect = load_sound("select_option.ogg")
		self.bgpos = 0
		self.LoadSprites()

	def LoadSprites(self):
		self.logo = ImageSprite("fruitix_logo.png", (600, 200))
		self.logo_sprite = pygame.sprite.RenderPlain((self.logo))
		self.buttons = pygame.sprite.Group()
		
		self.buttons.add(ImageButton(0, (100, 380), "sc_start_x.png", ["sc_start_1.png", "sc_start_2.png", "sc_start_3.png"]))
		self.buttons.add(ImageButton(1, (100, 490), "sc_high_x.png", ["sc_high_1.png", "sc_high_2.png", "sc_high_3.png"]))
		self.buttons.add(ImageButton(2, (70, 590), "sc_credits_x.png", ["sc_credits_1.png", "sc_credits_2.png", "sc_credits_3.png"]))
		self.buttons.add(ImageButton(3, (100, 690), "sc_exit_x.png", ["sc_exit_1.png", "sc_exit_2.png", "sc_exit_3.png"]))
		
		self.languages = pygame.sprite.Group()
		self.languages.add(LanguageImage("lang1.png", 0))
		self.languages.add(LanguageImage("lang2.png", 1))
		self.languages.add(LanguageImage("lang3.png", 2))
		self.languages.add(LanguageImage("lang4.png", 3))
		self.languages.add(LanguageImage("lang5.png", 4))
		self.languages.add(LanguageImage("lang6.png", 5))
		self.languages.add(LanguageImage("lang7.png", 6))
		self.instruction = pygame.image.load(os.path.join("data","sc_info.png"))
			
	def Run(self):
		theclock = pygame.time.Clock()
		self.curcounter = 0
		while self.active == 1:
			for event in pygame.event.get():
				if self.gamecore.handle_global_event(event):
					continue
				if event.type == KEYDOWN:
					if (event.key == pygame.QUIT):
						sys.exit()
					elif (event.key == K_ESCAPE):
						sys.exit()
					elif (event.key == K_UP):
						self.curcounter -= 1
						self.menuchange.play()
					elif (event.key == K_DOWN):
						self.curcounter += 1
						self.menuchange.play()
					elif (event.key == K_RETURN):
						if (self.curcounter == 0):
							self.gamecore.menuchoice = "start"
						elif (self.curcounter == 1):
							self.gamecore.menuchoice = "highscores"
						elif (self.curcounter == 2):
							self.gamecore.menuchoice = "credits"
						elif (self.curcounter == 3):
							self.gamecore.menuchoice = "exit"
						self.menuselect.play()
						self.active = 0
						break
					if self.curcounter < 0:
						self.curcounter = 3
					elif self.curcounter > 3:
						self.curcounter = 0
			
			
			self.screen.blit(self.background, (0,0))
			self.languages.update()
			self.languages.draw(self.screen)
			self.logo_sprite.draw(self.screen)
			self.buttons.update(pygame.time.get_ticks(), self.curcounter)
			self.buttons.draw(self.screen)
			
				
			scorefont = pygame.font.Font(None, 32)
			pressany = scorefont.render("Build 1.01B", 1, (0,0,0))
			pressanypos = pressany.get_rect(right = 1200-6, y = self.height - 25)
			self.screen.blit(pressany, pressanypos)

			self.gamecore.present()
			theclock.tick(30)
		
		self.active = 1
		if self.gamecore.menuchoice == "start":
			while self.active == 1:
				for event in pygame.event.get():
					if self.gamecore.handle_global_event(event):
						continue
					if event.type == pygame.QUIT:
						sys.exit()
					elif event.type == KEYDOWN:
						self.active = 0
				scorefont = pygame.font.Font(None, 32)
				scorefont.set_bold(True)			
				pressany = scorefont.render("Press any key to continue", 1, (255, 255, 255))
				pressanypos = pressany.get_rect(left = 30, y = self.height - 40)
				self.screen.blit(self.instruction, (0, 0))
				self.screen.blit(pressany, pressanypos)
				
				self.gamecore.present()
				theclock.tick(30)

class ImageButton(pygame.sprite.Sprite):
	def __init__(self, selectedid, initial_position, nonselectedimage, animlist):
		pygame.sprite.Sprite.__init__(self)
		self.selectedid = selectedid
		self.initialimage, self.initialrect = load_image(nonselectedimage)
		self.rect = self.initialrect
		self.rect.topleft = initial_position
		self.frames = []
		self.frames.append((self.initialimage, self.initialrect))
		for i in animlist:
			self.frames.append(load_image(i))
		
		self.changeframe(0)
		self.frame = 0
		self.last_update = 0
		
		self.fps = 8
		self.delay = 1000 / self.fps
		
		
	def changeframe(self, num):
		frameimg, framerect = self.frames[num]
		self.image = frameimg
	
	def update(self, t, selectedid):
		if self.selectedid == selectedid:
			if t-self.last_update > self.delay:
				self.frame += 1
				if self.frame >= len(self.frames): self.frame = 1
				self.changeframe(self.frame)
				self.last_update = t
		else:
			if self.frame != 0:
				self.changeframe(0)
				self.frame = 0

		
class ImageSprite(pygame.sprite.Sprite):
	def __init__(self, filepath, centerpos):
		pygame.sprite.Sprite.__init__(self)
		self.image, self.rect = load_image(filepath)
		self.rect.center = centerpos

class LanguageImage(pygame.sprite.Sprite):
	def __init__(self, filepath, linenumber):
		pygame.sprite.Sprite.__init__(self)
		self.image, self.rect = load_image(filepath)
		self.rect.left = random.randint(-200, 1200)
		self.rect.top = linenumber * self.rect.height
		self.movespeed = 2
	
	def update(self):
		self.rect.move_ip(-self.movespeed, 0)
		if self.rect.right < 0:
			self.rect.left = 1200




