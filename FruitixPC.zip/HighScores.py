import os, sys, time
import pygame
from pygame.locals import *
from helpers import *
if not pygame.font: print "Warning, fonts disabled"
if not pygame.mixer: print "Warning, sound disabled"

class HighScores:
	def __init__(self, gamecore):
		self.active = 1
		self.screen = gamecore.screen
		self.gamecore = gamecore
		self.width, self.height = self.screen.get_size()
		"""Create the background"""
		self.background = pygame.image.load(os.path.join("data", "hs_bg.png"))
		self.letterbackground = pygame.image.load(os.path.join("data", "hs_enter.png"))
		self.highscores = []
		self.loadscores()
		self.changesound = load_sound("change_option.ogg")
		self.selectsound = load_sound("select_option.ogg")
		self.deletesound = load_sound("fruit_eat.ogg")
		self.finishedsound = load_sound("cash_register.ogg")
		self.alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
		
	def scorecompare(self, a, b):
		scorea, namea = a
		scoreb, nameb = b
		return int(scoreb)-int(scorea)

	def askForName(self, score):
		self.curcounter = 0
		theclock = pygame.time.Clock()
		curletterpos = 0
		curspacepos = 0
		letters = []
		letters.append(self.alphabet[0])
		while self.active == 1:
			self.screen.blit(self.letterbackground, (0,0))
			if curspacepos == 3:
				self.active = 0
				return letters[0] + letters[1] + letters[2]
			
			for event in pygame.event.get():
				if self.gamecore.handle_global_event(event):
					continue
				if event.type == KEYDOWN:
					if (event.key == pygame.QUIT):
						sys.exit()
					elif (event.key == K_ESCAPE):
						self.active = 0
					elif (event.key == K_DOWN):
						curletterpos += 1
						if curletterpos >= len(self.alphabet):
							curletterpos = 0
						letters.pop()
						letters.append(self.alphabet[curletterpos])
						self.changesound.play()
					elif (event.key == K_UP):
						curletterpos -= 1
						if curletterpos < 0:
							curletterpos = len(self.alphabet)-1
						letters.pop()
						letters.append(self.alphabet[curletterpos])
						self.changesound.play()
					elif (event.key == K_RETURN):
						letters.append(self.alphabet[curletterpos])
						if len(letters) == 4:
							self.finishedsound.play()
						else:
							self.selectsound.play()
						curspacepos += 1
					elif (event.key == K_BACKSPACE or event.key == K_LEFT):
						curspacepos -= 1
						letters.pop()
						self.deletesound.play()
			self.drawScore(str(score), (495, 477))		
			count = 0
			for i in letters:

				if curspacepos == count:
					color = (130, 130, 130)
				else:
					color = (0,0,0)
				
				self.drawLetterSelect(i, (419 + 170*count, 277), color)
				count += 1
				if count == 3:
					break
			
			self.gamecore.present()
			theclock.tick(30)
			
			
	
		
	def drawLetterSelect(self, curletter, centers, color):
		initialfont = pygame.font.Font(None, 300)
		text = initialfont.render(curletter, 1, color)
		centerxa, centerya = centers
		textrect = text.get_rect(centerx = centerxa, centery = centerya)
		self.screen.blit(text, textrect)
		
	def addscore(self, initials, score):
		f = open("scores.txt", "a")
		strtowrite = "\r\n" + str(score) + "|" + initials
		f.write(strtowrite)
		f.close()
	def loadscores(self):
		f = open("scores.txt", "r")
		for line in f:
			test = line.split("|")
			if len(test) == 2:
				score, name = line.split("|", 2)
				self.highscores.append((score, name.strip()))
		f.close()
		self.highscores.sort(self.scorecompare)

	def isElgible(self, highscore):
		lowestscore, lowestname = self.highscores[9]
		if int(highscore) > int(lowestscore):
			return 1
		else:
			return 0
	
	def drawInitials(self, initials, centers):
		initialfont = pygame.font.Font(None, 100)
		text = initialfont.render(initials, 1, (0, 0, 0))
		centerxa, centerya = centers
		textrect = text.get_rect(centerx = centerxa, centery = centerya)
		self.screen.blit(text, textrect)
		
	def drawScore(self, initials, centers):
		initialfont = pygame.font.Font(None, 100)
		initialfont.set_bold(True)
		text = initialfont.render(initials, 1, (255, 255, 0))
		centerxa, centerya = centers
		textrect = text.get_rect(left = centerxa, centery = centerya)
		self.screen.blit(text, textrect)
		
	def Run(self):
		pygame.mixer.music.fadeout(100)
		pygame.mixer.music.load(os.path.join("data", "vodka.xm"))
		pygame.mixer.music.play(-1)

		self.curcounter = 0
		theclock = pygame.time.Clock()
		while self.active == 1:
			for event in pygame.event.get():
				if self.gamecore.handle_global_event(event):
					continue
				if event.type == KEYDOWN:
					if (event.key == pygame.QUIT):
						sys.exit()
					elif (event.key == K_ESCAPE):
						sys.exit()
					else:
						self.active = 0
			
			
			self.screen.blit(self.background, (0,0))
			
			count = 0
			vertspacing = 100
			vertstart = 270
			increment = 40
			horizstart = 155
			letterspacing = 65
			scoresprinted = 0
			for scoreline in self.highscores:
				score, name = scoreline
				if count == 5:
					horizstart = 704
					count = 0
					
				self.drawInitials(name[0], (horizstart,(vertstart + (vertspacing * count))))
				self.drawInitials(name[1], (horizstart+letterspacing,(vertstart + (vertspacing * count))))
				self.drawInitials(name[2], (horizstart+(letterspacing*2),(vertstart + (vertspacing * count))))
				
				self.drawScore(score, (horizstart + 290, (vertstart + (vertspacing * count))))
				
				
				
				count += 1
				scoresprinted += 1
				if scoresprinted == 10:
					break
				
			scorefont = pygame.font.Font(None, 32)
			scorefont.set_bold(True)			
			pressany = scorefont.render("Press any key to return to the main menu", 1, (255, 255, 255))
			pressanypos = pressany.get_rect(centerx = self.width / 2, y = self.height - 40)
			self.screen.blit(pressany, pressanypos)

			self.gamecore.present()
			theclock.tick(30)
		
			